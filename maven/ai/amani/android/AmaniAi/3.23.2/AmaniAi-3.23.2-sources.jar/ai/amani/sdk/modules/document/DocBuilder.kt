package ai.amani.sdk.modules.document
import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.SerializedName

data class DocBuilder(
        @SerializedName("tryAgainText")
        val tryAgainText: String?,

        @SerializedName("confirmText")
        val confirmText: String?,

        @SerializedName("tryAgainTextColor")
        val tryAgainTextColor: Int?,

        @SerializedName("confirmTextColor")
        val confirmTextColor: Int?,

        @SerializedName("captureButtonColor")
        val captureButtonColor: Int?,

        @SerializedName("documentCount")
        val documentCount: Int?)

    :Parcelable {
    constructor(parcel: Parcel) : this(
            parcel.readValue(Int::class.java.classLoader) as? String,
            parcel.readValue(Int::class.java.classLoader) as? String,
            parcel.readValue(Int::class.java.classLoader) as? Int,
            parcel.readValue(Int::class.java.classLoader) as? Int,
            parcel.readValue(Int::class.java.classLoader) as? Int,
            parcel.readValue(Int::class.java.classLoader) as? Int,) {
    }


    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeValue(tryAgainText)
        parcel.writeValue(confirmText)
        parcel.writeValue(tryAgainTextColor)
        parcel.writeValue(confirmTextColor)
        parcel.writeValue(captureButtonColor)
        parcel.writeValue(documentCount)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object  CREATOR : Parcelable.Creator<DocBuilder> {
        override fun createFromParcel(parcel: Parcel): DocBuilder {
            return DocBuilder(parcel)
        }

        override fun newArray(size: Int): Array<DocBuilder?> {
            return arrayOfNulls(size)
        }
    }
}