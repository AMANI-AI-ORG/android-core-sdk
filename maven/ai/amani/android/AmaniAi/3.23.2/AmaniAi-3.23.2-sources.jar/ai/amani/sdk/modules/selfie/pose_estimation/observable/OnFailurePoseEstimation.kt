package ai.amani.sdk.modules.selfie.pose_estimation.observable

/**
 * @Author: zekiamani
 * @Date: 8.08.2022
 */
enum class OnFailurePoseEstimation (
    val code: Int
        ){
    WRONG_POSE(8000)
}