package ai.amani.sdk.modules.document.upload

import ai.amani.base.util.AppPreferenceKey
import ai.amani.base.util.SessionManager
import ai.amani.base.utility.AmaniVersion
import ai.amani.sdk.Amani
import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.mapper.AmaniEventMapper.asAmaniEventType
import ai.amani.sdk.modules.amani_events.AmaniEvent
import ai.amani.sdk.modules.document.FileWithType
import ai.amani.sdk.modules.document_capture.camera.BitmapUtils.Companion.bitmapToBase64
import ai.amani.sdk.modules.document_capture.camera.BitmapUtils.Companion.byteArrayToBase64
import ai.amani.sdk.service.upload.ErrorConstants
import ai.amani.sdk.service.upload.HitUploadApi
import ai.amani.sdk.service.v2.upload.HitUploadApiV2
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Looper
import androidx.annotation.RequiresApi
import datamanager.v2.model.upload.request.ReqUploadV2
import okhttp3.MultipartBody

@RequiresApi(Build.VERSION_CODES.LOLLIPOP)
class UploadDocument {
    var iUploadCallBack: IUploadCallBack? = null

    fun invoke(
        activity: Activity,
        docType: String,
        data:ArrayList<FileWithType>?,
        operationID: String,
        actionType: String
    ) {
       if (data == null) uploadDocument(
           activity = activity,
           docType = docType,
           operationID = operationID,
           actionType = actionType
       )
       else uploadDocumentAsByteArray(
           activity = activity,
           docType = docType,
           data = data,
           actionType = actionType ,
           operationID = operationID
       )
    }

    private fun uploadDocument(
        activity: Activity,
        docType: String,
        operationID: String,
        actionType: String
    ) {
        val documentVersion = SessionManager.getVersion(docType)
        if (documentVersion == null) {
            iUploadCallBack!!.cb(false)
            AmaniEvent.getEvent()?.onError(
                type = docType.asAmaniEventType(),
                arrayListOf(ErrorConstants.DOCUMENT_VERSION_NULL_ERROR
                )
            )
            return
        }
        val hitUploadApi = HitUploadApi()
        val hitUploadApiV2 = HitUploadApiV2()
        val fileList: ArrayList<MultipartBody.Part> = ArrayList()
        var filePathList: ArrayList<String>
        var encodedDocument: String?
        var documentAsBmp: Bitmap?
        var documentAsFile: MultipartBody.Part?
        var documentList = mutableListOf<String>()

        Thread {
            Looper.prepare() // Prepare the looper
            filePathList = SessionManager.getListString(AppPreferenceKey.DOCUMENT_LIST)

            for (i in filePathList.indices){
                documentAsBmp = BitmapFactory.decodeFile(filePathList[i])
                documentAsBmp.let {
                    encodedDocument = bitmapToBase64(it!!)
                }
                documentAsFile = MultipartBody.Part.createFormData("files[]",
                        "data:image/jpeg;base64,$encodedDocument")

                documentList.add("data:image/jpeg;base64,$encodedDocument")

                documentAsFile.let {
                    fileList.add(it!!)
                }
            }

            when(Amani.VERSION.version) {
                AmaniVersion.V1.version -> {
                    hitUploadApi.iUploadCallBack = iUploadCallBack
                    hitUploadApi.UploadFunction(activity, fileList, documentVersion)
                }

                AmaniVersion.V2.version -> {
                    val request = ReqUploadV2()
                    request.documentType = docType
                    request.profile = SessionManager.getCustomerIdV2()
                    request.pages = documentList
                    request.uploadSource = Amani.getUploadSource()

                    hitUploadApiV2.requestUpload(
                        iUploadCallBack = iUploadCallBack!!,
                        uploadRequest = request,
                        activity = activity,
                        operationID = operationID,
                        actionType = actionType
                    )
                }
            }
            Looper.loop() // Quit from looper
            Looper.myLooper()!!.quitSafely()
        }.start()
    }

    private fun uploadDocumentAsByteArray(
        activity: Activity,
        docType: String,data: ArrayList<FileWithType>?,
        operationID: String,
        actionType: String
    ) {
        val documentVersion = SessionManager.getVersion(docType)
        if (documentVersion == null) {
            iUploadCallBack!!.cb(false)
            AmaniEvent.getEvent()?.onError(
                type = docType.asAmaniEventType(),
                arrayListOf(ErrorConstants.DOCUMENT_VERSION_NULL_ERROR
                )
            )
            return
        }
        val hitUploadApi = HitUploadApi()
        val hitUploadApiV2 = HitUploadApiV2()
        var encodedDocument: String?
        var documentAsFile: MultipartBody.Part?
        val fileList: ArrayList<MultipartBody.Part> = ArrayList()
        val encodedList: ArrayList<String> = ArrayList()

        Thread {
            Looper.prepare()  // Prepare the looper

            for (i in data!!.indices){
                encodedDocument = byteArrayToBase64(data[i].byteArray)
                val mimeType = data[i].type

                if (encodedDocument == null) {
                    iUploadCallBack!!.cb(false)
                    AmaniEvent.getEvent()?.onError(
                        type = docType.asAmaniEventType(),
                        arrayListOf(ErrorConstants.DOCUMENT_NULL_ERROR
                        )
                    )
                    return@Thread
                }

                encodedList.add("data:$mimeType;base64," + encodedDocument!!)

                documentAsFile = MultipartBody.Part.createFormData("files[]",
                    "data:$mimeType;base64,$encodedDocument")

                documentAsFile!!.let {
                    fileList.add(it)
                }

            }

            when(Amani.VERSION.version) {
                AmaniVersion.V1.version -> {
                    hitUploadApi.iUploadCallBack = iUploadCallBack
                    hitUploadApi.UploadFunction(activity, fileList, documentVersion)
                }

                AmaniVersion.V2.version -> {

                    val request = ReqUploadV2()
                    request.documentType = docType
                    request.profile = SessionManager.getCustomerIdV2()
                    request.pages = encodedList
                    request.uploadSource = Amani.getUploadSource()

                    hitUploadApiV2.requestUpload(
                        iUploadCallBack = iUploadCallBack!!,
                        uploadRequest = request,
                        activity = activity,
                        operationID = operationID,
                        actionType = actionType
                    )
                }
            }

            Looper.loop() // Quit from looper
            Looper.myLooper()!!.quitSafely()
        }.start()
    }
}