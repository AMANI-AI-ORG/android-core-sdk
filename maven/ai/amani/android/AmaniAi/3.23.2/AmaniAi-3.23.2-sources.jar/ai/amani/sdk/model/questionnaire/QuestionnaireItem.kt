package ai.amani.sdk.model.questionnaire


import com.google.gson.annotations.SerializedName

data class QuestionnaireItem(
    @SerializedName("answer_type")
    val answerType: String,
    @SerializedName("answers")
    val answers: List<Answer>,
    @SerializedName("id")
    val id: String,
    @SerializedName("sort_order")
    val sortOrder: Int,
    @SerializedName("title")
    val title: String,
    @SerializedName("optional")
    val optional: Boolean
)