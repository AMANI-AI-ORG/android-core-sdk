package ai.amani.sdk.modules.config.app

import ai.amani.base.util.SessionManager
import ai.amani.base.utility.AmaniVersion
import ai.amani.base.utility.AppConstants
import ai.amani.sdk.Amani
import datamanager.model.config.ResGetConfig
import datamanager.repomanager.config.Config
import datamanager.repomanager.config.IConfig
import datamanager.v2.repomanager.config.ConfigV2
import datamanager.v2.repomanager.config.IConfigV2
import io.reactivex.disposables.CompositeDisposable
import networkmanager.common.exception.ApiException
import networkmanager.common.exception.NoConnectivityException

/**
 * @Author: zekiamani
 * @Date: 1.07.2022
 */
object AppConfig: IAppConfig {

    private var disposable = CompositeDisposable()

    override fun getApplicationConfig(appConfigObserver: AppConfigObserver) {
        appConfigObserver.result(SessionManager.getAppConfig())
    }

    override fun fetchApplicationConfig(appConfigObserver: AppConfigObserver) {

        when(Amani.VERSION!!) {
            AmaniVersion.V1 -> {
                val iConfig: IConfig = Config()
                val subscribe =  iConfig.getConfig(
                    SessionManager.getCompanydId(),
                    AppConstants.TOKEN + SessionManager.getToken(),
                    SessionManager.getLanguage()
                ).subscribe(
                    { result: ResGetConfig ->
                        SessionManager.setStepConfig(result)
                        SessionManager.setGeneralConfig(result.generalConfigs)

                        appConfigObserver.result(result)
                    }
                ) { throwable: Throwable? ->
                    when (throwable) {
                        is ApiException -> {
                            appConfigObserver.result(
                                null,
                                throwable.erroCode
                            )
                        }
                        is NoConnectivityException -> {
                            appConfigObserver.result(
                                null,
                                10500) // Connectivity Exception
                        }
                        else -> appConfigObserver.result(null, 10600)
                    } // General Exception Exception
                }

                disposable.add(subscribe)
            }

            AmaniVersion.V2 -> {
                val iConfig: IConfigV2 = ConfigV2()
                val subscribe =  iConfig.getConfig(
                    id = SessionManager.getCompanydId(),
                    accessToken = AppConstants.BEARER + SessionManager.getToken(),
                    operationID = Amani.operationID
                )!!.subscribe(
                    { result: ResGetConfig? ->

                        if (result != null) {
                            SessionManager.setStepConfig(result)
                            SessionManager.setGeneralConfig(result.generalConfigs)
                        }

                        appConfigObserver.result(result)

                    }
                ) { throwable: Throwable? ->
                    when (throwable) {
                        is ApiException -> {
                            appConfigObserver.result(
                                null,
                                throwable.erroCode
                            )
                        }
                        is NoConnectivityException -> {
                            appConfigObserver.result(
                                null,
                                10500) // Connectivity Exception
                        }
                        else -> appConfigObserver.result(
                            null,
                            10600) //General Exception
                    }
                }

                disposable.add(subscribe)

            }
        }
    }
}