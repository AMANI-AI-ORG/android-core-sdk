package ai.amani.sdk.modules.signature

import ai.amani.base.logger.core.ActionTypes
import ai.amani.base.logger.local.AmaniLog
import ai.amani.base.logger.local.LogArea
import ai.amani.base.logger.local.LogFormat
import ai.amani.base.logger.util.OperationIdProvider
import ai.amani.base.util.AppPreferenceKey
import ai.amani.base.util.SessionManager
import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.model.amani_events.error.AmaniErrorTypes
import ai.amani.sdk.modules.amani_events.AmaniEvent
import ai.amani.sdk.modules.document_capture.camera.BitmapUtils
import ai.amani.sdk.modules.signature.interfaces.ISignature
import ai.amani.sdk.modules.signature.interfaces.ISignatureStartCallBack
import ai.amani.sdk.modules.signature.view.SignatureFragment
import ai.amani.sdk.service.upload.ErrorConstants
import android.content.Context
import android.graphics.BitmapFactory
import androidx.fragment.app.Fragment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class Signature: ISignature {
    private var numberOfSignatures = 0
    private var countOfSignature = 0
    private val signatureFragment = SignatureFragment()
    private var iSignatureStart: ISignatureStartCallBack? = null
    private var signatureList: ArrayList<String>? = ArrayList()
    private var docType = "XXX_SG_0"

    /**
     * Unique ID for each session start to end
     */
    var operationID : String = ""
        private set

    companion object {
        @Volatile
        private var mSignature: Signature? = null

        @JvmStatic
        @Synchronized
        fun sharedInstance(): Signature {
            if (mSignature == null) {
                synchronized(Signature){
                    mSignature = Signature()
                }
            }
            return mSignature!!
        }
    }

    /** @return: SignatureFragment
     *  @param numberOfSignatures       : Number of signature that will be taken.
     *  @param iSignatureStart          : A callback that returns with 2 parameter (bitmap , countOfSignatures:)
     */
    override fun start(context:Context, numberOfSignatures: Int, iSignatureStart: ISignatureStartCallBack): Fragment {
        this.numberOfSignatures = numberOfSignatures
        this.iSignatureStart = iSignatureStart
        // A new signature flow: its start, upload and verdict logs share this id. It was never
        // assigned before, so every signature log went out with a blank id and the backend
        // refused it (400 "operation_id: This field may not be blank").
        operationID = OperationIdProvider.startNew()
        AmaniLog.essential(LogArea.DOCUMENT) { "signature started count=$numberOfSignatures op=${LogFormat.op(operationID)}" }
        return signatureFragment
    }

    /** Upload function after requested Signatures are saved successfully.
     *  @param uploadCallBack           : A callback that returns 3 parameter of upload result (isSuccess, result, errors).
     */
    override fun upload( uploadCallBack: IUploadCallBack) {
       val callBack = AmaniEvent.observeUpload(uploadCallBack)
       // Both counts start at 0: without this check an upload pressed before any signature was taken
       // (start() never called, or nothing confirmed) passed as "all signatures taken" and reached
       // a fragment that had never been shown, which crashed the host.
       if (numberOfSignatures > 0 && numberOfSignatures == countOfSignature) {
           countOfSignature = 0 //Resetting count of Signature
           signatureFragment.upload(
               docType = docType,
               iUploadCallBack = callBack,
               operationID = operationID,
               actionType = ActionTypes.SIGNATURE_UPLOAD_RESP
           )
           signatureList = ArrayList() // Resetting signature after upload signature
       } else {
           callBack.cb(false)
           AmaniEvent.getEvent()?.onError(
               AmaniErrorTypes.SIGNATURE.name,
               arrayListOf(ErrorConstants.SIGNATURE_COUNT_ERROR)
           )
       }
    }

    /** Provides to clean canvas view of the Signature from SignatureFragment.
     */
    override fun clean() {
        cleanSignatureFromCanvas()
    }

    /** Provides to save ByteArray of Signature as File,
     *  to clean Signature from canvas if it's NOT last signature.
     */
    override fun confirm(context: Context) {
        val signatureAsByteArray = getSignatureFromCanvas()
        if (signatureAsByteArray != null) {
            countOfSignature += 1
            saveSignature(signatureAsByteArray, context)
            if (countOfSignature < numberOfSignatures) cleanSignatureFromCanvas() // If it's last signature; only save it, not clean signature from canvas.
        } else iSignatureStart!!.cb(null, countOfSignature)
    }

    /** reset the count of signature
     */
    override fun resetCountOfSignature() {
        countOfSignature = 0
    }

    /** It converts given byteArray to Bitmap, saves as file to disk, gets the path of file, keeps it as ArrayList and writes
     *  that ArrayList of saved data to SharedPref to use it in upload session.
     */
    private fun saveSignature(byteArray: ByteArray, context: Context) {
        CoroutineScope(Dispatchers.IO).launch {
            val bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            val savedSignatureFile: File? = BitmapUtils.saveBitmapAsFile(bitmap,
                "Signature"+ SessionManager.getCustomerId() + countOfSignature, context)
            signatureList!!.add(savedSignatureFile!!.absolutePath)
            SessionManager.addListString(signatureList, AppPreferenceKey.SIGNATURE_LIST)
            iSignatureStart!!.cb(bitmap,countOfSignature) // Returns callback after SignatureList is saved!
        }
    }

    private fun getSignatureFromCanvas(): ByteArray? {
        return signatureFragment.getSignatureFromView()
    }

    private fun cleanSignatureFromCanvas() {
        signatureFragment.cleanDigitalSignatureAtView()
    }
}