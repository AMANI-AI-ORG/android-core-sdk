package ai.amani.sdk.model

/**
 * How much the SDK writes to logcat (tag `AmaniCoreSDK`), set with `Amani.setLogLevel`.
 *
 * Without a choice the SDK follows the host app's build: a debuggable app gets [DEBUG], a release
 * app [ESSENTIAL]. Personal data, credentials and document data are never written at any level:
 * they show as `[hidden]`.
 */
enum class AmaniLogLevel {
    /** Nothing is written. */
    NONE,

    /** The main steps of a flow (session, capture, upload, verification result), warnings and errors. */
    ESSENTIAL,

    /** Also the details of each step, for development and support sessions. */
    DEBUG
}
