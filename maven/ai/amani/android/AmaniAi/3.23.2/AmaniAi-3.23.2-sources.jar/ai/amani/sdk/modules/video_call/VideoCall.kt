package ai.amani.sdk.modules.video_call

import ai.amani.base.util.SessionManager
import android.content.Intent
import androidx.core.net.toUri
import networkmanager.common.network.NetworkManagerClient

object VideoCall: IVideoCall {

    private var returnURL: String = "https://amani.ai"
    private var language: String = "tr"
    private var geoLocation: Boolean = true

    override fun returnURL(returnURL: String) = apply {
        this.returnURL = returnURL
    }
    override fun geoLocation(geoLocation: Boolean) = apply {
        this.geoLocation = geoLocation
    }

    override fun language(language: String) = apply {
        this.language = language
    }

    /** @return VideoCall intent
     */
    override fun start(): Intent {
      return generateIntent()
    }

    /**
     *  @param token AuthToken from SessionManager
     *  @param server BaseUrl from NetworkClient
     *  @return URL for VideoCall
     */
    private fun generateUrl(token: String, server: String): String {
        return "https://bclient.amani.ai/call/?tk=$token&rl=$returnURL&bu=$server&ln=$language&gl=$geoLocation"
    }

    /**
     *  @return Intent for video call
     *  Video call intent can be used only Chrome.
     */
    private fun generateIntent() :Intent{
        val intent = Intent(Intent.ACTION_VIEW, NetworkManagerClient.baseUrl?.let {
            generateUrl(
                SessionManager.getToken(),
                it
            )
        }?.toUri() ?: throw Exception("Intent creation exception"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        intent.setPackage("com.android.chrome")
        return intent
    }
}