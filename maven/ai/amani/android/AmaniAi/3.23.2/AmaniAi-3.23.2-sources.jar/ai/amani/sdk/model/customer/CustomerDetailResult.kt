package ai.amani.sdk.model.customer

import com.google.gson.annotations.SerializedName

/**
 * @Author: zekiamani
 * @Date: 28.11.2022
 */
data class CustomerDetailResult(
    @SerializedName("address")
    val address: Any?,
    @SerializedName("birthdate")
    val birthdate: String?,
    @SerializedName("email")
    val email: Any?,
    @SerializedName("gender")
    val gender: Any?,
    @SerializedName("id")
    val id: String?,
    @SerializedName("id_card_number")
    val idCardNumber: String?,
    @SerializedName("name")
    val name: String?,
    @SerializedName("nationality")
    val nationality: Any?,
    @SerializedName("occupation")
    val occupation: Any?,
    @SerializedName("phone")
    val phone: Any?,
    @SerializedName("photo")
    val photo: String?,
    @SerializedName("reject_reason")
    val rejectReason: Any?,
    @SerializedName("risk")
    val risk: String?,
    @SerializedName("rules")
    val rules: List<Rule>?,
    @SerializedName("status")
    val status: String?,
    @SerializedName("aml_status")
    val amlStatus: Boolean?,
    @SerializedName("verification_steps")
    val verificationSteps: List<String?>?,
    @SerializedName("missing_rules")
    val missingRules: List<MissingRule?>?,
    @SerializedName("email_verified")
    val emailVerified: Boolean? = false,
    @SerializedName("phone_verified")
    val phoneVerified: Boolean? = false,
    @SerializedName("biopay_enabled")
    val bioMatchEnabled: Boolean? = null,
    @SerializedName("terms_accepted_at")
    val termsAcceptedAt: String? = null
)
