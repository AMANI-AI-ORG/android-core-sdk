package ai.amani.sdk.modules.document.view

import ai.amani.R
import ai.amani.base.camera.CameraXLogging
import ai.amani.base.logger.local.AmaniLog
import ai.amani.base.logger.local.LogArea
import ai.amani.base.util.AppPreferenceKey
import ai.amani.base.util.PermissionHandler
import ai.amani.base.util.SessionManager
import ai.amani.base.utility.AppConstants
import ai.amani.base.view.BaseFragment
import ai.amani.databinding.FragmentDocumentBinding
import ai.amani.lib_image_cropper.CropImageView
import ai.amani.sdk.modules.document.DocBuilder
import ai.amani.sdk.modules.document.interfaces.IDocumentCallBack
import ai.amani.sdk.modules.document_capture.camera.BitmapUtils
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.lifecycleScope
import datamanager.model.config.Step
import datamanager.model.config.Version
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class DocumentFragment : BaseFragment(), PermissionHandler.PermissionHandleCallback {

    lateinit var mBinding: FragmentDocumentBinding
    var mContext: Activity? = null
    var mStep: Step? = null
    var mToolTittle: String? = null
    var mVersion: Version? = null
    var documentCallBack: IDocumentCallBack? = null
    var mCameraType = 0
    var id: Int? = null
    private var mPermissionHandler: PermissionHandler? = null

    /** Modern ActivityResult-based permission launcher; replaces the deprecated APIs. */
    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        mPermissionHandler?.handleResult(results)
    }

    /**
     * Once the camera is bound we stop re-running the permission flow on every resume.
     * Required because [onResume] used to call [handlePermission] unconditionally — that
     * caused the permission-denied alert to fire on every resume when an auxiliary
     * permission (e.g. location) wasn't granted, even though the camera itself was OK.
     */
    private var cameraStarted = false
    var mHeight = 0
    var mWidth = 0
    var mView: View? = null
    var bitmap: Bitmap? = null
    var docList: ArrayList<String>? = ArrayList()

    // Custom Builder
    private var docBuilder: DocBuilder? = null

    //CameraX
    private lateinit var cameraProvider: ProcessCameraProvider

    companion object {
        private const val REQUEST_CAMERA_PERMISSION = 200
        private var mDocumentCount = 0
    }

    override fun getContentView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_document, container, false)
        return mBinding.root
    }

    override fun initLayout(view: View) {
        mView = view
        mContext = activity
        val hideLogo = if (SessionManager.getGeneralConfig()?.hideLogo != null) SessionManager.getGeneralConfig()?.hideLogo else false
        val imageViewLogo = view.findViewById<ImageView>(R.id.image_view_powered)
        /*if (hideLogo) {
            imageViewLogo.visibility = View.GONE
        } else imageViewLogo.setColorFilter(Color.parseColor(color))*/
        mBinding.manualCaptureBttn.setColorFilter(Color.parseColor(SessionManager.getGeneralConfig()?.primaryButtonBackgroundColor))

        val geoLocation = SessionManager.getGeoLocation()
        mPermissionHandler = PermissionHandler.init(
            requireActivity(),
            this,
            geoLocation
        )

        bundle
        setUI()
        mBinding.manualCaptureBttn.setOnClickListener {
            bitmap = mBinding.cameraPreview.bitmap
            AmaniLog.d(LogArea.DOCUMENT) { "document capture taken mode=manual page=${mDocumentCount + 1} ok=${bitmap != null}" }
            invisibleCamera()
            bitmap?.let {
                setBitmapToCrop(it)
            }
        }

        mBinding.tryAgain.setOnClickListener {
            visibleCamera()
        }

        mBinding.confirm.setOnClickListener {
            val croppedBm = getCroppedBitmap()
            // Capture the activity up front; the save runs asynchronously and must
            // not rely on mContext!! still being non-null when the write finishes.
            val activity = mContext ?: return@setOnClickListener

            // Saving is now off the UI thread, so guard against double-taps by
            // disabling the button until the save either completes or fails.
            mBinding.confirm.isEnabled = false

            // JPEG compression + disk write used to run inside runBlocking on the
            // UI thread, freezing the app on large images / slow storage and
            // tripping the ANR watchdog. Do the I/O on Dispatchers.IO and only
            // touch the UI back on Main.
            viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                val nextCount = mDocumentCount + 1
                val savedDocumentFile: File? = BitmapUtils.saveBitmapAsFile(
                    croppedBm,
                    "Document" + SessionManager.getCustomerId() + nextCount,
                    activity
                )

                if (savedDocumentFile == null) {
                    // Save failed: surface a retryable error instead of crashing
                    // the host app with an NPE, and do not advance the flow.
                    AmaniLog.e(LogArea.DOCUMENT) { "document save failed page=$nextCount" }
                    withContext(Dispatchers.Main) {
                        mBinding.confirm.isEnabled = true
                    }
                    return@launch
                }

                mDocumentCount = nextCount
                docList?.add(savedDocumentFile.absolutePath)
                SessionManager.addListString(docList, AppPreferenceKey.DOCUMENT_LIST)

                withContext(Dispatchers.Main) {
                    mBinding.confirm.isEnabled = true
                    val requiredCount = docBuilder?.documentCount?.toInt() ?: mDocumentCount
                    if (mDocumentCount < requiredCount) {
                        visibleCamera()
                    } else {
                        docList?.let { documentCallBack?.cb(it, true) }
                    }
                }
            }
        }
    }

    private val bundle: Unit
        get() {
            val appFontColor = if (SessionManager.getGeneralConfig().appFontColor != null) SessionManager.getGeneralConfig().appFontColor else AppConstants.COLOR_BLACK
            val appBackgroundColor = if (SessionManager.getGeneralConfig().appBackground != null) SessionManager.getAppBackground() else AppConstants.COLOR_WHITE
            mBinding.parentImageCapture.setBackgroundColor(Color.parseColor(appBackgroundColor))
            val bundle = arguments
            if (bundle != null) {
                mWidth = bundle.getInt(AppConstants.FRAME_LAYOUT_WIDTH)
                mHeight = bundle.getInt(AppConstants.FRAME_LAYOUT_HEIGHT)
                id = bundle.getInt(AppConstants.KEY_STEP_CONFIG_ID)
                mVersion = bundle.getParcelable(AppConstants.KEY_VERSION_LIST)
                docBuilder = bundle.getParcelable(AppConstants.DOC_BUILDER)!!
                if (mVersion != null) mStep = mVersion!!.steps[0]
            }
            handlePermission()
        }


    /**
     *  set custom UserInterface
     */
    private fun setUI() {
        mBinding.confirm.text = docBuilder!!.confirmText
        mBinding.tryAgain.text = docBuilder!!.tryAgainText
        mBinding.confirm.setTextColor(ContextCompat.getColor(
                mContext!!,
                docBuilder!!.confirmTextColor!!
        ))
        mBinding.tryAgain.setTextColor(ContextCompat.getColor(
                mContext!!,
                docBuilder!!.tryAgainTextColor!!))
        mBinding.manualCaptureBttn.setColorFilter(ContextCompat.getColor(
                mContext!!,
                docBuilder!!.captureButtonColor!!))
    }

    /**
     * handle permission
     */
    private fun handlePermission() {
        mPermissionHandler!!.requestPermission(permissionLauncher)
    }

    private fun startCamera() {
        CameraXLogging.quiet(mContext)
        val cameraProviderFuture = ProcessCameraProvider.getInstance(mContext!!)

        cameraProviderFuture.addListener({

            // Used to bind the lifecycle of cameras to the lifecycle owner
            cameraProvider = cameraProviderFuture.get()

            // Preview
            val preview = Preview.Builder()
                    .build()
                    .also {
                        it.setSurfaceProvider(mBinding.cameraPreview.surfaceProvider)
                    }

            // Select back camera as a default
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                // Unbind use cases before rebinding
                cameraProvider.unbindAll()

                // Bind use cases to camera
                cameraProvider.bindToLifecycle(this, cameraSelector, preview)

            } catch (exc: Exception) {
                AmaniLog.e(LogArea.DOCUMENT, exc) { "camera bind failed" }
            }

        }, ContextCompat.getMainExecutor(mContext!!))
    }

    override fun permissionGranted(permission: List<String>?) {
        if (cameraStarted) return
        cameraStarted = true
        startCamera()
    }

    override fun permissionDenied(permissionList: List<String>?) {
        if (permissionList == null) return

        val okTxt = if (SessionManager.getGeneralConfig().okText != null) SessionManager.getGeneralConfig().okText else resources.getString(R.string.confirm)
        val permissionDeniedTxt = if (SessionManager.getGeneralConfig().permissionDeniedText != null) SessionManager.getGeneralConfig().permissionDeniedText else resources.getString(R.string.permission_denied)
        val changePermissionTxt = if (SessionManager.getGeneralConfig().changePermissionText != null) SessionManager.getGeneralConfig().changePermissionText else resources.getString(R.string.please_change_permission_settings)

        showAlert(permissionDeniedTxt, changePermissionTxt, okTxt,"" , object : ActionCallback {
            override fun onPositiveBtnClick() {
                mPermissionHandler!!.retryOrOpenSettings(permissionLauncher)
            }

            override fun onNegativeBtnClick() {
                popBackStack()
            }
        })
    }

    private fun visibleCamera() {
        mBinding.cameraPreview.visibility = View.VISIBLE
        mBinding.manualCaptureBttn.visibility = View.VISIBLE
        mBinding.polygonView.visibility = View.INVISIBLE
        mBinding.tryAgain.visibility = View.INVISIBLE
        mBinding.confirm.visibility = View.INVISIBLE
    }

    private fun invisibleCamera() {
        mBinding.cameraPreview.visibility = View.INVISIBLE
        mBinding.manualCaptureBttn.visibility = View.INVISIBLE
        mBinding.polygonView.visibility = View.VISIBLE
        mBinding.tryAgain.visibility = View.VISIBLE
        mBinding.confirm.visibility = View.VISIBLE

    }

    private fun setBitmapToCrop(bitmap: Bitmap) {
        mBinding.polygonView.cropShape = CropImageView.CropShape.RECTANGLE
        mBinding.polygonView.setImageBitmap(bitmap)
        mBinding.polygonView.scaleType = CropImageView.ScaleType.CENTER_INSIDE
        mBinding.polygonView.visibility = View.VISIBLE
    }

    private fun getCroppedBitmap(): Bitmap {
        return mBinding.polygonView.croppedImage
    }

    private fun mStopCamera() {
        try {
            cameraProvider.unbindAll()
        } catch (e: Exception) {
        }
    }

    override fun onPause() {
        super.onPause()
        mStopCamera()
        // Allow re-bind on next resume; permission flow itself is not re-run.
        cameraStarted = false
    }

    override fun onResume() {
        super.onResume()
        visibleCamera()
        // Skip the permission dialog flow if we already have what we need. The
        // launcher fires permissionDenied for any missing optional permission
        // (e.g. location) which used to cause an alert on every resume.
        if (mPermissionHandler?.hasPermission(activity) == true ||
            ContextCompat.checkSelfPermission(
                requireContext(),
                android.Manifest.permission.CAMERA
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            if (!cameraStarted) {
                cameraStarted = true
                startCamera()
            }
        } else {
            handlePermission()
        }
    }

}