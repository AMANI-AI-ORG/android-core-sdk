package ai.amani.sdk.modules.selfie.pose_estimation.model

data class DeviceOrientationState (var deviceOrientation: DeviceOrientation)

enum class DeviceOrientation{
    UNSUPPORTED,
    AVAILABLE,
    NOT_AVAILABLE
}
