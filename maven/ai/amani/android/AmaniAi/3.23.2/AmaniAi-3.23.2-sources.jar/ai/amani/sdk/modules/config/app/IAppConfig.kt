package ai.amani.sdk.modules.config.app

import datamanager.model.config.GeneralConfigs
import datamanager.model.config.ResGetConfig

/**
 * @Author: zekiamani
 * @Date: 1.07.2022
 */
interface IAppConfig {

    /** @return the local saved model data*/
    fun getApplicationConfig(appConfigObserver: AppConfigObserver)

    /** @return the up to date remote model data*/
    fun fetchApplicationConfig(appConfigObserver: AppConfigObserver)
}

interface AppConfigObserver{
    fun result(applicationConfig: ResGetConfig?, errorCode: Int? = null)
}