package ai.amani.sdk.modules.selfie.pose_estimation.model

enum class HeadPose {
    RIGHT,
    LEFT,
    UP,
    DOWN,
    NOT_FOUND,
    FACE_NOT_INSIDE,
    FACE_NOT_STRAIGHT,
    FACE_TOO_FAR,
    FACE_TOO_CLOSE,
    FACE_AVAILABLE_FOR_AUTO_SELFIE,
    FACE_AVAILABLE_FOR_POSE_ESTIMATION,
    EYES_CLOSED,
    STRAIGHT
}