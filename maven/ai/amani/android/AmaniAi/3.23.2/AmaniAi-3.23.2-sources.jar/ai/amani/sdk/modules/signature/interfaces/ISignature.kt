package ai.amani.sdk.modules.signature.interfaces

import ai.amani.sdk.interfaces.IUploadCallBack
import android.content.Context
import androidx.fragment.app.Fragment

interface ISignature {
    fun start (context: Context,numberOfSignatures: Int,iSignatureStart: ISignatureStartCallBack):Fragment

    fun upload (uploadCallBack: IUploadCallBack)

    fun clean ()

    fun confirm (context: Context)

    fun resetCountOfSignature()

}