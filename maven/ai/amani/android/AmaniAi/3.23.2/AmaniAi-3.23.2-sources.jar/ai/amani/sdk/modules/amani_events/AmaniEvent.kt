package ai.amani.sdk.modules.amani_events

import ai.amani.base.logger.core.ActionTypes
import ai.amani.base.logger.local.AmaniLog
import ai.amani.base.logger.local.LogArea
import ai.amani.base.logger.local.LogFormat
import ai.amani.base.util.toObject
import ai.amani.base.utility.AmaniVersion
import ai.amani.sdk.Amani
import ai.amani.sdk.interfaces.AmaniEventCallBack
import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.model.amani_events.error.AmaniError
import ai.amani.sdk.model.amani_events.profile_status.ProfileStatus
import ai.amani.sdk.model.amani_events.steps_result.Errors
import ai.amani.sdk.model.amani_events.steps_result.Result
import ai.amani.sdk.model.amani_events.steps_result.StepsResult
import datamanager.v2.model.socket.profile_status.ProfileStatusSocketModel
import datamanager.v2.model.socket.step.StepResultSocketModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import networkmanager.v2.MessageListener
import networkmanager.v2.SseDiagnostics
import networkmanager.v2.SseManager
import networkmanager.v2.SseStatusCode
import org.json.JSONObject

/**
 * @Author: zekiamani
 * @Date: 11.11.2022
 */
object AmaniEvent : IAmaniEvent {

    const val STEP_RESULT_PARSE_ERROR = "STEP_RESULT_PARSE"
    private const val STEP_RESULT_PARSE_ERROR_CODE = 10701

    /**
     * Frame types that are handled by someone else, or ignored here on purpose. The backend sends
     * `classification_result` with every upload; the SDK has no use for it, and it is not news.
     */
    private const val CLASSIFICATION_RESULT = "classification_result"
    private val HANDLED_ELSEWHERE =
        setOf(SseManager.MRZ_RESULT, SseManager.VALIDATION_RESULT, CLASSIFICATION_RESULT)
    private const val MAX_REPORTED_TYPE_CHARS = 40
    private var event: AmaniEventCallBack? = null

    @JvmStatic
    fun getEvent(): AmaniEventCallBack? = event

    override fun setListener(event: AmaniEventCallBack) {
        AmaniEvent.event = MainThreadAmaniEventCallBack(event)
        AmaniLog.d(LogArea.EVENT) { "host event listener set (api ${Amani.VERSION})" }

        when(Amani.VERSION) {
            AmaniVersion.V1 -> {

            }

            AmaniVersion.V2 -> {
                // A callback that has just been attached has been handed nothing. What the SDK
                // remembers as delivered went to the previous callback (or to none), and treating
                // it as delivered here would hide the state snapshot from the new one.
                forgetDelivered()
                setSocketListener()
                pushCurrentState()
            }
        }
    }

    /** Forgets what was delivered so the next snapshot or recovery reaches the current callback. */
    internal fun forgetDelivered() {
        MissedVerdictSync.reset()
        resetDelivered()
    }

    /**
     * Hands a newly attached callback the current step statuses, once. A callback that is set
     * after the stream's own state snapshot has already gone by would otherwise have to wait for
     * the next event to learn anything. When the stream is not open yet, the first open does it.
     */
    private fun pushCurrentState() {
        if (!SseManager.sharedInstance().isStreamOpen()) return
        MissedVerdictSync.recoverMissedVerdicts()
    }

    override fun removeListener() {
        event = null
    }

    private fun setSocketListener() {
        // The transport counts the connections and calls this back only on a RE-connection, so
        // re-installing the listener (every screen that re-attaches its callback does) cannot
        // blind the recovery.
        SseManager.sharedInstance().setStreamRecoveryListener {
            MissedVerdictSync.recoverMissedVerdicts()
        }
        // The login callback returns before the stream is open: a verdict produced in between
        // would never be sent, so the first open pulls the current state too.
        SseManager.sharedInstance().setInitialOpenListener {
            MissedVerdictSync.recoverMissedVerdicts(onlyChanged = true)
        }

        // An accepted upload makes its verdict news even if it repeats the last status.
        SseManager.sharedInstance().setUploadAcceptedListener {
            MissedVerdictSync.expectNewVerdict()
        }

        // An upload was accepted and no event came back: read the statuses directly, so a stream
        // that is dead or late does not leave the screen waiting.
        SseManager.sharedInstance().setVerdictPollListener {
            MissedVerdictSync.recoverMissedVerdicts(onlyChanged = true, viaPoll = true)
        }
        // A read that finds nothing left in flight ends the wait for a verdict.
        MissedVerdictSync.onNothingProcessing = {
            SseManager.sharedInstance().onNothingProcessing()
        }

        SseManager.sharedInstance().setListener(object : MessageListener {
            override fun onConnectSuccess() {
                AmaniLog.d(LogArea.EVENT) { "host notified: stream connected" }
            }

            override fun onConnectFailed() {
                AmaniLog.d(LogArea.EVENT) { "host notified: stream failed" }
            }

            override fun onClose() {
                AmaniLog.d(LogArea.EVENT) { "host notified: stream closed" }
            }

            override fun onMessage(text: String?) {
                if (text == null) return
                dispatchFrame(text)
            }
        })
    }

    /**
     * Wraps the callback of ONE upload. Its answer reaches the host unchanged; only when that answer
     * is a failure does the event listener also get the current step statuses, once, without
     * waiting for the event stream. A failed upload produces no verdict, so a host that already
     * shows the step as in progress would otherwise wait on the event listener for good. Every
     * module's upload method passes its callback through here; a new upload is a new wrapper.
     */
    internal fun observeUpload(callback: IUploadCallBack): IUploadCallBack =
        callback as? UploadResultObserver ?: UploadResultObserver(callback)

    /** A failed upload: hands the event listener the current statuses once, off the caller's thread. */
    private fun onUploadFailed() {
        // No live session (never logged in, or finished): there is nothing to read. Whether anyone
        // listens and whether this is the streaming version is checked by the read itself.
        if (!SseManager.sharedInstance().isPrepared()) return
        AmaniLog.d(LogArea.EVENT) { "upload failed, reading the current step statuses for the host" }
        uploadScope.launch { MissedVerdictSync.deliverAfterFailedUpload() }
    }

    private val uploadScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private class UploadResultObserver(private val delegate: IUploadCallBack) : IUploadCallBack {

        private val failureHandled = java.util.concurrent.atomic.AtomicBoolean(false)

        override fun cb(isSuccess: Boolean) {
            delegate.cb(isSuccess)
            handleFailure(isSuccess)
        }

        override fun cb(isSuccess: Boolean, documentID: String?) {
            delegate.cb(isSuccess, documentID)
            handleFailure(isSuccess)
        }

        private fun handleFailure(isSuccess: Boolean) {
            if (!isSuccess && failureHandled.compareAndSet(false, true)) runCatching { onUploadFailed() }
        }
    }

    /** How long after a stream opens the server's state snapshot is expected. */
    private const val SNAPSHOT_WINDOW_MS = 5_000L

    /** Time since the stream opened; a seam so tests need no connection. */
    @androidx.annotation.VisibleForTesting
    internal var msSinceStreamOpen: () -> Long = { SseManager.sharedInstance().msSinceOpen() }

    /** The last profile status that reached the host, to spot a repeated snapshot. */
    @Volatile
    private var lastProfileStatus: ProfileStatus? = null

    @androidx.annotation.VisibleForTesting
    internal fun resetDelivered() {
        lastProfileStatus = null
    }

    /**
     * Turns one stream frame into the matching callback.
     *
     * Network payloads are never trusted to be well formed: a malformed or partial frame must not
     * throw inside the stream reader, where it would tear the stream down (or crash the host)
     * instead of being skipped. A frame that is dropped for its shape is reported through
     * `onError`, so the integrator is not left waiting on a verdict that was thrown away.
     */
    @androidx.annotation.VisibleForTesting
    internal fun dispatchFrame(text: String, target: AmaniEventCallBack? = event) {
        val type: String = try {
            JSONObject(text).getString("type")
        } catch (e: Exception) {
            AmaniLog.d(LogArea.EVENT) { "unreadable event skipped" }
            // Nothing of the frame is kept, only that one arrived and its size: a stream that
            // delivers bytes nobody can read (compressed, rewritten by a proxy) looks, from the
            // host, exactly like a stream that delivers nothing.
            SseDiagnostics.report(
                ActionTypes.SSE_FRAME_DROPPED,
                "An event frame is not valid JSON or has no type",
                mapOf("length" to text.length),
                e,
                statusCode = SseStatusCode.FRAME_NOT_JSON
            )
            return
        }

        if (target == null) return

        try {
            when (type) {
                SseManager.PROFILE_STATUS -> {
                    val profileStatus = text.toObject<ProfileStatusSocketModel>()
                    val status = ProfileStatus(
                        profile = profileStatus.profile,
                        amlStatus = profileStatus.message!!.amlStatus,
                        risk = profileStatus.message.risk.toString(),
                        status = profileStatus.message.status
                    )
                    // A state snapshot the host already has is not news.
                    if (msSinceStreamOpen() < SNAPSHOT_WINDOW_MS && status == lastProfileStatus) return
                    lastProfileStatus = status
                    AmaniLog.essential(LogArea.EVENT) { "profile status ${status.status} (from the stream)" }
                    target.profileStatus(status)
                }

                SseManager.STEP_RESULT -> {
                    val model = text.toObject<StepResultSocketModel>()
                    val results = arrayListOf<Result>()
                    var skipped = 0
                    model.message.orEmpty().forEach { message ->
                        // One damaged step must not take the verdicts of the others with it.
                        val result = message?.let { runCatching { it.toResult() }.getOrNull() }
                        if (result == null) skipped++ else results.add(result)
                    }

                    if (skipped > 0) reportDroppedStep(target, skipped)

                    // A status the direct read already handed over must not reach the host twice.
                    val fresh = results.filterNot { MissedVerdictSync.consumeDuplicate(it) }
                    // The same goes for a snapshot after a re-open that changes nothing.
                    val unchangedSnapshot = msSinceStreamOpen() < SNAPSHOT_WINDOW_MS &&
                        results.isNotEmpty() && results.all { MissedVerdictSync.isUnchanged(it) }
                    MissedVerdictSync.record(results)
                    if (unchangedSnapshot) return
                    if (fresh.isEmpty() && results.isNotEmpty()) return
                    AmaniLog.essential(LogArea.EVENT) { "step status ${LogFormat.steps(fresh)} (from the stream)" }
                    target.stepsResult(StepsResult(ArrayList(fresh)))
                }

                // The MRZ result is routed by the transport; anything else is a kind of event this
                // version does not know, which usually means the backend moved ahead of the SDK.
                !in HANDLED_ELSEWHERE -> SseDiagnostics.report(
                    ActionTypes.SSE_FRAME_DROPPED,
                    "An event frame of an unknown type was ignored",
                    mapOf("type" to type.take(MAX_REPORTED_TYPE_CHARS)),
                    statusCode = SseStatusCode.FRAME_UNKNOWN_TYPE
                )
            }
        } catch (e: Exception) {
            AmaniLog.d(LogArea.EVENT) { "event of type $type could not be read: ${e.javaClass.simpleName}" }
            if (type == SseManager.STEP_RESULT) reportDroppedStep(target, null)
            else SseDiagnostics.report(
                ActionTypes.SSE_FRAME_DROPPED,
                "A profile status frame could not be read",
                emptyMap(),
                e,
                statusCode = SseStatusCode.FRAME_UNREADABLE
            )
        }
    }

    private fun datamanager.v2.model.socket.step.Message.toResult() = Result(
        id = id,
        status = status,
        sortOrder = sortOrder,
        errors = errors?.mapNotNull { it.toErrorOrNull() },
        title = title,
        // One default for every source of a step result, the stream and the recovery alike.
        uploadSource = uploadSource ?: MissedVerdictSync.uploadSourceProvider(),
        documentId = document,
        optional = optional
    )

    /** Reads one raw error entry; an entry of an unexpected shape is skipped, not fatal. */
    private fun Any?.toErrorOrNull(): Errors? {
        val entry = this as? Map<*, *> ?: return null
        return Errors(
            errorCode = (entry["error_code"] as? Number)?.toInt(),
            errorMessage = entry["error_message"]
        )
    }

    private fun reportDroppedStep(target: AmaniEventCallBack, count: Int?) {
        SseDiagnostics.report(
            ActionTypes.SSE_FRAME_DROPPED,
            if (count == null) "A step result frame could not be read"
            else "$count step result entries could not be read and were skipped",
            mapOf("skippedEntries" to count),
            statusCode = if (count == null) SseStatusCode.FRAME_UNREADABLE else SseStatusCode.FRAME_STEPS_SKIPPED
        )
        target.onError(
            type = STEP_RESULT_PARSE_ERROR,
            error = arrayListOf(
                AmaniError(
                    errorCode = STEP_RESULT_PARSE_ERROR_CODE,
                    errorMessage = if (count == null) "A step result frame could not be read"
                    else "$count step result entries could not be read and were skipped"
                )
            )
        )
    }

}

/**
 * Delivers every [AmaniEventCallBack] invocation on the main thread so integrators can perform
 * host-app UI work directly inside the callbacks.
 */
private class MainThreadAmaniEventCallBack(
    private val delegate: AmaniEventCallBack
) : AmaniEventCallBack {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun profileStatus(profileStatus: ProfileStatus) {
        scope.launch { delegate.profileStatus(profileStatus) }
    }

    override fun stepsResult(stepsResult: StepsResult?) {
        scope.launch { delegate.stepsResult(stepsResult) }
    }

    override fun onError(type: String?, error: ArrayList<AmaniError?>?) {
        scope.launch { delegate.onError(type, error) }
    }
}
