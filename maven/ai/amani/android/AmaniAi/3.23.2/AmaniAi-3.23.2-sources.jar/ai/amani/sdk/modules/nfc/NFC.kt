package ai.amani.sdk.modules.nfc

import ai.amani.base.logger.local.AmaniLog
import ai.amani.base.logger.local.LogArea
import ai.amani.base.logger.local.LogFormat
import ai.amani.sdk.modules.amani_events.AmaniEvent
import ai.amani.base.logger.core.ActionTypes
import ai.amani.base.logger.impl.AmaniLogger
import ai.amani.base.logger.util.OperationIdProvider
import ai.amani.base.util.SessionManager
import ai.amani.sdk.Amani
import ai.amani.sdk.interfaces.INfcCallBack
import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.interfaces.NfcResultCallBack
import ai.amani.sdk.model.mrz.MRZResult
import ai.amani.sdk.modules.document_capture.IDCapture
import ai.amani.sdk.modules.document_capture.mrz.GetMRZ
import ai.amani.sdk.modules.nfc.start.NFCStart
import ai.amani.sdk.modules.nfc.upload.UploadNFC
import android.content.Context
import android.graphics.Bitmap
import android.nfc.Tag
import androidx.fragment.app.FragmentActivity

object NFC {
    private var callBackNFC: INfcCallBack? = null
    private var callBackU: IUploadCallBack? = null

    /**
     * Unique ID for each session start to end
     */
    var operationID : String = ""
        private set

    fun start(
        tag: Tag,
        applicationContext: Context,
        birthDate: String,
        expireDate: String,
        documentNumber: String,
        callBack: INfcCallBack?
    ) {
        //If IDCapture module already generated an operation ID, NFC module operation should be same,
        //If NFC module independently called (independent from IDCapture) NFC operation must regenerated
        operationID = if (IDCapture.operationID != "") IDCapture.operationID
        else OperationIdProvider.startNew()
        AmaniLog.essential(LogArea.NFC) { "NFC scan started source=chip_tag op=${LogFormat.op(operationID)}" }

        callBackNFC = callBack

        val validFormat = ValidFormat()
        if (validFormat.isValid(birthDate, expireDate, documentNumber)) {
            AmaniLogger.get().log(
                operationID = Amani.ScanNFC().operationID,
                actionType = ActionTypes.ID_CAPTURE_START_NFC
            )
            nfc(
                tag,
                applicationContext,
                birthDate,
                expireDate,
                documentNumber
            )
        } else {
            AmaniLog.e(LogArea.NFC) {
                "❌ NFC scan not started reason=invalid_document_data dateFormat=yyMMdd op=${LogFormat.op(operationID)}"
            }
            // The values themselves only in the SDK's own debug build.
            AmaniLog.v(LogArea.NFC) { "invalid document data expiry=$expireDate birth=$birthDate document=$documentNumber" }
            callBackNFC!!.cb(null, false, "NVI format is invalid")
        }
    }

    /** Please be sure that you are using this functions at scenarios which you have the MRZ field
     * of the image.Otherwise NFC will be failed.
     *
     * MRZ fields generally existing on the back side of the ID.
     *
     * @param tag : NFC Tag
     * @param applicationContext : Required context of activity
     * @param image : Back side of the document that contains MRZ field.
     * @param callBack
     */
    fun start(
        tag: Tag,
        applicationContext: Context,
        docType: String?,
        image: Bitmap?,
        callBack: INfcCallBack?
    ) {
        /*val assetDownloaded = DynamicFeatureManager.instance().checker().checkItIsDownloadedCorrectly(
            DynamicFeature.NFC_SCAN
        )

        if (!assetDownloaded) {
            AmaniEvent.getEvent()?.onError(
                type = docType.asAmaniEventType(),
                error = arrayListOf(ErrorConstants.DYNAMIC_FEATURE_ASSET_NOT_FOUND)
            )
            return
        }*/

        operationID = OperationIdProvider.startNew()
        AmaniLog.essential(LogArea.NFC) { "NFC scan started source=mrz_image docType=$docType op=${LogFormat.op(operationID)}" }
        callBackNFC = callBack
        GetMRZ().requestMRZ(
            image,
            docType!!,
            { mrz: MRZResult ->
                nfc(
                    tag,
                    applicationContext,
                    mrz.mRZBirthDate,
                    mrz.mRZExpiryDate,
                    mrz.mRZDocumentNumber
                )
            }
        ) {
            AmaniLog.e(LogArea.NFC) { "❌ NFC scan not started reason=mrz_not_read op=${LogFormat.op(operationID)}" }
            callBackNFC!!.cb(null, false, "MRZ request failed")
        }
    }

    fun start(
        tag: Tag,
        context: Context,
        birthDate: String,
        expireDate: String,
        documentNumber: String,
        callBack: NfcResultCallBack
    ){
        operationID = OperationIdProvider.startNew()
        AmaniLog.essential(LogArea.NFC) { "NFC scan started source=host_data op=${LogFormat.op(operationID)}" }
        SessionManager.setBirthDate(birthDate)
        SessionManager.setDocumentNo(documentNumber)
        SessionManager.setExpireDate(expireDate)
        val nfcStart = NFCStart()
        nfcStart.nfcCallBackNew = callBack
        AmaniLogger.get().log(
            operationID = Amani.ScanNFC().operationID,
            actionType = ActionTypes.ID_CAPTURE_START_NFC
        )
        nfcStart.nfcAuth(tag, context)
    }

    fun upload(activity: FragmentActivity, docType: String, callBack: IUploadCallBack?) {
        callBackU = callBack?.let { AmaniEvent.observeUpload(it) }
        uploadNFC(activity, docType)
    }

    private fun nfc(
        tag: Tag,
        applicationContext: Context,
        birthDate: String?,
        expireDate: String?,
        documentNumber: String?
    ) {
        SessionManager.setBirthDate(birthDate)
        SessionManager.setDocumentNo(documentNumber)
        SessionManager.setExpireDate(expireDate)
        val nfcStart = NFCStart()
        nfcStart.nfcCallBack = callBackNFC
        AmaniLogger.get().log(
            operationID = Amani.ScanNFC().operationID,
            actionType = ActionTypes.ID_CAPTURE_START_NFC
        )
        nfcStart.nfcAuth(tag, applicationContext)
    }

    private fun uploadNFC(activity: FragmentActivity, docType: String) {
        val uploadNFC = UploadNFC(activity)
        uploadNFC.uploadNFC(
            docType = docType,
            callBack = callBackU!!,
            operationID = operationID,
            actionType = ActionTypes.NFC_UPLOAD_RESP
        )
    }
}