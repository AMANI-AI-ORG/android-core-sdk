package ai.amani.sdk.modules.config.country

import ai.amani.base.util.SessionManager
import ai.amani.base.utility.AmaniVersion
import ai.amani.base.utility.AppConstants
import ai.amani.sdk.Amani
import datamanager.repomanager.digitalcontract.DContractImp
import datamanager.v2.repomanager.digital_contract.DContractImpV2
import io.reactivex.disposables.CompositeDisposable

/**
 * @Author: zekiamani
 * @Date: 4.07.2022
 */
object CountryList : ICountryList {

    private var disposable = CompositeDisposable()

    override fun getCountryList(observer: CountryListObserver) {

        when (Amani.VERSION!!) {

            AmaniVersion.V1 -> {
                val countryListFetch = DContractImp().getCountries(
                    AppConstants.TOKEN + SessionManager.getToken(),
                    SessionManager.getLanguage()
                ).subscribe(

                    {
                        observer.result(it)
                    },

                    {
                        observer.result(null, it)
                    })

                disposable.add(countryListFetch)
            }

            AmaniVersion.V2 -> {
                val countryListFetch = DContractImpV2().getCountries(
                    AppConstants.BEARER + SessionManager.getToken(),
                    SessionManager.getLanguage()
                )!!.subscribe({
                    observer.result(it)
                },
                    {
                        observer.result(null, it)
                    })

                disposable.add(countryListFetch)
            }
        }
    }
}