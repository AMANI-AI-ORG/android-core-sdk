package ai.amani.sdk.modules.selfie.pose_estimation.model

data class CurrentAnimation(
    val visibility: Boolean,
    val name: String
)
