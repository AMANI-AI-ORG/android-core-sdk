package ai.amani.sdk.interfaces

import ai.amani.sdk.model.amani_events.error.AmaniError
import ai.amani.sdk.model.amani_events.profile_status.ProfileStatus
import ai.amani.sdk.model.amani_events.steps_result.StepsResult

/**
 * All callbacks are invoked on the main thread, so host-app UI work can be done directly inside them.
 *
 * @Author: zekiamani
 * @Date: 11.11.2022
 */
interface AmaniEventCallBack {

    fun profileStatus(profileStatus: ProfileStatus)

    fun stepsResult(stepsResult: StepsResult?)

    fun onError(type: String? = null, error: ArrayList<AmaniError?>?)
}


