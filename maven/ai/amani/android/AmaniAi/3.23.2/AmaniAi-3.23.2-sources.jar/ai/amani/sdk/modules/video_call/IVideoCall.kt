package ai.amani.sdk.modules.video_call

import android.content.Intent

interface IVideoCall {

    fun returnURL(returnURL: String): VideoCall

    fun geoLocation(geoLocation: Boolean): VideoCall

    fun language(language: String): VideoCall
    fun start() : Intent
}