package ai.amani.sdk.modules.questionnaire

import ai.amani.sdk.model.questionnaire.QuestionnaireModel
import ai.amani.sdk.model.questionnaire.SubmitAnswer
import datamanager.v2.repomanager.questionnaire.QuestionnaireRepositoryImp

/**
 * @Author: @zekiamani
 * @Date: 12.01.2024
 */
object Questionnaire {

    private val questionnaireUseCase: QuestionnaireUseCase? by lazy {
        QuestionnaireUseCase(QuestionnaireRepositoryImp())
    }

    fun getQuestions(
        onComplete: (QuestionnaireModel) -> Unit,
        onError: (error: Exception) -> Unit
    ) {
        questionnaireUseCase?.getQuestions(
            onComplete = onComplete,
            onError = onError
        )
    }

    fun submitAnswers(
        submitAnswer: List<SubmitAnswer>,
        onComplete: () -> Unit,
        onError: (exception :Exception) -> Unit
    ) {
        questionnaireUseCase?.submitAnswers(
            submitAnswers = submitAnswer,
            onComplete = onComplete,
            onError = onError
        )
    }
}
