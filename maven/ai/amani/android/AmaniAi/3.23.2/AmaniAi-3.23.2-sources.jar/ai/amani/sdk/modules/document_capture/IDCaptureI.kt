package ai.amani.sdk.modules.document_capture

import ai.amani.sdk.interfaces.ExceptionCallBack
import ai.amani.sdk.interfaces.IFragmentCallBack
import ai.amani.sdk.interfaces.IUploadCallBack
import android.widget.FrameLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity

interface IDCaptureI {
    fun start(
        activity: FragmentActivity,
        frameLayout: FrameLayout,
        docType: String,
        frontSide: Boolean = true,
        callBack: IFragmentCallBack
    ): Fragment?

    fun upload(activity: FragmentActivity, docType: String, callBack: IUploadCallBack)

    fun onException(exception: ExceptionCallBack): IDCapture
}