package ai.amani.sdk.modules.customer.detail

import ai.amani.sdk.model.customer.CustomerDetailResult

/**
 * @Author: zekiamani
 * @Date: 30.06.2022
 */
interface ICustomerDetail {

    fun getCustomerDetail(profileDetailObserver: CustomerDetailObserver)
}

interface CustomerDetailObserver {

    fun result(customerDetail: CustomerDetailResult?, throwable: Throwable? = null)
}