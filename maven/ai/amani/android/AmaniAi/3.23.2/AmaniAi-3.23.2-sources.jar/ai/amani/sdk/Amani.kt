package ai.amani.sdk

import ai.amani.base.annotiations.AmaniRestricted
import ai.amani.base.logger.local.AmaniLog
import ai.amani.base.logger.local.LogArea
import ai.amani.base.logger.local.LogPolicy
import ai.amani.base.util.AppPreferences
import ai.amani.base.util.CacheUtility
import ai.amani.base.util.ServerUrl
import ai.amani.base.utility.AmaniVersion
import ai.amani.base.utility.AppConstants
import ai.amani.sdk.Amani.configure
import ai.amani.sdk.Amani.init
import ai.amani.sdk.Amani.startSession
import ai.amani.sdk.interfaces.ILoginCallBack
import ai.amani.sdk.model.AmaniLogLevel
import ai.amani.sdk.model.exception.AmaniException
import ai.amani.sdk.modules.amani_events.AmaniEvent
import ai.amani.sdk.modules.bio_login.BioLogin
import ai.amani.sdk.modules.config.app.AppConfig
import ai.amani.sdk.modules.config.country.CountryList
import ai.amani.sdk.modules.customer.detail.CustomerDetail
import ai.amani.sdk.modules.customer.update.CustomerUpdate
import ai.amani.sdk.modules.document.Document
import ai.amani.sdk.modules.document_capture.IDCapture
import ai.amani.sdk.modules.nfc.NFC
import ai.amani.sdk.modules.questionnaire.Questionnaire
import ai.amani.sdk.modules.selfie.auto_capture.AutoSelfieCapture
import ai.amani.sdk.modules.selfie.manual_capture.Selfie
import ai.amani.sdk.modules.selfie.pose_estimation.SelfiePoseEstimation
import ai.amani.sdk.modules.signature.Signature
import ai.amani.sdk.modules.video_call.VideoCall
import ai.amani.sdk.service.upload.ErrorConstants
import android.app.Activity
import android.content.Context
import androidx.annotation.RawRes
import networkmanager.common.network.NetworkManagerClient
import networkmanager.common.network.SSLPinningManager
import networkmanager.v2.SseConnectivityWatcher
import networkmanager.v2.SseManager
import java.io.InputStream

object Amani: InternalAmaniInitializer() {

    var VERSION: AmaniVersion = AmaniVersion.V1

    @JvmStatic
    fun sharedInstance(): Amani = Amani


    /**
     * ⚠️ Deprecated: Use [configure] instead.
     * Fully deprecated after +v4.
     *
     * ✅ Recommended Latest Configuration method:
     * ```kotlin
     * configure(
     *     context = yourContext,
     *     server = "https://yourserver.com",
     *     version = AmaniVersion.V2,
     *     sharedSecret = "optional",
     *     uploadSource = UploadSource.KYC,
     *     enabledFeatures = DynamicFeature.allFeatures
     * )
     * ```
     */
    @Deprecated(
        message = "Use configure() instead. Fully deprecated after +v4.",
        replaceWith = ReplaceWith(
            "configure(context, server, version, sharedSecret = null, uploadSource = null, " +
                    "enabledFeatures = DynamicFeature.allFeatures)"
        )
    )
    @JvmStatic
    fun init(
        context: Context,
        server: String? = null,
        version: AmaniVersion? = null,
    ) {
        super.configureInternal(
            context = context,
            server = server,
            version = version,
            sharedSecret = null,
            uploadSource = null,
            enabledFeatures = DynamicFeature.allFeatures
        )
    }

    /**
     * ⚠️ Deprecated: Use [configure] instead.
     * Fully deprecated after +v4.
     *
     * ✅ Recommended Latest Configuration method:
     * ```kotlin
     * configure(
     *     context = yourContext,
     *     server = "https://yourserver.com",
     *     version = AmaniVersion.V2,
     *     sharedSecret = "optional",
     *     uploadSource = UploadSource.KYC,
     *     enabledFeatures = DynamicFeature.allFeatures
     * )
     * ```
     */
    @Deprecated(
        message = "Use configure() instead. Fully deprecated after +v4.",
        replaceWith = ReplaceWith(
            "configure(context, server, version, sharedSecret = null, uploadSource = null," +
                    " enabledFeatures = DynamicFeature.allFeatures)"
        )
    )
    @JvmStatic
    fun init(
        context: Context,
        server: String? = null,
        version: AmaniVersion? = null,
        sharedSecret: String?
    ) {
        super.configureInternal(
            context = context,
            server = server,
            version = version,
            sharedSecret = sharedSecret,
            uploadSource = null,
            enabledFeatures = DynamicFeature.allFeatures
        )
    }

    /**
     * ⚠️ Deprecated: Use [configure] instead.
     * Fully deprecated after +v4.
     *
     * ✅ Recommended Latest Configuration method:
     * ```kotlin
     * configure(
     *     context = yourContext,
     *     server = "https://yourserver.com",
     *     version = AmaniVersion.V2,
     *     sharedSecret = "optional",
     *     uploadSource = UploadSource.KYC,
     *     enabledFeatures = DynamicFeature.allFeatures
     * )
     * ```
     */
    @Deprecated(
        message = "Use configure() instead. Fully deprecated after +v4.",
        replaceWith = ReplaceWith(
            "configure(context, server, version, sharedSecret = null, uploadSource = null," +
                    " enabledFeatures = DynamicFeature.allFeatures)"
        )
    )
    @JvmStatic
    fun init(
        context: Context,
        server: String? = null,
        version: AmaniVersion? = null,
        sharedSecret: String?,
        uploadSource: UploadSource? = null
    ) {
        super.configureInternal(
            context = context,
            server = server,
            version = version,
            sharedSecret = sharedSecret,
            uploadSource = uploadSource,
            enabledFeatures = DynamicFeature.allFeatures
        )
    }

    /**
     * ⚠️ Deprecated: Use [configure] instead.
     * Fully deprecated after +v4.
     *
     * ✅ Recommended Latest Configuration method:
     * ```kotlin
     * configure(
     *     context = yourContext,
     *     server = "https://yourserver.com",
     *     version = AmaniVersion.V2,
     *     sharedSecret = "optional",
     *     uploadSource = UploadSource.KYC,
     *     enabledFeatures = DynamicFeature.allFeatures
     * )
     * ```
     */
    @Deprecated(
        message = "Use configure() instead. Fully deprecated after +v4.",
        replaceWith = ReplaceWith(
            "configure(context, server, version, sharedSecret = null, uploadSource = null," +
                    " enabledFeatures = DynamicFeature.allFeatures)"
        )
    )
    @JvmStatic
    fun init(
        context: Context,
        server: String? = null,
        version: AmaniVersion? = null,
        sharedSecret: String? = null,
        uploadSource: UploadSource? = null,
        enabledFeatures: List<DynamicFeature> = DynamicFeature.allFeatures
    ) {
        super.configureInternal(
            context = context,
            server = server,
            version = version,
            sharedSecret = sharedSecret,
            uploadSource = uploadSource,
            enabledFeatures = enabledFeatures
        )
    }

    /**
     * ✅ Recommended Latest Configuration method
     *
     * Use this method to configure the SDK with all available options.
     * It replaces the deprecated [init] method and should be preferred
     * for all new integrations.
     *
     * Example usage:
     * ```kotlin
     * configure(
     *     context = yourContext,
     *     server = "https://yourserver.com",
     *     version = AmaniVersion.V2,
     *     sharedSecret = "optionalSharedSecret",
     *     uploadSource = UploadSource.KYC,
     *     enabledFeatures = DynamicFeature.allFeatures
     * )
     * ```
     *
     * This method allows you to configure:
     * - Server URL
     * - SDK version
     * - Optional shared secret
     * - Upload source
     * - Enabled dynamic features
     */
    @JvmStatic
    fun configure(
        context: Context,
        server: String? = null,
        version: AmaniVersion? = null,
        sharedSecret: String? = null,
        uploadSource: UploadSource? = null,
        enabledFeatures: List<DynamicFeature> = DynamicFeature.allFeatures
    ) {
        super.configureInternal(
            context = context,
            server = server,
            version = version,
            sharedSecret = sharedSecret,
            uploadSource = uploadSource,
            enabledFeatures = enabledFeatures
        )
    }

    /**
     * Configures the SDK using local (bundled) TFLite model files from the APK's `assets/`
     * directory, **skipping all CDN downloads entirely**.
     *
     * Only the features configured via [DynamicFeatureLocal.Builder] are enabled.
     * No other features are activated or downloaded.
     *
     * Example:
     * ```kotlin
     * Amani.configureWithLocalFeatures(
     *     context = context,
     *     server = "https://yourserver.com",
     *     version = AmaniVersion.V2,
     *     sharedSecret = "optional",
     *     uploadSource = UploadSource.KYC,
     *     dynamicFeatureLocal = DynamicFeatureLocal.Builder()
     *         .idCaptureAsset("id_capture_asset.tflite")
     *         .hologramAsset("hologram_asset.tflite")
     *         .autoSelfieAssets(
     *             autoSelfieAsset1 = "selfie_asset_1.tflite",
     *             autoSelfieAsset2 = "selfie_asset_2.tflite",
     *             autoSelfieAsset3 = "selfie_asset_3.tflite"
     *         )
     *         .build()
     * )
     * ```
     *
     * @param dynamicFeatureLocal Asset file names grouped by feature via [DynamicFeatureLocal.Builder].
     */
    @AmaniRestricted
    @JvmStatic
    fun configureWithLocalFeatures(
        context: Context,
        server: String? = null,
        version: AmaniVersion? = null,
        sharedSecret: String? = null,
        uploadSource: UploadSource? = null,
        dynamicFeatureLocal: DynamicFeatureLocal
    ) {
        super.configureWithLocalFeaturesInternal(
            context = context,
            server = server,
            version = version,
            sharedSecret = sharedSecret,
            uploadSource = uploadSource,
            dynamicFeatureLocal = dynamicFeatureLocal
        )
    }

    @JvmStatic
    fun initBio(context: Context, server: String, sharedSecret: String?) {
        LogPolicy.init(context)
        AppPreferences.init(context)
        NetworkManagerClient.initBioLogin(context, ServerUrl.requireApi(server, AmaniVersion.V1), sharedSecret)
        AmaniLog.essential(LogArea.LOGIN) { "bio login configured" }
    }

    @JvmStatic
    fun setUploadSource(uploadSource: UploadSource) {
        this.setUploadSourceInternal(uploadSource.uploadValue)
    }

    @JvmStatic
    fun setUploadSource(uploadSource: String) {
        this.setUploadSourceInternal(uploadSource)
    }

    fun getUploadSource(): String = getUploadSourceInternal()

    @JvmStatic
    @Throws(AmaniException::class)
    fun setSSLPinning(context: Context, @RawRes certificate: Int) {
        try {
            SSLPinningManager.sharedInstance().init(context, certificate)
        } catch (e: Exception) {
            AmaniLog.e(LogArea.CONFIG, e) { "SSL certificate could not be read" }
            throw ErrorConstants.SSL_CERTIFICATE_EXCEPTION
        }
    }

    @JvmStatic
    @Throws(AmaniException::class)
    fun setSSLPinning(certificate: InputStream) {
        try {
            SSLPinningManager.sharedInstance().init(certificate)
        } catch (e: Exception) {
            AmaniLog.e(LogArea.CONFIG, e) { "SSL certificate could not be read" }
            throw ErrorConstants.SSL_CERTIFICATE_EXCEPTION
        }
    }

    /**
     * ⚠️ Deprecated: Use [startSession] instead.
     * Fully deprecated after +v4.
     *
     */
    @Deprecated(
        message = "Use startSession() instead. Fully deprecated after +v4.",
        replaceWith = ReplaceWith("startSession(id, token, lang, birthDate, expireDate," +
                " documentNo, geoLocation, userFullName, userPhoneNumber, userEmail, callback)")
    )
    @JvmStatic
    fun initAmani(
        id: String,
        token: String,
        lang: String,
        callBack: ILoginCallBack
    ) {
        super.startSessionInternal(
            id = id,
            token = token,
            lang = lang,
            callback = callBack,
            birthDate  = null,
            expireDate = null,
            documentNo  = null,
            geoLocation  = true,
            userFullName  = null,
            userPhoneNumber  = null,
            userEmail  = null,
        )
    }

    /**
     * ⚠️ Deprecated: Use [startSession] instead.
     * Fully deprecated after +v4.
     *
     */
    @Deprecated(
        message = "Use startSession() instead. Fully deprecated after +v4.",
        replaceWith = ReplaceWith("startSession(id, token, lang, birthDate, expireDate," +
                " documentNo, geoLocation, userFullName, userPhoneNumber, userEmail, callback)")
    )
    @JvmStatic
    fun initAmani(
        activity: Activity?,
        id: String,
        token: String,
        lang: String,
        birthDate: String? = null,
        expireDate: String? = null,
        documentNo: String? = null,
        geoLocation: Boolean = true,
        userFullName: String? = null,
        userPhoneNumber: String? = null,
        userEmail: String? = null,
        callback: ILoginCallBack
        ) {
        super.startSessionInternal(
            id = id,
            token = token,
            lang = lang,
            birthDate = birthDate,
            expireDate = expireDate,
            documentNo = documentNo,
            geoLocation = geoLocation,
            userFullName = userFullName,
            userPhoneNumber = userPhoneNumber,
            userEmail = userEmail,
            callback = callback
        )
    }

    /**
     * ✅ Recommended Latest token-based Session Starter
     */
    @JvmStatic
    fun startSession(
        id: String,
        token: String,
        lang: String,
        birthDate: String? = null,
        expireDate: String? = null,
        documentNo: String? = null,
        geoLocation: Boolean = true,
        userFullName: String? = null,
        userPhoneNumber: String? = null,
        userEmail: String? = null,
        callback: ILoginCallBack
    ) {
        super.startSessionInternal(
            id = id,
            token = token,
            lang = lang,
            birthDate = birthDate,
            expireDate = expireDate,
            documentNo = documentNo,
            geoLocation = geoLocation,
            userFullName = userFullName,
            userPhoneNumber = userPhoneNumber,
            userEmail = userEmail,
            callback = callback
        )
    }

    /**
     * 🚫 Fully Deprecated: Password-based login
     */
    @JvmStatic
    @Deprecated(
        message = "Password-based login is deprecated. Use token-based initAmani() instead.",
        replaceWith = ReplaceWith(
            "initAmani(activity, id, token, birthDate, expireDate, documentNo, " +
                    "geoLocation, lang, userFullName, userPhoneNumber, userEmail, callback)",
        )
    )
    fun initAmaniWithPassword(
        activity: Activity,
        id: String?,
        email: String?,
        password: String?,
        lang: String,
        callback: ILoginCallBack,
        birthDate: String? = null,
        expireDate: String? = null,
        documentNo: String? = null,
        geoLocation: Boolean = true,
        userFullName: String? = null,
        userPhoneNumber: String? = null,
        userEmail: String? = null
    ) {
        super.startSessionWithPassword(
            id = id,
            email = email,
            password = password,
            lang = lang,
            callback = callback,
            birthDate = birthDate,
            expireDate = expireDate,
            documentNo = documentNo,
            geoLocation = geoLocation,
            userFullName = userFullName,
            userPhoneNumber = userPhoneNumber,
            userEmail = userEmail
        )
    }

    /**
     * Sets how much the SDK writes to logcat (tag `AmaniCoreSDK`, each line prefixed with its area
     * such as `[Upload]`). Without a call the SDK follows the host app's build:
     * [AmaniLogLevel.DEBUG] in a debuggable app, [AmaniLogLevel.ESSENTIAL] in a release app.
     * May be called at any time, before or after [configure], and from any thread.
     *
     * Personal data, credentials and document data are never written, at any level: they show as
     * `[hidden]`, in a debuggable app too.
     *
     * ```kotlin
     * Amani.setLogLevel(AmaniLogLevel.NONE) // silence the SDK in logcat
     * ```
     * ```java
     * Amani.setLogLevel(AmaniLogLevel.DEBUG); // details in a release build, e.g. for a support session
     * ```
     */
    @JvmStatic
    fun setLogLevel(level: AmaniLogLevel) {
        LogPolicy.hostLevel = level
    }

    @JvmStatic
    fun finishSession(){
        if (sessionActive) AmaniLog.essential(LogArea.SESSION) { "session finished" }
        else AmaniLog.d(LogArea.SESSION) { "session finish skipped, no active session" }
        sessionActive = false
        SseManager.sharedInstance().killSocket()
        // What the finished session delivered says nothing about the next one.
        AmaniEvent.forgetDelivered()
        // Nothing of the SDK stays registered in or held from the host app after a finished
        // session; a later configure() installs the watcher again and stores the context anew.
        watchedApplicationContext?.let { SseConnectivityWatcher.uninstall(it) }
        watchedApplicationContext = null
        CacheUtility.clearAllCache()
    }

    @AmaniRestricted
    fun setUISDKVersion(version: String) = apply {
        AppConstants.SDK_VERSION = "UI SDK: $version\n${AppConstants.SDK_VERSION}"
    }

    // Module accessors
    @JvmStatic
    fun IDCapture(): IDCapture = IDCapture

    @JvmStatic
    fun Selfie(): Selfie = Selfie

    @JvmStatic
    fun ScanNFC(): NFC = NFC

    @JvmStatic
    fun BioLogin(): BioLogin = BioLogin

    @JvmStatic
    fun AutoSelfieCapture(): AutoSelfieCapture = AutoSelfieCapture

    @JvmStatic
    fun Document(): Document = Document

    @JvmStatic
    fun CustomerInfo(): CustomerUpdate = CustomerUpdate

    @JvmStatic
    fun Signature(): Signature = Signature.sharedInstance()

    @JvmStatic
    fun VideoCall(): VideoCall = VideoCall

    @JvmStatic
    fun CustomerDetail(): CustomerDetail = CustomerDetail

    @JvmStatic
    fun AppConfig(): AppConfig = AppConfig

    @JvmStatic
    fun SelfiePoseEstimation(): SelfiePoseEstimation = SelfiePoseEstimation

    @JvmStatic
    fun CountryList(): CountryList = CountryList

    @JvmStatic
    fun AmaniEvent(): AmaniEvent = AmaniEvent

    @JvmStatic
    fun Questionnaire(): Questionnaire = Questionnaire

}
