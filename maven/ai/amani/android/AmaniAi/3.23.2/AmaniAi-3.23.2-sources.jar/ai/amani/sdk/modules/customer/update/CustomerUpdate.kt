package ai.amani.sdk.modules.customer.update

import ai.amani.base.logger.local.AmaniLog
import ai.amani.base.logger.local.LogArea
import ai.amani.base.util.SessionManager
import ai.amani.base.utility.AmaniVersion
import ai.amani.sdk.Amani
import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.interfaces.PINCallback
import ai.amani.sdk.interfaces.TermsConditionsCallback
import ai.amani.sdk.model.amani_events.error.AmaniErrorTypes
import ai.amani.sdk.modules.amani_events.AmaniEvent
import ai.amani.sdk.modules.customer.usecase.TermsConditionsUseCase
import ai.amani.sdk.service.upload.ErrorConstants
import ai.amani.sdk.service.upload.HitCustomerInfoApi
import ai.amani.sdk.service.v2.biomatch.DisablePINUseCase
import ai.amani.sdk.service.v2.biomatch.EnablePINUseCase
import ai.amani.sdk.service.v2.upload.HitCustomerInfoApiV2
import datamanager.model.customer.Address
import datamanager.model.customer.CustomerNewInfo
import datamanager.repomanager.biomatch.BioMatchRepository
import datamanager.v2.model.otp.email.SubmitEmailOTPRequest
import datamanager.v2.model.otp.phone.SubmitPhoneOTPRequest
import datamanager.v2.model.profile.update.ProfileAddressUpdate
import datamanager.v2.repomanager.otp.EmailOTPRepositoryImp
import datamanager.v2.repomanager.otp.PhoneOTPRepositoryImp
import datamanager.v2.repomanager.terms_conditions.TermsConditionsRepositoryImp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import networkmanager.common.network.NetworkManager

object CustomerUpdate : ICustomerInfo {

    private var customerNewInfo: CustomerNewInfo? = null

    private val disablePINUseCase = DisablePINUseCase(
        repository = BioMatchRepository(
            NetworkManager.apiClientV2
        )
    )
    private val enablePINUseCase = EnablePINUseCase(
        repository = BioMatchRepository(
            NetworkManager.apiClientV2
        )
    )

    private val useCase: TermsConditionsUseCase by lazy {
        TermsConditionsUseCase(TermsConditionsRepositoryImp())
    }


    override fun upload(callBack: IUploadCallBack) {
        when (Amani.VERSION.version) {
            AmaniVersion.V1.version -> {
                try {
                    val hitCustomerInfoApi = HitCustomerInfoApi()
                    hitCustomerInfoApi.callBackU = callBack
                    customerNewInfo!!.id = SessionManager.getCustomerId()
                    hitCustomerInfoApi.updateCustomerInfo(customerNewInfo)
                } catch (e: Exception) {
                    AmaniLog.e(LogArea.SESSION, e) { "customer update failed" }
                    callBack.cb(false)
                    AmaniEvent.getEvent()?.onError(
                        AmaniErrorTypes.CUSTOMER.name,
                        arrayListOf(ErrorConstants.CUSTOMER_NOT_FOUND_ERROR)
                    )
                }
            }

            AmaniVersion.V2.version -> {
                val hitCustomerApiV2 = HitCustomerInfoApiV2()
                val customerID = SessionManager.getCustomerIdV2()

                if (customerID != null) {
                    hitCustomerApiV2.updateCustomerInfo(
                        callBackU = callBack,
                        addressUpdate = ProfileAddressUpdate(
                            address = datamanager.v2.model.profile.update.Address(
                                address = customerNewInfo!!.address?.address,
                                city = customerNewInfo!!.address?.city,
                                province = customerNewInfo!!.address?.province,
                            ),
                            occupation = customerNewInfo?.occupation,
                            email = customerNewInfo?.email,
                            phone = customerNewInfo?.phone,
                            birthdate = customerNewInfo?.birthdate,
                            name = customerNewInfo?.name
                        )
                    )
                } else {
                    callBack.cb(false)
                    AmaniEvent.getEvent()?.onError(
                        AmaniErrorTypes.CUSTOMER.name,
                        arrayListOf(ErrorConstants.CUSTOMER_NOT_FOUND_ERROR)
                    )
                }
            }
        }
    }

    override fun sendEmailOTP(callBack: IUploadCallBack) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                EmailOTPRepositoryImp().send(SessionManager.getToken())
                callBack.cb(true)
            } catch (e: Exception) {
                AmaniLog.e(LogArea.SESSION, e) { "email otp send failed" }
                callBack.cb(false)
            }
        }
    }

    override fun submitEmailOTP(otp: String, callBack: IUploadCallBack) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                EmailOTPRepositoryImp().submit(
                    SessionManager.getToken(), SubmitEmailOTPRequest(
                        otp = otp
                    )
                )
                callBack.cb(true)
            } catch (e: Exception) {
                AmaniLog.e(LogArea.SESSION, e) { "email otp submit failed" }
                callBack.cb(false)
            }
        }
    }

    override fun sendPhoneOTP(callBack: IUploadCallBack) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                PhoneOTPRepositoryImp().send(SessionManager.getToken())
                callBack.cb(true)
            } catch (e: Exception) {
                AmaniLog.e(LogArea.SESSION, e) { "phone otp send failed" }
                callBack.cb(false)
            }
        }
    }

    override fun submitPhoneOTP(otp: String, callBack: IUploadCallBack) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                PhoneOTPRepositoryImp().submit(
                    SessionManager.getToken(),
                    SubmitPhoneOTPRequest(otp = otp)
                )
                callBack.cb(true)
            } catch (e: Exception) {
                AmaniLog.e(LogArea.SESSION, e) { "phone otp submit failed" }
                callBack.cb(false)
            }
        }
    }

    override fun enablePin(pin: String, callback: PINCallback) {
        enablePINUseCase.invoke(
            pin = pin,
            callback = callback
        )
    }

    override fun disablePin(callback: PINCallback) {
        disablePINUseCase.invoke(
            callback = callback
        )
    }

    override fun acceptTermsConditions(
        callback: TermsConditionsCallback
    ) {
        useCase.accept(
            callback = callback
        )
    }

    fun setInfo(
        occupation: String? = null,
        city: String? = null,
        province: String? = null,
        address: String? = null,
        email: String? = null,
        phoneNumber: String? = null,
        birthDate: String? = null,
        fullName: String? = null
    ) {
        customerNewInfo = CustomerNewInfo()
        val customerAddress = Address()
        val customerID: Int?
        customerAddress.address = address
        customerAddress.city = city
        customerAddress.province = province
        customerID = SessionManager.getCustomerId()
        if (customerID != 0) customerNewInfo!!.id = SessionManager.getCustomerId()
        customerNewInfo?.occupation = occupation
        customerNewInfo?.address = customerAddress
        customerNewInfo?.email = email
        customerNewInfo?.phone = phoneNumber
        customerNewInfo?.birthdate = birthDate
        customerNewInfo?.name = fullName
    }
}