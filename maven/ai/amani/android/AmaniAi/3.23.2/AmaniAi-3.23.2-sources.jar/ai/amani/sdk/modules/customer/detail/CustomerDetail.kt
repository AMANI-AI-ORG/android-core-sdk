package ai.amani.sdk.modules.customer.detail

import ai.amani.base.util.SessionManager
import ai.amani.base.utility.AmaniVersion
import ai.amani.base.utility.AppConstants
import ai.amani.sdk.Amani
import ai.amani.sdk.mapper.CustomerDetailMapper.asSDKModel
import datamanager.repomanager.customer.CustomerImp
import datamanager.v2.repomanager.profile.CustomerImpV2
import io.reactivex.disposables.CompositeDisposable


/**
 * @Author: zekiamani
 * @Date: 30.06.2022
 */
object CustomerDetail : ICustomerDetail {

    private var compositeDisposable = CompositeDisposable()


    override fun getCustomerDetail(profileDetailObserver: CustomerDetailObserver) {

        when(Amani.VERSION!!) {

            AmaniVersion.V1 -> {
                val customerStatusDisposable = CustomerImp().getCustomerDetail(
                    SessionManager.getCustomerId().toString(),
                    SessionManager.getLanguage(),
                    AppConstants.TOKEN + SessionManager.getToken()
                )
                    .subscribe(

                        {
                            profileDetailObserver.result(it.asSDKModel())
                        },

                        {
                            profileDetailObserver.result(null, it)
                        })

                compositeDisposable.add(customerStatusDisposable)
            }

            AmaniVersion.V2 -> {

                val customerStatusDisposable = CustomerImpV2().getCustomerDetail(
                    SessionManager.getCustomerIdV2(),
                    SessionManager.getLanguage(),
                    AppConstants.BEARER + SessionManager.getToken()
                )
                    .subscribe(
                        {
                            profileDetailObserver.result(it!!.asSDKModel())
                        },

                        {
                            profileDetailObserver.result(null, it)
                        })

                compositeDisposable.add(customerStatusDisposable)
            }
        }
    }
}
