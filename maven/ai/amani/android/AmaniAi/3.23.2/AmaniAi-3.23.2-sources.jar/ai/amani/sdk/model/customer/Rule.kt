package ai.amani.sdk.model.customer


import com.google.gson.annotations.SerializedName

data class Rule(
    @SerializedName("adapter")
    val adapter: String?,
    @SerializedName("attempt")
    val attempt: Int?,
    @SerializedName("document_classes")
    val documentClasses: List<String?>?,
    @SerializedName("errors")
    val errors: List<Error?>?,
    @SerializedName("id")
    val id: String?,
    @SerializedName("phase")
    val phase: Int?,
    @SerializedName("sort_order")
    val sortOrder: Int?,
    @SerializedName("status")
    val status: String?,
    @SerializedName("title")
    val title: String?,
    @SerializedName("isShowLoader")
    var isShowLoader: Boolean = false,
    @SerializedName("identifier")
    var identifier: String = "",
    @SerializedName("document")
    val document: String? = null,
    /** True when the step may be skipped; null when the backend did not say. */
    @SerializedName("optional")
    val optional: Boolean? = null,
)