package ai.amani.sdk.interfaces;

import android.graphics.Bitmap;

import androidx.annotation.Nullable;

public interface INfcCallBack{

     /**
      *--- NFC CallBack ---
      * @param bitmap ID/Passport biometric photo as bitmap value.
      * @param isSuccess If the NFC process is success or not as boo.
      * @param exception While reading NFC from document, if any kind of error occurs.
      */
     void cb(Bitmap bitmap, boolean isSuccess, @Nullable String exception);
}
