package ai.amani.sdk.model.customer

import com.google.gson.annotations.SerializedName

data class Error(
    @SerializedName("error_code")
    val errorCode: Int?,
    @SerializedName("error_message")
    val errorMessage: Any?
)