package ai.amani.sdk.model.amani_events.error

/**
 * @Author: @zekiamani
 * @Date: 18.07.2023
 */
enum class AmaniErrorTypes(name: String)  {
    LOGIN ("login_error"),
    CONFIG("config_error"),
    SELFIE("selfie_error"),
    ID("id_error"),
    SIGNATURE ("signature_error"),
    CUSTOMER("customer_error"),
    SOCKET("socket_error"),
    NFC("nfc_error")
}