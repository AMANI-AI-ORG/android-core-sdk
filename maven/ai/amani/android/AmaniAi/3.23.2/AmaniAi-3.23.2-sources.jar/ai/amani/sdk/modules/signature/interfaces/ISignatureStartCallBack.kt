package ai.amani.sdk.modules.signature.interfaces

import android.graphics.Bitmap

interface ISignatureStartCallBack {
    fun cb(bitmap: Bitmap?, countOfSignature: Int)
}