package ai.amani.sdk.modules.bio_login

import ai.amani.base.annotiations.NonMandatory
import ai.amani.base.logger.local.AmaniLog
import ai.amani.base.logger.local.LogArea
import ai.amani.base.logger.util.OperationIdProvider
import ai.amani.base.utility.AppConstants
import ai.amani.base.utility.RootedDeviceChecker
import ai.amani.sdk.interfaces.AutoSelfieCaptureObserver
import ai.amani.sdk.interfaces.BioLoginUploadCallBack
import ai.amani.sdk.interfaces.IFragmentCallBack
import ai.amani.sdk.interfaces.ManualSelfieCaptureObserver
import ai.amani.sdk.modules.selfie.auto_capture.ASCBuilder
import ai.amani.sdk.modules.selfie.auto_capture.view.fragment.AutoSelfieCaptureFrag
import ai.amani.sdk.modules.selfie.manual_capture.model.ManualSelfieCaptureConfig
import ai.amani.sdk.modules.selfie.manual_capture.view.SelfieCaptureFrag
import ai.amani.sdk.modules.selfie.pose_estimation.model.PoseEstimationConfig
import ai.amani.sdk.modules.selfie.pose_estimation.observable.PoseEstimationObserver
import ai.amani.sdk.modules.selfie.pose_estimation.ui.fragment.SelfiePoseEstimationFrag
import ai.amani.sdk.service.upload.BIOLoginUseCase
import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import androidx.annotation.ColorRes
import androidx.annotation.DrawableRes
import androidx.fragment.app.Fragment
import datamanager.v2.repomanager.device_data.DeviceDataRepository
import datamanager.v2.repomanager.upload_bio_login.BIOLoginRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

object BioLogin {
    private var selfieFeature: SelfieFeature = SelfieFeature.ManualSelfie
    /* Auto Selfie Builder as default configuration of screen */
    var autoSelfieConfig = ASCBuilder()

    /* Selfie Pose Estimation as default configuration of screen */
    var poseEstimationConfig = PoseEstimationConfig()

    /* Manual Selfie as default configuration of screen */
    var manualSelfieConfig = ManualSelfieCaptureConfig()

    var docType: String = "XXX_SE_0"

    private var uploadConfig: UploadConfiguration = UploadConfiguration()
    private var bioLoginUseCase: BIOLoginUseCase? = null

    object AutoSelfie {

        private var observer: AutoSelfieCaptureObserver? = null

        fun timeOutManualButton( timeOut: Int) = apply {
            autoSelfieConfig.timeOutManualButton = timeOut
        }

        fun observer(
            observer : AutoSelfieCaptureObserver
        ) = apply {
            this.observer = observer
        }

        fun documentType(docType: String) = apply {
            BioLogin.docType = docType
        }

        fun userInterfaceTexts(
            faceNotFoundText: String? = null,
            holdStableText: String? = null,
            faceIsTooFarText: String? = null
        ) = apply {
            if (faceIsTooFarText != null) autoSelfieConfig.closeEnoughMessageText = faceIsTooFarText
            if (faceNotFoundText != null) autoSelfieConfig.faceNotFoundMessageText = faceNotFoundText
            if (holdStableText != null) autoSelfieConfig.holdStableMessageText = holdStableText
        }

        fun userInterfaceColors(
            @ColorRes appFontColor: Int? = null,
            @ColorRes manualButtonColor: Int? = null,
            @ColorRes ovalViewStartColor: Int? = null,
            @ColorRes ovalViewSuccessColor: Int? = null,
        ) = apply {
            if (ovalViewStartColor != null) {
                autoSelfieConfig.counterTextColor = ovalViewStartColor
                autoSelfieConfig.ovalColor = ovalViewStartColor
            }
            if (ovalViewSuccessColor != null) autoSelfieConfig.successColor = ovalViewSuccessColor
            if (appFontColor != null) autoSelfieConfig.messageTextColor = appFontColor
            if (manualButtonColor != null) autoSelfieConfig.colorManualButton = manualButtonColor
        }

        fun build() : Fragment? {
            if (observer == null) {
                AmaniLog.e(LogArea.LOGIN) { "bio login screen not built: no observer set" }
                return null
            }

            val selfieCaptureFrag = AutoSelfieCaptureFrag()
            val arg = Bundle()
            arg.putParcelable(AppConstants.ASC_BUILDER, autoSelfieConfig)
            arg.putString(AppConstants.OPERATION_ID, OperationIdProvider.startNew())
            selfieCaptureFrag.arguments = arg
            selfieCaptureFrag.fragmentCallBack = object : IFragmentCallBack {
                override fun cb(bitmap: Bitmap?, manualButtonActivated: Boolean?, file: File?) {
                   if (observer != null) observer!!.cb(bitmap)
                }
            }
            return selfieCaptureFrag
        }
    }

    object ManualSelfie  {

        private var observer : ManualSelfieCaptureObserver? = null

        fun documentType(docType: String) = apply {
            BioLogin.docType = docType
        }

        fun observer(
            observer : ManualSelfieCaptureObserver
        ) = apply {
            this.observer = observer
        }

        fun userInterfaceTexts(
            selfieDescriptionText: String? = null
        ) = apply {
            if (selfieDescriptionText != null) manualSelfieConfig.uiTexts.selfieDescriptionText = selfieDescriptionText
        }

        fun userInterfaceColors(
            @ColorRes appFontColor: Int? = null,
            @ColorRes appBackgroundColor: Int? = null,
            @ColorRes ovalViewColor: Int? = null,
            @ColorRes manualButtonColor: Int? = null
        ) = apply {
           if (appFontColor != null) manualSelfieConfig.uiColors.appFontColor = appFontColor
           if (ovalViewColor != null) manualSelfieConfig.uiColors.ovalViewColor = ovalViewColor
           if (manualButtonColor != null) manualSelfieConfig.uiColors.manualCaptureButtonColor = manualButtonColor
           if (appBackgroundColor != null) manualSelfieConfig.uiColors.appBackgroundColor = appBackgroundColor
        }

        fun build() : Fragment? {
            if (observer == null) return null
            val selfieCaptureFrag = SelfieCaptureFrag()
            val arg = Bundle()
            arg.putParcelable(AppConstants.CONFIG_MANUAL_SELFIE, manualSelfieConfig )
            arg.putString(AppConstants.OPERATION_ID, OperationIdProvider.startNew())
            selfieCaptureFrag.arguments = arg
            selfieCaptureFrag.fragmentCallBack = object : IFragmentCallBack {
                override fun cb(bitmap: Bitmap?, manualButtonActivated: Boolean?, file: File?) {
                    observer!!.cb(bitmap = bitmap)
                }
            }
            return selfieCaptureFrag
        }
    }

    object SelfiePoseEstimation {

        private var observer: PoseEstimationObserver? = null

        fun documentType(docType: String) = apply {
            BioLogin.docType = docType
        }

        fun requestedPoseNumber(requestedPoseNumber: Int?) = apply {
            if (requestedPoseNumber == null) throw Exception("Requested pose number cannot be null")
            if (requestedPoseNumber == 0) throw Exception("Requested pose number cannot be zero or null")
            poseEstimationConfig.selfieType = requestedPoseNumber
        }

        fun ovalViewAnimationDurationMilSec(ovalViewAnimationDurationMilSec: Int?) = apply {
            if (ovalViewAnimationDurationMilSec == null) throw Exception("Duration mil sec of oval view animation cannot be null")
            poseEstimationConfig.ovalViewAnimationDurationMilSec = ovalViewAnimationDurationMilSec
        }

        @NonMandatory("Has default values")
        fun userInterfaceTexts(
            faceNotInside: String? = null,
            faceNotStraight: String? = null,
            faceIsTooFar: String? = null,
            holdPhoneVertically: String? = null,
            alertTitle: String? = null,
            alertDescription: String? = null,
            alertTryAgain: String? = null,
            turnLeft: String? = null,
            turnRight: String? = null,
            turnUp: String? = null,
            turnDown: String? = null,
            faceStraight: String? = null
        ) = apply {
            poseEstimationConfig.uiTexts.also {
                if (faceNotInside != null) it.faceNotInside = faceNotInside
                if (faceNotStraight != null) it.faceNotStraight = faceNotStraight
                if (faceIsTooFar != null) it.faceTooFar = faceIsTooFar
                if (holdPhoneVertically != null) it.holdPhoneVertically = holdPhoneVertically
                if (alertDescription != null) it.alertDescription = alertDescription
                if (alertTitle != null) it.alertTitle = alertTitle
                if (alertTryAgain != null) it.alertTryAgain = alertTryAgain
                if (turnLeft != null) it.turnLeft = turnLeft
                if (turnRight != null) it.turnRight = turnRight
                if (turnUp != null) it.turnUp = turnUp
                if (turnDown != null) it.turnDown = turnDown
                if (faceStraight != null) it.faceStraight = faceStraight
            }
        }

        @NonMandatory("Has mandatory values")
        fun userInterfaceColors(
            ovalViewStartColor: Int?,
            ovalViewSuccessColor: Int?,
            ovalViewErrorColor: Int?,
            alertTitleFontColor: Int?,
            alertDescriptionFontColor: Int?,
            alertTryAgainFontColor: Int?,
            alertBackgroundFontColor: Int?,
            appFontColor: Int?
        ) = apply {
            if (ovalViewErrorColor != null
                && ovalViewStartColor != null
                && ovalViewSuccessColor != null
                &&appFontColor != null
                && alertTitleFontColor != null
                && alertDescriptionFontColor != null
                && alertTryAgainFontColor != null
                && alertBackgroundFontColor != null ) {
                poseEstimationConfig.uiColors.also {
                    it.appFontColor = appFontColor
                    it.ovalViewErrorColor = ovalViewErrorColor
                    it.ovalViewStartColor = ovalViewStartColor
                    it.ovalViewSuccessColor = ovalViewSuccessColor
                    it.alertFontDescriptionColor = alertDescriptionFontColor
                    it.alertBackgroundColor = alertBackgroundFontColor
                    it.alertFontTitleColor = alertTitleFontColor
                    it.alertFontTryAgainColor = alertTryAgainFontColor
                }
            }
        }

        @NonMandatory("Has default values")
        fun userInterfaceDrawables(
            @DrawableRes mainGuideLeft: Int? = null,
            @DrawableRes mainGuideRight: Int? = null,
            @DrawableRes mainGuideUp: Int? = null,
            @DrawableRes mainGuideDown: Int? = null,
            @DrawableRes mainGuideStraight: Int? = null,
            @DrawableRes secondaryGuideLeft: Int? = null,
            @DrawableRes secondaryGuideRight: Int? = null,
            @DrawableRes secondaryGuideUp: Int? = null,
            @DrawableRes secondaryGuideDown: Int? = null,
        ) = apply {
            poseEstimationConfig.uiDrawables.also {
                if (mainGuideLeft != null) it.mainGuideLeft = mainGuideLeft
                if (mainGuideRight != null) it.mainGuideRight = mainGuideRight
                if (mainGuideUp != null) it.mainGuideUp = mainGuideUp
                if (mainGuideDown != null) it.mainGuideDown = mainGuideDown
                if (mainGuideStraight != null) it.mainGuideStraight = mainGuideStraight
                if (secondaryGuideLeft != null) it.secondaryGuideLeft = secondaryGuideLeft
                if (secondaryGuideRight != null) it.secondaryGuideRight = secondaryGuideRight
                if (secondaryGuideUp != null) it.secondaryGuideUp = secondaryGuideUp
                if (secondaryGuideDown != null) it.secondaryGuideDown = secondaryGuideDown
            }
        }

        @NonMandatory("Has default values as true")
        fun userInterfaceVisibilities (
            mainGuideVisibility : Boolean = true,
            secondaryGuideVisibility : Boolean = true
        ) = apply {
            poseEstimationConfig.uiVisibilities.also {
                it.mainGuideVisibility = mainGuideVisibility
                it.secondaryGuideVisibility = secondaryGuideVisibility
            }
        }

        fun observer(poseEstimationObserver: PoseEstimationObserver?) = apply {
            if (poseEstimationObserver == null) throw Exception("Pose estimation observer cannot be null")
            observer = poseEstimationObserver
        }

        fun build() : Fragment? {
            return if (observer != null) {
                val poseEstimationInstruction = SelfiePoseEstimationFrag()
                val arg = Bundle()
                arg.putParcelable(AppConstants.KEY_POSE_ESTIMATION, poseEstimationConfig)
                // One operation per screen, as the standalone modules do: the remote log rejects
                // entries without one.
                arg.putString(AppConstants.OPERATION_ID, OperationIdProvider.startNew())
                poseEstimationInstruction.arguments = arg
                poseEstimationInstruction.observer = observer!! // Passing the observer
                poseEstimationInstruction
            } else null
        }
    }

    fun AutoSelfieCapture() : AutoSelfie {
        selfieFeature = SelfieFeature.AutoSelfie
        return AutoSelfie
    }

    fun ManualSelfieCapture() : ManualSelfie {
        selfieFeature = SelfieFeature.ManualSelfie
        return ManualSelfie
    }

    fun PoseEstimation(): SelfiePoseEstimation {
        selfieFeature = SelfieFeature.PoseEstimation
        return SelfiePoseEstimation
    }


    /**
     * Uploads the captured bio login selfie.
     *
     * Unlike the other modules, whose callbacks report whether the upload itself completed, the
     * result reported here is the document status returned by the backend. A `false` result
     * therefore also covers an upload that completed but was not verified.
     *
     * @param callBack receives the document status and, when the backend returns one, the id of
     *                 the uploaded document. Implement only `cb(result)` to keep the previous
     *                 behaviour, or use [bioLoginUploadCallBack] to receive the document id.
     */
    fun upload(context: Context, callBack: BioLoginUploadCallBack?) {
        if (bioLoginUseCase == null) {
            bioLoginUseCase = BIOLoginUseCase(
                deviceDataRepository = DeviceDataRepository(
                    context = context,
                    deviceChecker = RootedDeviceChecker(context = context)
                ),
                bioLoginRepository = BIOLoginRepository()
            )
        }

        bioLoginUseCase?.request(
            docType = docType,
            iUploadCallBack = object : BioLoginUploadCallBack {
                override fun cb(result: Boolean?) {
                    cb(result, null)
                }

                override fun cb(result: Boolean?, documentID: String?) {
                    CoroutineScope(Dispatchers.Main).launch{
                        callBack?.cb(result, documentID)
                    }
                }
            }
        )
    }


    sealed class SelfieFeature {
        object ManualSelfie : SelfieFeature()
        object AutoSelfie : SelfieFeature()
        object PoseEstimation : SelfieFeature()
    }
}