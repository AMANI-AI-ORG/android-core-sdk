package ai.amani.sdk.interfaces;

import androidx.annotation.Nullable;

import java.util.List;

import datamanager.model.customer.Errors;

public interface IUploadCallBack{

    /**
     * ---Upload CallBack ---
     * @param isSuccess Boo value if uploading doc is success or not.
     */
    void cb(boolean isSuccess);

    /**
     * ---Upload CallBack ---
     * @param isSuccess Boo value if uploading doc is success or not.
     * @param documentID id of uploaded document, returned by backend on success (v2 upload flows only).
     */
    default void cb(boolean isSuccess, @Nullable String documentID) {
        cb(isSuccess);
    }

}