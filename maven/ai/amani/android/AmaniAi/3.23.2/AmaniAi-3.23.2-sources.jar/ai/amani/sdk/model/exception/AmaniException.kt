package ai.amani.sdk.model.exception

/**
 * @Author: @zekiamani
 * @Date: 2.08.2024
 */
class AmaniException(
    val exceptionCode: Int,
    val exceptionMessage: String
): Exception()