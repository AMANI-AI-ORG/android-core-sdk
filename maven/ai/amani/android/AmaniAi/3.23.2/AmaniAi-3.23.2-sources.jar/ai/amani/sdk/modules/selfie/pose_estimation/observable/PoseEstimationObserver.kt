package ai.amani.sdk.modules.selfie.pose_estimation.observable

import android.graphics.Bitmap

/**
 * @Author: zekiamani
 * @Date: 8.08.2022
 */
interface PoseEstimationObserver {

    fun onSuccess(bitmap : Bitmap?)

    fun onFailure(reason: OnFailurePoseEstimation, currentAttempt: Int)

    fun onError(error: Error)
}


