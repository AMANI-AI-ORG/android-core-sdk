package ai.amani.sdk.modules.selfie.auto_capture

import ai.amani.R
import ai.amani.base.logger.core.ActionTypes
import ai.amani.base.logger.local.AmaniLog
import ai.amani.base.logger.local.LogArea
import ai.amani.base.logger.local.LogFormat
import ai.amani.base.logger.util.OperationIdProvider
import ai.amani.base.util.SessionManager
import ai.amani.base.utility.AppConstants
import ai.amani.sdk.interfaces.ExceptionCallBack
import ai.amani.sdk.interfaces.IFragmentCallBack
import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.mapper.AmaniEventMapper.asAmaniEventType
import ai.amani.sdk.modules.amani_events.AmaniEvent
import ai.amani.sdk.modules.selfie.auto_capture.upload.UploadAutoCapturedSelfie
import ai.amani.sdk.modules.selfie.auto_capture.view.fragment.AutoSelfieCaptureFrag
import ai.amani.sdk.modules.selfie.auto_capture.tflite.util.Constant.MODEL_FILE_ONET
import ai.amani.sdk.modules.selfie.auto_capture.tflite.util.Constant.MODEL_FILE_PNET
import ai.amani.sdk.modules.selfie.auto_capture.tflite.util.Constant.MODEL_FILE_RNET
import ai.amani.sdk.service.upload.ErrorConstants
import android.os.Bundle
import android.widget.FrameLayout
import androidx.annotation.Nullable
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import ml_amani.util.ModelFileUtility

object AutoSelfieCapture {

    private var callBackF: IFragmentCallBack? = null
    private var callBackU: IUploadCallBack? = null
    private var ascBuilder: ASCBuilder? = ASCBuilder(
        R.color.white,
        20,
        R.color.approve_green,
        false,
        100,
        10,
        "Close enough",
        "Face not found",
        "Hold stable",
        "Restart in 3 seconds",
        R.color.white,
        R.color.white
    )
    private var exceptionCallBack: ExceptionCallBack? = null

    /**
     * Unique ID for each session start to end
     */
    private var operationID : String = ""

    /**
     * @param faceNotStraightMessageText shown while the face is turned, tilted, or looking up or
     * down; empty (the default) shows no message.
     */
    @JvmOverloads
    fun setCustomUI(messageTextColor: Int,messageTextSize: Int, counterTextColor: Int, counterTextVisibility: Boolean, counterTextSize: Int, timeOutManualButton:Int,closeEnoughMessageText:String, faceNotFoundMessageText:String,holdStableMessageText:String,failureMessageText: String, ovalColor:Int, successColor:Int, faceNotStraightMessageText: String = "") {
        ascBuilder = ASCBuilder(messageTextColor,messageTextSize,counterTextColor,counterTextVisibility,counterTextSize,
                timeOutManualButton,closeEnoughMessageText,faceNotFoundMessageText, holdStableMessageText, failureMessageText, ovalColor, successColor,
                faceNotStraightMessageText = faceNotStraightMessageText)
    }

    fun onException(exception: ExceptionCallBack) = apply {
        this.exceptionCallBack = exception
    }

    fun start(docType: String?, @Nullable ascBuilder: ASCBuilder?, frameLayout: FrameLayout, callBack: IFragmentCallBack?): Fragment? {
        callBackF = callBack
        this.operationID = OperationIdProvider.startNew()
        AmaniLog.essential(LogArea.SELFIE) { "auto selfie started docType=$docType op=${LogFormat.op(operationID)}" }
        if (ascBuilder != null) this.ascBuilder = ascBuilder
        return startSelfie(docType, ascBuilder, frameLayout)
    }

    fun upload(activity: FragmentActivity, docType: String, callBack: IUploadCallBack) {
        callBackU = AmaniEvent.observeUpload(callBack)
        uploadSelfie(activity, docType)
    }

    private fun startSelfie(docType: String?, @Nullable ascBuilder: ASCBuilder?, frameLayout: FrameLayout): Fragment? {
        val selfieCaptureFrag = AutoSelfieCaptureFrag()
        val arg = Bundle()

        try {
            val version = SessionManager.getVersion(docType!!)
            if (version == null) {
                AmaniEvent.getEvent()?.onError(
                    type = docType.asAmaniEventType(),
                    error = arrayListOf(ErrorConstants.CONFIG_ERROR)
                )
                return null
            }
            arg.putParcelable(AppConstants.KEY_VERSION_LIST, SessionManager.getVersion(docType))
        } catch (e: Exception) {
            AmaniEvent.getEvent()?.onError(
                type = docType.asAmaniEventType(),
                error = arrayListOf(ErrorConstants.CONFIG_ERROR)
            )
            return null
        }

        val context = frameLayout.context
        val modelsReady = ModelFileUtility.isModelAvailable(context, MODEL_FILE_RNET)
                && ModelFileUtility.isModelAvailable(context, MODEL_FILE_PNET)
                && ModelFileUtility.isModelAvailable(context, MODEL_FILE_ONET)

        if (!modelsReady) {
            AmaniEvent.getEvent()?.onError(
                type = docType.asAmaniEventType(),
                error = arrayListOf(ErrorConstants.DYNAMIC_FEATURE_ASSET_NOT_FOUND)
            )
            return null
        }

        if (ascBuilder!=null) arg.putParcelable(AppConstants.ASC_BUILDER, ascBuilder)
        if (this.ascBuilder != null) arg.putParcelable(AppConstants.ASC_BUILDER, this.ascBuilder)

        arg.putInt(AppConstants.FRAME_LAYOUT_HEIGHT,frameLayout.height)
        arg.putInt(AppConstants.FRAME_LAYOUT_WIDTH,frameLayout.width)
        arg.putString(AppConstants.OPERATION_ID, operationID)

        selfieCaptureFrag.arguments = arg
        selfieCaptureFrag.fragmentCallBack = callBackF
        selfieCaptureFrag.exceptionCallBack = exceptionCallBack
        return selfieCaptureFrag
    }

    private fun uploadSelfie(activity: FragmentActivity, docType: String) {
        val uploadSelfie = UploadAutoCapturedSelfie()
        uploadSelfie.iUploadCallBack = callBackU
        uploadSelfie.uploadSelfie(
            activity = activity,
            docType = docType,
            operationID = operationID,
            actionType = ActionTypes.AUTO_SELFIE_UPLOAD_RESP
        )
    }
}