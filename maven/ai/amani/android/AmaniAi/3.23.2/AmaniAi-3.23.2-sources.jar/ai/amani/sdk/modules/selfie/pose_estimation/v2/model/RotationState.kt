package ai.amani.sdk.modules.selfie.pose_estimation.v2.model

/**
 * Represents the complete UI state for the v2 pose estimation rotation flow.
 *
 * @param leftTurnProgress  How far the user has turned their head LEFT (0.0 → 1.0).
 *                          Maps to a counter-clockwise arc on screen (left side).
 * @param rightTurnProgress How far the user has turned their head RIGHT (0.0 → 1.0).
 *                          Maps to a clockwise arc on screen (right side).
 * @param phase             Current instruction phase driving what text/UI to show.
 * @param faceState         Current detection status of the face.
 * @param targetDirection   The randomly-chosen direction required for this session.
 * @param checkpointIndex   Number of 45° checkpoints completed so far (0–8).
 * @param isStalled         True when rotation is in progress but no checkpoint has advanced
 *                          for approximately 1.5 seconds (~45 frames at 30 fps).
 *                          The UI uses this to surface a "keep rotating" hint.
 */
data class RotationState(
    val leftTurnProgress: Float = 0f,
    val rightTurnProgress: Float = 0f,
    val phase: RotationPhase = RotationPhase.FACE_POSITIONING,
    val faceState: FaceState = FaceState.NOT_INSIDE,
    val targetDirection: TargetDirection = TargetDirection.LEFT,
    val checkpointIndex: Int = 0,
    val isStalled: Boolean = false,
    /**
     * True only when the face is calibrated, present, and pointing forward
     * within strict yaw/pitch tolerances. Drives the gate for selfie capture.
     */
    val isFaceStraight: Boolean = false,
)

/**
 * Phases that drive the instruction text and arc color.
 */
enum class RotationPhase {
    /** Establishing neutral baseline — user must hold steady. */
    CALIBRATING,
    /** Face not yet properly positioned inside the oval. */
    FACE_POSITIONING,
    /** User should turn their head to the LEFT. */
    TURN_LEFT,
    /** Left turn complete; user should now turn to the RIGHT. */
    TURN_RIGHT,
    /** Both turns completed — liveness check passed. */
    SUCCESS
}

/**
 * Fine-grained face detection status used for per-frame feedback.
 */
enum class FaceState {
    NOT_FOUND,
    NOT_INSIDE,
    TOO_FAR,
    AVAILABLE
}

/**
 * The randomly-chosen single direction the user must rotate their head for this session.
 */
enum class TargetDirection { LEFT, RIGHT }
