package ai.amani.sdk.model.customer


import com.google.gson.annotations.SerializedName

data class MissingRule(
    @SerializedName("adapter")
    val adapter: String?,
    @SerializedName("document_classes")
    val documentClasses: List<String?>?,
    @SerializedName("id")
    val id: String?,
    @SerializedName("phase")
    val phase: Int?,
    @SerializedName("sort_order")
    val sortOrder: Int?,
    @SerializedName("title")
    val title: String?
)