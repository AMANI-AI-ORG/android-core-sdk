package ai.amani.sdk.modules.selfie.pose_estimation.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Text configuration for the v2 360° rotation liveness challenge.
 *
 * Only the texts actually displayed by the v2 flow are included.
 * All fields have sensible English defaults.
 */
@Parcelize
data class V2UITexts(

    /** Shown during face-positioning phase: "Look straight to camera". */
    var faceStraight: String = "Look straight to camera",

    /** Shown when the user should rotate left. */
    var turnLeft: String = "Turn your head left",

    /** Shown when the user should rotate right. */
    var turnRight: String = "Turn your head right",

    /** Shown when the face is not detected inside the oval area. */
    var faceNotInside: String = "Your face is not inside the area",

    /** Shown when the face is detected but too far from the camera. */
    var faceTooFar: String = "Your face is too far from camera",

    /** Shown when the device is not held upright. */
    var holdPhoneVertically: String = "Please keep phone in a straight position",

    /** Title of the retry alert dialog after a failed attempt. */
    var alertTitle: String = "Verification Failed",

    /** Body text of the retry alert dialog. */
    var alertDescription: String = "You did not pass verification. Press the button to try again.",

    /** Label for the retry button in the alert dialog. */
    var alertTryAgain: String = "Try Again",

    /**
     * Shown when rotation has started but no checkpoint has advanced for ~1.5 seconds
     * (stall detected). Prompts the user to continue moving rather than freezing silently.
     */
    var keepRotating: String = "Keep rotating",

) : Parcelable
