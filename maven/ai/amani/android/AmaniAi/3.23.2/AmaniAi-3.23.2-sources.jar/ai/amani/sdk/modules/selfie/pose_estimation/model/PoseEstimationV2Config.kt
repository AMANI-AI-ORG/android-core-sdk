package ai.amani.sdk.modules.selfie.pose_estimation.model

import ai.amani.R
import android.os.Parcelable
import androidx.annotation.ColorInt
import androidx.annotation.ColorRes
import androidx.annotation.DrawableRes
import androidx.annotation.RawRes
import kotlinx.parcelize.Parcelize

/**
 * Complete configuration bundle for the v2 360° rotation liveness challenge.
 *
 * Built exclusively by [ai.amani.sdk.modules.selfie.pose_estimation.SelfiePoseEstimation.V2Builder]
 * and passed as a bundle argument to [ai.amani.sdk.modules.selfie.pose_estimation.v2.ui.SelfiePoseEstimationV2Frag].
 */
@Parcelize
data class PoseEstimationV2Config(

    /** Colours for progress ring, direction arrow, text, and alert dialogs. */
    var v2Colors: V2UIColors = V2UIColors(),

    /** Instruction and alert texts displayed during the v2 flow. */
    var v2Texts: V2UITexts = V2UITexts(),

    /**
     * Drawable shown in the oval centre while the user holds their face straight, supplied by
     * the host app. Belongs to the processing screen, so it is configured — and shares its
     * opacity — with
     * [ai.amani.sdk.modules.selfie.pose_estimation.SelfiePoseEstimation.V2Builder.processingAnimation].
     *
     * 0 = not supplied; no icon is drawn and the instruction text carries the message alone.
     */
    @DrawableRes var faceGuideDrawable: Int = 0,

    /** Maximum number of retry attempts before the failure callback fires. */
    var maxAttempt: Int = 3,

    /** Duration in milliseconds of the success animation at challenge completion. */
    var ovalViewAnimationDurationMilSec: Int = 3000,

    /** Whether to record a background video during the liveness challenge. */
    var recordVideo: Boolean = false,

    /**
     * Whether the preparation screen — the head circle guide animation plus the confirm
     * button — is requested.
     * Enabled via [ai.amani.sdk.modules.selfie.pose_estimation.SelfiePoseEstimation.V2Builder.showPreparationScreen].
     *
     * The screen only appears when [preparationAnimationRawRes] is also supplied; without an
     * animation there is nothing to demonstrate, so the flow goes straight to capture.
     */
    var showPreparationScreen: Boolean = false,

    /** Instruction text shown below the circle while the guide animation is playing. */
    var guideInstructionText: String = "Follow the head movement shown in the animation",

    /** Text for the preparation screen start button. */
    var preparationButtonText: String = "Start",

    /** Text color resource for the preparation button. */
    @ColorRes var preparationButtonTextColor: Int = android.R.color.white,

    /** Background color resource for the preparation button. */
    @ColorRes var preparationButtonBackgroundColor: Int = R.color.approve_green,

    /** Corner radius in dp for the preparation button. */
    var preparationButtonRadiusDp: Float = 28f,

    /** Background color resource for the circle overlay during the preparation screen.
     *  Defaults to the same as [V2UIColors.overlayBackgroundColor] if not set (0). */
    @ColorRes var preparationOverlayColor: Int = 0,

    // ── Hex / raw ARGB overrides (set via the String overload of showPreparationScreen)
    // When non-null these take precedence over the @ColorRes counterparts above and are
    // used directly — no ContextCompat.getColor() resolution is needed.

    /** Raw ARGB text color for the preparation button (overrides [preparationButtonTextColor]). */
    @ColorInt var preparationButtonTextColorArgb: Int? = null,

    /** Raw ARGB background color for the preparation button (overrides [preparationButtonBackgroundColor]). */
    @ColorInt var preparationButtonBackgroundColorArgb: Int? = null,

    /** Raw ARGB overlay color for the preparation screen (overrides [preparationOverlayColor]). */
    @ColorInt var preparationOverlayColorArgb: Int? = null,

    // ── Preparation screen animation ─────────────────────────────────────────
    // Configured via V2Builder.preparationAnimation(...)

    /**
     * Raw resource of the Lottie animation played full size on the preparation screen,
     * supplied by the host app.
     *
     * 0 = not supplied; the preparation screen is skipped entirely.
     */
    @RawRes var preparationAnimationRawRes: Int = 0,

    /**
     * Color resource of the disc painted behind the head on the preparation screen.
     * 0 = black.
     */
    @ColorRes var preparationAnimationBackgroundColor: Int = 0,

    /**
     * Raw ARGB color of the disc behind the head
     * (overrides [preparationAnimationBackgroundColor]).
     */
    @ColorInt var preparationAnimationBackgroundColorArgb: Int? = null,

    /** Opacity of the preparation screen animation, 0f (invisible) to 1f (opaque). */
    var preparationAnimationOpacity: Float = 1f,

    // ── Processing screen animation ──────────────────────────────────────────
    // Configured via V2Builder.processingAnimation(...)

    /**
     * Raw resource of the Lottie animation played as the direction hint in the centre of the
     * camera circle while the user rotates, supplied by the host app.
     *
     * 0 = not supplied; the centre hint is skipped and the overlay falls back to its own
     * spinning direction arrow.
     */
    @RawRes var processingAnimationRawRes: Int = 0,

    /**
     * Opacity of everything the processing screen draws in the centre of the circle: the
     * direction hint animation and the [faceGuideDrawable] icon that precedes it.
     */
    var processingAnimationOpacity: Float = 1f,

) : Parcelable
