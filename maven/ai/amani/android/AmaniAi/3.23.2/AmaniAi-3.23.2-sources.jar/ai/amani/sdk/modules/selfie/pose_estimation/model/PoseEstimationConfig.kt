package ai.amani.sdk.modules.selfie.pose_estimation.model

import ai.amani.R
import android.os.Parcelable
import androidx.annotation.DrawableRes
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

/**
 * @Author: zekiamani
 * @Date: 5.08.2022
 */

@Parcelize
data class PoseEstimationConfig(
    @SerializedName("uiColors")
    var uiColors : UIColors = UIColors(),

    @SerializedName("uiTexts")
    var uiTexts: UITexts = UITexts(),

    @SerializedName("uiVisibility")
    var uiVisibilities: UIVisibility = UIVisibility(),

    @SerializedName("uiVisibility")
    var uiDrawables: UIDrawables = UIDrawables(),

    @SerializedName("selfieType")
    var selfieType: Int = 2, // Represents how many pose will be requested

    @SerializedName("maxAttempt")
    var maxAttempt: Int = 3, // Max attempt of retrying the PoseEstimation

    @SerializedName("ovalViewAnimationDuration")
    var ovalViewAnimationDurationMilSec: Int = 3000,

    @SerializedName("recordVideo")
    var recordVideo: Boolean = false

) : Parcelable

@Parcelize
data class UIColors(
    @SerializedName("ovalViewStartColor")
    var ovalViewStartColor: Int = R.color.amani_blue,

    @SerializedName("ovalViewErrorColor")
    var ovalViewErrorColor: Int = R.color.error_red,

    @SerializedName("ovalViewSuccessColor")
    var ovalViewSuccessColor: Int = R.color.approve_green,

    @SerializedName("appFontColor")
    var appFontColor: Int = R.color.white,

    @SerializedName("alertFontTitleColor")
    var alertFontTitleColor: Int = R.color.color_black,

    @SerializedName("alertFontDescriptionColor")
    var alertFontDescriptionColor: Int = R.color.color_black,

    @SerializedName("alertFontTryAgainColor")
    var alertFontTryAgainColor: Int = R.color.color_black,

    @SerializedName("alertBackgroundColor")
    var alertBackgroundColor: Int = R.color.white

) : Parcelable

@Parcelize
data class UITexts(
    @SerializedName("faceTooFar")
    var faceTooFar: String = "Your face is too far from camera",

    @SerializedName("faceNotStraight")
    var faceNotStraight: String = "Your face is not straight",

    @SerializedName("faceNotInside")
    var faceNotInside: String = "Your face is not inside the area",

    @SerializedName("holdPhoneVertically")
    var holdPhoneVertically: String = "Please be sure to keeping phone as straight position",

    @SerializedName("alertTitle")
    var alertTitle: String = "Verification Failed",

    @SerializedName("alertDescription")
    var alertDescription: String = "You did not pass verification. Press the button to try again.",

    @SerializedName("alertTryAgain")
    var alertTryAgain: String = "Try Again",

    @SerializedName("turnLeft")
    var turnLeft: String = "Turn your head left",

    @SerializedName("turnRight")
    var turnRight: String = "Turn your head right",

    @SerializedName("turnUp")
    var turnUp: String = "Turn your head up",

    @SerializedName("turnDown")
    var turnDown: String = "Turn your head down",

    @SerializedName("lookStraight")
    var faceStraight: String = "Look straight to camera",

    @SerializedName("keepEyesOpenAndFaceStraight")
    var keepEyesOpenAndFaceStraight: String = "Please keep your eyes open and look straight at the camera"

    ) : Parcelable

@Parcelize
data class UIDrawables(
    @SerializedName("mainGuideLeft")
    @DrawableRes var mainGuideLeft: Int = R.drawable.ic_face_turn_left,

    @SerializedName("mainGuideRight")
    @DrawableRes var mainGuideRight: Int = R.drawable.ic_face_turn_right,

    @SerializedName("mainGuideUp")
    @DrawableRes var mainGuideUp: Int = R.drawable.ic_face_turn_up,

    @SerializedName("mainGuideDown")
    @DrawableRes var mainGuideDown: Int = R.drawable.ic_face_turn_down,

    @SerializedName("mainGuideStraight")
    @DrawableRes var mainGuideStraight: Int = R.drawable.ic_face_straight,

    @SerializedName("secondaryGuideLeft")
    @DrawableRes var secondaryGuideLeft: Int = R.drawable.arrow_left,

    @SerializedName("secondaryGuideRight")
    @DrawableRes var secondaryGuideRight: Int = R.drawable.arrow_right,

    @SerializedName("secondaryGuideUp")
    @DrawableRes var secondaryGuideUp: Int = R.drawable.arrow_up,

    @SerializedName("secondaryGuideDown")
    @DrawableRes var secondaryGuideDown: Int = R.drawable.arrow_down,

): Parcelable
@Parcelize
data class UIVisibility(
    @SerializedName("mainGuideVisibility")
    var mainGuideVisibility: Boolean = true,

    @SerializedName("secondaryGuideVisibility")
    var secondaryGuideVisibility: Boolean = true,

): Parcelable