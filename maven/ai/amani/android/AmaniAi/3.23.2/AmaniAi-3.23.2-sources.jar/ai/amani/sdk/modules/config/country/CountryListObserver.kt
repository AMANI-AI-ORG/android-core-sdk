package ai.amani.sdk.modules.config.country

import datamanager.model.digitalcontract.Country

/**
 * @Author: zekiamani
 * @Date: 4.07.2022
 */
interface CountryListObserver {

    fun result(resCountryList: List<Country?>?, throwable: Throwable? = null)
}