package ai.amani.sdk.model.mrz

import com.google.gson.annotations.SerializedName

/**
 * @Author: zekiamani
 * @Date: 1.12.2022
 */

/**
 * SDK CallBack Model
 */
data class MRZResult (
    @SerializedName("MRZBirthDate")
    val mRZBirthDate: String?,
    @SerializedName("MRZDocumentNumber")
    val mRZDocumentNumber: String?,
    @SerializedName("MRZExpiryDate")
    val mRZExpiryDate: String?,
    @SerializedName("MRZIDNumber")
    val mRZIDNumber: Any? = null,
)
