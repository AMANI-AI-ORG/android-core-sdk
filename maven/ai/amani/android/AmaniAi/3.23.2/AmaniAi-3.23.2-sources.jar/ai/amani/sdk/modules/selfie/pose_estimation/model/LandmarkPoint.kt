package ai.amani.sdk.modules.selfie.pose_estimation.model

import android.graphics.Bitmap
import ml_amani.face.landmark.models.FaceMeshResult


data class LandmarkPoint(
    val rightX: Float?,
    val rightY: Float?,
    val rightZ: Float?,
    val leftX: Float?,
    val leftZ: Float?,
    val noseZ: Float?,
    val topY: Float?,
    val topZ: Float?,
    val bottomY: Float?,
    val bottomZ: Float?,
    val allPoints: FaceMeshResult,
    val inputBitmap: Bitmap?,
)
