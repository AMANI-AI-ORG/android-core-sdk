package ai.amani.sdk.interfaces

/**
 * Wraps a (isSuccess, documentID) lambda into an [IUploadCallBack], so callers who want the
 * v2 upload response's documentID can pass this to any `upload(...)` function without having
 * to write an `object : IUploadCallBack` themselves or implement the legacy single-arg `cb`.
 */
fun uploadCallBack(callBack: (isSuccess: Boolean, documentID: String?) -> Unit): IUploadCallBack =
    object : IUploadCallBack {
        // Forwards to the lambda with a null id rather than swallowing the call: a one-argument
        // invocation still has to reach the caller.
        override fun cb(isSuccess: Boolean) = callBack(isSuccess, null)
        override fun cb(isSuccess: Boolean, documentID: String?) {
            callBack(isSuccess, documentID)
        }
    }
