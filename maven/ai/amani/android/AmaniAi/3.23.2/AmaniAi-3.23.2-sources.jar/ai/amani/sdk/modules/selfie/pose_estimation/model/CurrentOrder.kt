package ai.amani.sdk.modules.selfie.pose_estimation.model

data class CurrentOrder(
    val isSuccess: Boolean,
    val number: Int
)
