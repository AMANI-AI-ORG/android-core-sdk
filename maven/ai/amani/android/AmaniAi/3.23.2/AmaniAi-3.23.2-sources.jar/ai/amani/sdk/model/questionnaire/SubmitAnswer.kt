package ai.amani.sdk.model.questionnaire

import com.google.gson.annotations.SerializedName

data class SubmitAnswer(
    @SerializedName("multiple_option_answer")
    val multipleOptionAnswer: List<String>? = null,
    @SerializedName("question")
    val question: String?,
    @SerializedName("single_option_answer")
    val singleOptionAnswer: String? = null,
    @SerializedName("typed_answer")
    val typedAnswer: String? = null
)