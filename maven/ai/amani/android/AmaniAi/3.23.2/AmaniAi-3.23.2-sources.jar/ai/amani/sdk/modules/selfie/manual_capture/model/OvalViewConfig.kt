package ai.amani.sdk.modules.selfie.manual_capture.model

import com.google.gson.annotations.SerializedName

/**
 * @Author: zekiamani
 * @Date: 18.11.2022
 */
data class OvalViewConfig(
    @SerializedName("appBackgroundColor")
    var appBackgroundColor: String = "#ffffff",

    @SerializedName("ovalViewColor")
    var ovalViewColor: String = "#ffffff",
)