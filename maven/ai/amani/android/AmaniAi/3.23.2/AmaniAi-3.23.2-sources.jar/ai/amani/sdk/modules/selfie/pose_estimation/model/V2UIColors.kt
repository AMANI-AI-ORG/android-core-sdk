package ai.amani.sdk.modules.selfie.pose_estimation.model

import ai.amani.R
import android.os.Parcelable
import androidx.annotation.ColorRes
import kotlinx.parcelize.Parcelize

/**
 * Colour configuration for the v2 360° rotation liveness challenge.
 *
 * All fields are colour **resource IDs** (e.g. [R.color.approve_green]).
 * Progress is always shown in a single colour ([progressRingColor]) for
 * both in-progress and completed arc segments.
 */
@Parcelize
data class V2UIColors(

    /** Colour of the full-screen overlay that surrounds the camera oval. */
    @ColorRes var overlayBackgroundColor: Int = R.color.pose_estimation_v2_overlay,

    /** Colour of the progress ring arc (both in-progress and completed segments). */
    @ColorRes var progressRingColor: Int = R.color.approve_green,

    /** Colour of the dim background ring track behind the progress arc. */
    @ColorRes var progressRingTrackColor: Int = R.color.ring_track_gray,

    /** Colour of the spinning direction arrow drawn inside the oval. */
    @ColorRes var directionArrowColor: Int = R.color.white,

    /** Colour of the instruction text shown below the oval. */
    @ColorRes var appFontColor: Int = R.color.white,

    /** Text colour for the retry alert dialog title. */
    @ColorRes var alertFontTitleColor: Int = R.color.color_black,

    /** Text colour for the retry alert dialog description. */
    @ColorRes var alertFontDescriptionColor: Int = R.color.color_black,

    /** Text colour for the retry alert dialog "try again" button. */
    @ColorRes var alertFontTryAgainColor: Int = R.color.color_black,

    /** Background colour for the retry alert dialog. */
    @ColorRes var alertBackgroundColor: Int = R.color.white,

) : Parcelable
