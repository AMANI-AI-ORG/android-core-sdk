package ai.amani.sdk.interfaces

interface ExceptionCallBack {
 
     fun onException(exception: Exception)
 }