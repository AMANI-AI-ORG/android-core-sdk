package ai.amani.sdk.modules.document

import com.google.gson.annotations.SerializedName

data class FileWithType(
    @SerializedName("byteArray") val byteArray: ByteArray,
    @SerializedName("type") val type: String
)
