package ai.amani.sdk.model.questionnaire


data class QuestionnaireModel (
    val questions: ArrayList<QuestionnaireItem>
)