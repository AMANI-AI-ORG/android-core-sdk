package ai.amani.sdk.model.amani_events.profile_status


import com.google.gson.annotations.SerializedName

data class ProfileStatus(
    @SerializedName("aml_status")
    val amlStatus: Boolean?,
    @SerializedName("risk")
    val risk: String?,
    @SerializedName("status")
    val status: String?,
    @SerializedName("profile")
    val profile: String?
)