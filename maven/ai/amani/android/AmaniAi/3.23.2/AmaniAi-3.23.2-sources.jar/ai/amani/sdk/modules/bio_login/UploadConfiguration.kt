package ai.amani.sdk.modules.bio_login

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

/**
 * @Author: zekiamani
 * @Date: 23.11.2022
 */
@Parcelize
data class UploadConfiguration(
    @SerializedName("comparisonAdapter")
    val comparisonAdapter: Int = 2,
    @SerializedName("source")
    val source: Int = 3,
    @SerializedName("attemptId")
    val attemptId: String? = null,
    @SerializedName("type")
    val type: Int= 0 // Type will be static as always, it gives information about the uploaded
):Parcelable         // data's type. The data type is for 0 it means IMAGE. It will not be dynamic for while

