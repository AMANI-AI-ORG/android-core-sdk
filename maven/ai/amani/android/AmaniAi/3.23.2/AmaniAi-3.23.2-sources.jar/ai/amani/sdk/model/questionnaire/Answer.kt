package ai.amani.sdk.model.questionnaire


import com.google.gson.annotations.SerializedName

data class Answer(
    @SerializedName("id")
    val id: String,
    @SerializedName("title")
    val title: String
)