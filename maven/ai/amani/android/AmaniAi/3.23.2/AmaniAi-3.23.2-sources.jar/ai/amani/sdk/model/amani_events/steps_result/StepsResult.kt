package ai.amani.sdk.model.amani_events.steps_result


data class StepsResult (
   val result: ArrayList<Result>
)
