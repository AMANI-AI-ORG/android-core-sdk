package ai.amani.sdk.modules.selfie.pose_estimation.v2.model

/**
 * High-level UI states emitted by the Pose Estimation v2 liveness flow.
 *
 * Register a listener via
 * [ai.amani.sdk.modules.selfie.pose_estimation.SelfiePoseEstimation.V2Builder.onUiStateChanged]
 * to observe the flow's progress. All states are delivered on the main thread.
 */
enum class PoseEstimationV2UiState {

    /**
     * The preparation screen (guide video + confirm button) has started being shown.
     *
     * Only emitted when a preparation screen is configured (a guide video URI is set via
     * [ai.amani.sdk.modules.selfie.pose_estimation.SelfiePoseEstimation.V2Builder.showPreparationScreen]).
     * Flows without a preparation screen go straight to [CAPTURE_STARTED].
     */
    PREPARATION_STARTED,

    /** The user tapped the preparation screen's confirm button (once per tap). */
    PREPARATION_CONFIRMED,

    /**
     * The capture / liveness flow has begun: the camera has been opened and bound.
     * Emitted once per fragment instance, when the camera first opens.
     */
    CAPTURE_STARTED
}
