package ai.amani.sdk.modules.config.country

/**
 * @Author: zekiamani
 * @Date: 4.07.2022
 */
interface ICountryList {

    fun getCountryList(observer: CountryListObserver)
}