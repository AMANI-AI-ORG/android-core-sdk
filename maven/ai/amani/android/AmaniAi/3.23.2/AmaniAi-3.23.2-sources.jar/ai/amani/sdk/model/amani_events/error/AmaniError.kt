package ai.amani.sdk.model.amani_events.error

import ai.amani.base.util.JSONConvertable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class AmaniError(
    @SerializedName("error_code")
    @Expose
    val errorCode: Any? = null,
    @SerializedName("error_message")
    @Expose
    val errorMessage: Any? = null
): JSONConvertable