package ai.amani.sdk.modules.selfie.auto_capture

import ai.amani.R
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class ASCBuilder(
        @SerializedName("messageTextColor")
        var messageTextColor: Int? = R.color.white,

        @SerializedName("messageTextSize")
        val messageTextSize: Int? = 20,

        @SerializedName("counterTextColor")
        var counterTextColor: Int? = R.color.white,

        @SerializedName("counterTextVisibility")
        val counterTextVisibility: Boolean? = false,

        @SerializedName("counterTextSize")
        val counterTextSize: Int? = 8,

        @SerializedName("timeOutManualButton")
        var timeOutManualButton: Int? = 30,

        @SerializedName("closeEnoughMessageText")
        var closeEnoughMessageText: String? = "Please close enough",

        @SerializedName("faceNotFoundMessageText")
        var faceNotFoundMessageText: String? = "Face is not found",

        @SerializedName("holdStableMessageText")
        var holdStableMessageText: String? = "Please hold stable",

        @SerializedName("failureMessageText")
        var failureMessageText: String? = "",

        @SerializedName("ovalColor")
        var ovalColor: Int? = R.color.white,

        @SerializedName("successColor")
        var successColor: Int? = R.color.approve_green,

        @SerializedName("photoShootCountdownMilliseconds")
        var photoShootCountDownMilliseconds: Int? = null,

        @SerializedName("colorManualButton")
        var colorManualButton: Int? = R.color.white,

        /**
         * Shown while the face is inside the oval but turned, tilted, or looking up or down, and
         * when the photo is rejected for that reason. Empty (the default) shows no message.
         */
        @SerializedName("faceNotStraightMessageText")
        var faceNotStraightMessageText: String? = ""

):Parcelable