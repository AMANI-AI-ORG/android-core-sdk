package ai.amani.sdk.model.amani_events.steps_result


import ai.amani.base.util.JSONConvertable
import com.google.gson.annotations.SerializedName
import com.google.gson.annotations.Expose

data class Errors(
    @SerializedName("error_code")
    @Expose
    val errorCode: Int?,
    @SerializedName("error_message")
    @Expose
    val errorMessage: Any?
):JSONConvertable