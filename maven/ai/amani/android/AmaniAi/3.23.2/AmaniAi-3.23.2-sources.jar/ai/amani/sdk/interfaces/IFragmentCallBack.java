package ai.amani.sdk.interfaces;

import android.graphics.Bitmap;

import androidx.annotation.Nullable;

import java.io.File;

public interface IFragmentCallBack{

     /**
      *--- Fragment CallBack---
      * @param bitmap returns bitmap when process is done.
      * @param manualButtonActivated returns true if fragment is destroyed for some reasons.
      * @param file it returns file only Selfie methods. It returns null other methods.
      */
     void cb(@Nullable Bitmap bitmap, @Nullable Boolean manualButtonActivated, @Nullable File file);
}

