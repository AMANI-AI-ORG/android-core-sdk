package ai.amani.sdk.modules.amani_events

import ai.amani.sdk.interfaces.AmaniEventCallBack

/**
 * @Author: zekiamani
 * @Date: 11.11.2022
 */
interface IAmaniEvent {

    fun setListener(event: AmaniEventCallBack)

    fun removeListener()
}

