package ai.amani.sdk.interfaces;

import androidx.annotation.Nullable;

/**
 * @Author: zekiamani
 * @Date: 14.11.2022
 */
public interface BioLoginUploadCallBack {

    /**
     * --- BioLogin Upload CallBack ---
     * @param result Boo value if uploading the bio login selfie is success or not.
     */
    void cb(@Nullable Boolean result);

    /**
     * --- BioLogin Upload CallBack ---
     * @param result Boo value if uploading the bio login selfie is success or not.
     * @param documentID id of uploaded document, returned by backend on success. Null when the
     *                   backend does not return one, or when the upload fails.
     */
    default void cb(@Nullable Boolean result, @Nullable String documentID) {
        cb(result);
    }

}
