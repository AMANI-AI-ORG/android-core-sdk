package ai.amani.sdk.interfaces

import android.graphics.Bitmap


interface NfcResultCallBack {

    fun onSuccess(photo: Bitmap?, mrz: String?)

    fun onError(error: String?)
}