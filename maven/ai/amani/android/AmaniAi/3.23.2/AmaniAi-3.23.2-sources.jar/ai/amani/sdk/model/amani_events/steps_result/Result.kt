package ai.amani.sdk.model.amani_events.steps_result


import com.google.gson.annotations.SerializedName

data class Result(
    @SerializedName("id")
    val id: String?,
    @SerializedName("status")
    val status: String?,
    @SerializedName("sortOrder")
    val sortOrder: Int?,
    @SerializedName("errors")
    val errors: List<Errors?>?,
    @SerializedName("title")
    val title: String?,
    @SerializedName("uploadSource")
    val uploadSource: String = "KYC",
    /** Id of the document the step belongs to, when the backend names one. */
    @SerializedName("documentId")
    val documentId: String? = null,
    /** True when the step may be skipped; null when the backend did not say. */
    @SerializedName("optional")
    val optional: Boolean? = null
)