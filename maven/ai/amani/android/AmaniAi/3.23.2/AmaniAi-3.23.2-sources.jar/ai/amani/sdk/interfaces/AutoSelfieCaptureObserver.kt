package ai.amani.sdk.interfaces

import android.graphics.Bitmap

/**
 * @Author: zekiamani
 * @Date: 17.11.2022
 */
interface AutoSelfieCaptureObserver {
    fun cb(bitmap: Bitmap?)
}