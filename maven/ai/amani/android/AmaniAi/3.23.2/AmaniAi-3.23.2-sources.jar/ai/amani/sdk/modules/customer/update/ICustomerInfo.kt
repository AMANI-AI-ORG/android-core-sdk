package ai.amani.sdk.modules.customer.update

import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.interfaces.PINCallback
import ai.amani.sdk.interfaces.TermsConditionsCallback

interface ICustomerInfo {

    fun upload (callBack: IUploadCallBack)

    fun sendEmailOTP(callBack: IUploadCallBack)

    fun submitEmailOTP(otp: String, callBack: IUploadCallBack)

    fun sendPhoneOTP(callBack: IUploadCallBack)

    fun submitPhoneOTP(otp: String, callBack: IUploadCallBack)

    fun enablePin(pin: String, callback: PINCallback)

    fun disablePin(callback: PINCallback)

    fun acceptTermsConditions(callback: TermsConditionsCallback)
}