package ai.amani.sdk.interfaces

interface TermsConditionsCallback {

    /**
     * Called when the accept terms request completes successfully.
     */
    fun onSuccess()

    /**
     * Called when an error occurs during the request.
     *
     * @param exception The exception that occurred.
     */
    fun onError(exception: Exception)
}