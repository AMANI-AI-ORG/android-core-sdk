package ai.amani.sdk.modules.signature.interfaces

interface ISignatureCallBack {
    fun cb(isSuccess: Boolean)
}
