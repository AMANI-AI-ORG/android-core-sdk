package ai.amani.sdk.modules.selfie.manual_capture

import ai.amani.base.logger.core.ActionTypes
import ai.amani.base.logger.local.AmaniLog
import ai.amani.base.logger.local.LogArea
import ai.amani.base.logger.local.LogFormat
import ai.amani.base.logger.util.OperationIdProvider
import ai.amani.base.util.SessionManager
import ai.amani.base.utility.AppConstants
import ai.amani.sdk.Amani
import ai.amani.sdk.interfaces.ExceptionCallBack
import ai.amani.sdk.interfaces.IFragmentCallBack
import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.model.amani_events.error.AmaniError
import ai.amani.sdk.model.amani_events.error.AmaniErrorTypes
import ai.amani.sdk.modules.amani_events.AmaniEvent
import ai.amani.sdk.modules.selfie.manual_capture.upload.UploadSelfie
import ai.amani.sdk.modules.selfie.manual_capture.upload.v2.UploadSelfieV2
import ai.amani.sdk.modules.selfie.manual_capture.view.SelfieCaptureFrag
import ai.amani.sdk.service.upload.ErrorConstants.Companion.CONFIG_ERROR
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity

object Selfie {
    var callBackF: IFragmentCallBack? = null
    var callBackU: IUploadCallBack? = null
    private var exceptionCallBack: ExceptionCallBack? = null
    private var textPaddingLeft = 20
    private var textPaddingTop: Int? = null
    private var textPaddingRight = 20
    /**
     * Unique ID for each session start to end
     */
    private var operationID : String = ""

    fun start(docType: String, callBack: IFragmentCallBack?): Fragment? {
        this.operationID = OperationIdProvider.startNew()
        AmaniLog.essential(LogArea.SELFIE) { "manual selfie started docType=$docType op=${LogFormat.op(operationID)}" }
        this.callBackF = callBack
        return startSelfie(docType)
    }

    fun setTextPaddings(left: Int, top: Int = -999, right: Int) = apply {
        textPaddingLeft = left
        textPaddingTop = top
        textPaddingRight = right
    }

    fun onException(exception: ExceptionCallBack) = apply {
        this.exceptionCallBack = exception
    }

    fun upload(activity: FragmentActivity, docType: String, callBack: IUploadCallBack?) {
        this.callBackU = callBack?.let { AmaniEvent.observeUpload(it) }
        uploadSelfie(activity, docType)
    }

    private fun startSelfie(docType: String): Fragment? {
        val selfieCaptureFrag = SelfieCaptureFrag()
        val arg = Bundle()

        try {
            arg.putParcelable(AppConstants.KEY_VERSION_LIST, SessionManager.getVersion(docType))
            arg.putString(AppConstants.OPERATION_ID, operationID)
            arg.putInt(AppConstants.ARG_TEXT_PADDING_LEFT, textPaddingLeft)
            arg.putInt(AppConstants.ARG_TEXT_PADDING_RIGHT, textPaddingRight)
            if (textPaddingTop != null) arg.putInt(AppConstants.ARG_TEXT_PADDING_TOP, textPaddingTop!!)
        } catch (e: Exception) {
            val errorList = ArrayList<AmaniError?>()
            errorList.add(CONFIG_ERROR)
            AmaniEvent.getEvent()?.onError(
                AmaniErrorTypes.ID.name,
                errorList
            )
            return null
        }

        selfieCaptureFrag.arguments = arg
        selfieCaptureFrag.fragmentCallBack = callBackF
        return selfieCaptureFrag
    }

    private fun uploadSelfie(activity: FragmentActivity, docType: String) {
        when (Amani.VERSION.version) {
            "v1" -> {
                val uploadSelfie = UploadSelfie()
                uploadSelfie.iUploadCallBack = callBackU
                uploadSelfie.UploadSelfie(activity, docType)
            }

            "v2" -> {
                val uploadSelfieV2 = UploadSelfieV2()
                uploadSelfieV2.uploadSelfie(
                    iUploadCallBack = callBackU!!,
                    activity = activity,
                    docType = docType,
                    operationID = this.operationID,
                    actionType = ActionTypes.SELFIE_UPLOAD_RESP
                )
            }
        }
    }
}
