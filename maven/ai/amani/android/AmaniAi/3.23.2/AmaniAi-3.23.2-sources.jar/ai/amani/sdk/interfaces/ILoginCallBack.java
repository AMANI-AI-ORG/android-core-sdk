package ai.amani.sdk.interfaces;

import androidx.annotation.Nullable;

public interface ILoginCallBack {

    /**
     *--- Login CallBack ---
     * @param isSuccess if the login process is done successfully, returns true.
     */
    void cb(boolean isSuccess);
}
