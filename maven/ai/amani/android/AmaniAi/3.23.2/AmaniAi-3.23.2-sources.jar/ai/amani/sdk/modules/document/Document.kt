package ai.amani.sdk.modules.document

import ai.amani.R
import ai.amani.base.logger.core.ActionTypes
import ai.amani.base.logger.local.AmaniLog
import ai.amani.base.logger.local.LogArea
import ai.amani.base.logger.local.LogFormat
import ai.amani.base.logger.util.OperationIdProvider
import ai.amani.base.util.AppPreferenceKey
import ai.amani.base.util.SessionManager
import ai.amani.base.utility.AppConstants
import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.mapper.AmaniEventMapper.asAmaniEventType
import ai.amani.sdk.modules.amani_events.AmaniEvent
import ai.amani.sdk.modules.document.interfaces.IDocumentCallBack
import ai.amani.sdk.modules.document.upload.UploadDocument
import ai.amani.sdk.modules.document.view.DocumentFragment
import ai.amani.sdk.modules.document_capture.camera.BitmapUtils
import ai.amani.sdk.service.upload.ErrorConstants
import android.os.Bundle
import android.widget.FrameLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import java.io.FileNotFoundException

object Document {

   private var callBackD: IDocumentCallBack? = null
   private var callBackU: IUploadCallBack? = null
   private var mDocBuilder: DocBuilder = DocBuilder(
            "Try Again",  // Try Again label string.
            "Confirm", // Confirm label string
            R.color.white, //
            R.color.white,
            R.color.white,
            1)


    /**
     * Unique ID for each session start to end
     */
    private var operationID : String = ""

    /** Starter function that returns related vies as a Fragment into your frameLayout container.
     *  @param docType: DocumentType as String
     *  @param documentBuilder: It's for customization of the view.
     *  @param frameLayout: Container of the fragment that will return.
     *  @param callBack: Returns specific callback from IFragmentCallBack.
     */
    fun start(docType: String?, documentBuilder: DocBuilder?, frameLayout: FrameLayout, callBack: IDocumentCallBack?): Fragment? {
        operationID = OperationIdProvider.startNew()
        AmaniLog.essential(LogArea.DOCUMENT) { "document capture started docType=$docType op=${LogFormat.op(operationID)}" }
        callBackD = callBack
        return startDocFragment(docType, documentBuilder,frameLayout)
    }

    /** Sets custom UI object.
     *  It must be called before start() function.
     */
    fun setCustomUI(tryAgainText: String, confirmText: String, tryAgainTextColor: Int, confirmTextColor: Int, captureButtonColor: Int, documentCount: Int) {
        mDocBuilder =  DocBuilder(tryAgainText,confirmText,tryAgainTextColor,confirmTextColor,captureButtonColor,documentCount)
    }

    /** Upload given data.
     *  @param data : ByteArray of an image/bitmap or file that fiven from HostApplication(CustomerApp).
     *  @param activity : Activity pointer
     *  @param docType: DocumentType as String
     *  @param callBack: Returns specific callback from IUploadCallBack.
     */
    fun upload(activity: FragmentActivity, docType: String, data: ArrayList<FileWithType>, callBack: IUploadCallBack) {
        callBackU = AmaniEvent.observeUpload(callBack)
        uploadGivenDocument(activity,docType,data)
    }

    /** Uploads directly the data that taken from camera.
     *  This function has to be called after result of start function is properly done.
     */
    fun upload(activity: FragmentActivity,docType: String,callBack: IUploadCallBack) {
        callBackU = AmaniEvent.observeUpload(callBack)
        uploadDocument(activity, docType)
    }

    /** Optional Usage
     * This function delete all related files(list of all documents) that
     * taken and saved from camera. Also it must be called after the upload process done.
     */
    fun deleteAllDocumentCaches(){
        deleteAllCacheFilesSavedFromCamera()
    }

    private fun startDocFragment(
        docType: String?,
        docBuilder: DocBuilder?,
        frameLayout: FrameLayout
    ): Fragment? {
        val documentFragment = DocumentFragment()
        val arg = Bundle()

        try {
            val version = SessionManager.getVersion(docType!!)
            if (version == null) {
                AmaniEvent.getEvent()?.onError(
                    type = docType.asAmaniEventType(),
                    error = arrayListOf(ErrorConstants.CONFIG_ERROR)
                )
                return null
            }
            arg.putParcelable(AppConstants.KEY_VERSION_LIST, version)
        } catch (e: Exception) {
            AmaniEvent.getEvent()?.onError(
                type = docType.asAmaniEventType(),
                error = arrayListOf(ErrorConstants.CONFIG_ERROR)
            )
            return null
        }

        if (docBuilder != null) mDocBuilder = docBuilder

        arg.putParcelable(AppConstants.DOC_BUILDER, mDocBuilder)
        arg.putInt(AppConstants.FRAME_LAYOUT_HEIGHT,frameLayout.height)
        arg.putInt(AppConstants.FRAME_LAYOUT_WIDTH,frameLayout.width)

        documentFragment.arguments = arg
        documentFragment.documentCallBack = callBackD
        return documentFragment
    }

    private fun uploadDocument(activity: FragmentActivity, docType: String) {
        val uploadDocument = UploadDocument()
        uploadDocument.iUploadCallBack = callBackU
        uploadDocument.invoke(
            activity = activity,
            docType = docType,
            data = null,
            operationID = operationID,
            actionType = ActionTypes.DOCUMENT_UPLOAD_RESP
        )
    }

    private fun uploadGivenDocument(activity: FragmentActivity,docType: String, data:ArrayList<FileWithType>) {
        val uploadDocument = UploadDocument()
        uploadDocument.iUploadCallBack = callBackU
        uploadDocument.invoke(
            activity = activity,
            docType = docType,
            data =  data,
            operationID = operationID,
            actionType = ActionTypes.DOCUMENT_UPLOAD_RESP
        )
    }

    private fun deleteAllCacheFilesSavedFromCamera() {
        val docCacheList: ArrayList<String> = SessionManager.getListString(AppPreferenceKey.DOCUMENT_LIST)
        try {
            for (i in docCacheList.indices){
                BitmapUtils.deleteImageFile(docCacheList[i])
            }
        } catch (e : FileNotFoundException){
            AmaniLog.w(LogArea.DOCUMENT, e) { "document cache file not found" }
        } catch (e: Exception) {
            AmaniLog.w(LogArea.DOCUMENT, e) { "document cache clear failed" }
        }
    }
}