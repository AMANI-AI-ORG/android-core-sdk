package ai.amani.sdk.modules.document.interfaces

interface IDocumentCallBack {

   fun cb (listOfDocumentAbsolutePath: ArrayList<String>?, isSuccess: Boolean)
}