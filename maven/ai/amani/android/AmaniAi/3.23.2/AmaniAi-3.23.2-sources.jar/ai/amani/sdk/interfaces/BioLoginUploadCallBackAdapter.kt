package ai.amani.sdk.interfaces

/**
 * Wraps a (result, documentID) lambda into a [BioLoginUploadCallBack], so callers who want the
 * uploaded document's ID can pass this to `BioLogin().upload(...)` without having to write an
 * `object : BioLoginUploadCallBack` themselves or implement the legacy single-arg `cb`.
 */
fun bioLoginUploadCallBack(
    callBack: (result: Boolean?, documentID: String?) -> Unit
): BioLoginUploadCallBack =
    object : BioLoginUploadCallBack {
        // Forwards to the lambda with a null id rather than swallowing the call: a one-argument
        // invocation still has to reach the caller.
        override fun cb(result: Boolean?) = callBack(result, null)
        override fun cb(result: Boolean?, documentID: String?) {
            callBack(result, documentID)
        }
    }
