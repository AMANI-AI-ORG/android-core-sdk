package ai.amani.sdk.modules.selfie.pose_estimation

import ai.amani.sdk.modules.amani_events.AmaniEvent
import ai.amani.base.annotiations.AmaniExperimental
import ai.amani.base.annotiations.Mandatory
import ai.amani.base.annotiations.NonMandatory
import ai.amani.base.logger.core.ActionTypes
import ai.amani.base.logger.local.AmaniLog
import ai.amani.base.logger.local.LogArea
import ai.amani.base.logger.local.LogFormat
import ai.amani.base.logger.util.OperationIdProvider
import ai.amani.base.util.SessionManager
import ai.amani.base.utility.AppConstants
import ai.amani.base.view.BaseFragment
import ai.amani.sdk.interfaces.ExceptionCallBack
import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.modules.selfie.pose_estimation.SelfiePoseEstimation.upload
import ai.amani.sdk.modules.selfie.pose_estimation.model.PoseEstimationConfig
import ai.amani.sdk.modules.selfie.pose_estimation.model.PoseEstimationV2Config
import ai.amani.sdk.modules.selfie.pose_estimation.observable.PoseEstimationObserver
import ai.amani.sdk.modules.selfie.pose_estimation.ui.fragment.SelfiePoseEstimationFrag
import ai.amani.sdk.modules.selfie.pose_estimation.v2.model.PoseEstimationV2UiState
import ai.amani.sdk.modules.selfie.pose_estimation.usecase.UploadPoseEstimationUseCase
import ai.amani.sdk.modules.selfie.pose_estimation.usecase.UploadVideoRecordUseCase
import ai.amani.sdk.modules.selfie.pose_estimation.util.ColorValidator
import ai.amani.sdk.modules.selfie.pose_estimation.v2.ui.SelfiePoseEstimationV2Frag
import android.app.Activity
import android.content.Context
import android.os.Bundle
import androidx.annotation.ColorRes
import androidx.annotation.DrawableRes
import androidx.annotation.RawRes
import androidx.core.graphics.toColorInt
import datamanager.repomanager.id_video.UploadIDVideoImp
import datamanager.v2.repomanager.video_record.UploadVideoRecordImp

/**
 * Entry point for the Selfie Pose-Estimation liveness challenge.
 *
 * Choose the flow variant first — each entry point returns a typed builder that
 * only exposes the configuration options relevant to that variant:
 *
 * ```kotlin
 * // Default discrete-pose flow: LEFT / RIGHT / UP / DOWN
 * val fragment = SelfiePoseEstimation.Builder()
 *     .documentType("XXX_SE_0")
 *     .requestedPoseNumber(2)
 *     .userInterfaceColors(...)
 *     .userInterfaceTexts(...)
 *     .observe(myObserver)
 *     .build(context)
 *
 * // 360° continuous head-rotation flow with arc progress ring
 * val fragment = SelfiePoseEstimation.BuilderV2()
 *     .documentType("XXX_SE_0")
 *     .userInterfaceColors(...)   // v2-specific colour params only
 *     .userInterfaceTexts(...)    // v2-specific text params only
 *     .observe(myObserver)
 *     .build(context)
 * ```
 *
 * Call [upload] after a successful result to submit the captured selfie and optional video.
 *
 * @Author: zekiamani
 * @Date: 2.08.2022
 */
object SelfiePoseEstimation {


    // Shared state written by whichever builder calls build(), read by upload()
    internal var _operationID: String = ""
    internal var _docType: String = "XXX_SE_0"
    internal var _recordVideo: Boolean = false

    /**
     * Returns a [V1Builder] for the classic discrete-pose flow (LEFT / RIGHT / UP / DOWN).
     * This is the default liveness variant — existing callers continue to work unchanged.
     */
    fun Builder(): V1Builder = V1Builder()

    /**
     * Returns a [V2Builder] for the continuous 360° head-rotation flow.
     *
     * Only exposes configuration relevant to the rotation challenge
     * (ring colours, rotation texts, face guide drawable). Discrete-pose options
     * such as [V1Builder.requestedPoseNumber] or [V1Builder.userInterfaceDrawables]
     * are intentionally absent to prevent confusion.
     */
    @AmaniExperimental
    fun BuilderV2(): V2Builder = V2Builder()

    /**
     * Uploads the selfie captured during the last completed session.
     * Call this from your [PoseEstimationObserver.onSuccess] handler.
     */
    fun upload(context: Activity, docType: String, callback: IUploadCallBack) {
        val uploadSelfie = UploadPoseEstimationUseCase(
            UploadVideoRecordUseCase(UploadVideoRecordImp(), UploadIDVideoImp())
        )
        uploadSelfie.iUploadCallBack = AmaniEvent.observeUpload(callback)
        uploadSelfie.uploadSelfie(
            activity = context,
            docType = docType,
            videoRecord = _recordVideo,
            operationID = _operationID,
            actionType = ActionTypes.POSE_ESTIMATION_UPLOAD_RESP
        )
    }

    // ─────────────────────────────────────────────────────────────────────────
    // V1 Builder — discrete pose flow (LEFT / RIGHT / UP / DOWN)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Builder for the classic discrete-pose selfie liveness challenge.
     *
     * Returned by [SelfiePoseEstimation.Builder]. Only discrete-pose options
     * appear in IDE autocomplete — head-rotation settings are absent.
     */
    class V1Builder {

        private val config = PoseEstimationConfig()
        private val colorValidator = ColorValidator()
        private lateinit var observer: PoseEstimationObserver
        private var exceptionCallBack: ExceptionCallBack? = null

        @Mandatory
        fun documentType(documentType: String) = apply {
            _docType = documentType
        }

        /**
         * Sets all eight UI colours at once. If any parameter is null the whole call is ignored
         * and default colours are used.
         */
        @NonMandatory("Has default values")
        fun userInterfaceColors(
            ovalViewStartColor: Int?,
            ovalViewSuccessColor: Int?,
            ovalViewErrorColor: Int?,
            alertTitleFontColor: Int?,
            alertDescriptionFontColor: Int?,
            alertTryAgainFontColor: Int?,
            alertBackgroundFontColor: Int?,
            appFontColor: Int?
        ) = apply {
            if (ovalViewErrorColor != null
                && ovalViewStartColor != null
                && ovalViewSuccessColor != null
                && appFontColor != null
                && alertTitleFontColor != null
                && alertDescriptionFontColor != null
                && alertTryAgainFontColor != null
                && alertBackgroundFontColor != null
            ) {
                config.uiColors.also {
                    it.appFontColor = appFontColor
                    it.ovalViewErrorColor = ovalViewErrorColor
                    it.ovalViewStartColor = ovalViewStartColor
                    it.ovalViewSuccessColor = ovalViewSuccessColor
                    it.alertFontDescriptionColor = alertDescriptionFontColor
                    it.alertBackgroundColor = alertBackgroundFontColor
                    it.alertFontTitleColor = alertTitleFontColor
                    it.alertFontTryAgainColor = alertTryAgainFontColor
                }
            }
        }

        /** Overrides any subset of the 13 instruction / alert texts. */
        @NonMandatory("Has default values")
        fun userInterfaceTexts(
            faceNotInside: String? = null,
            faceNotStraight: String? = null,
            faceIsTooFar: String? = null,
            holdPhoneVertically: String? = null,
            alertTitle: String? = null,
            alertDescription: String? = null,
            alertTryAgain: String? = null,
            turnLeft: String? = null,
            turnRight: String? = null,
            turnUp: String? = null,
            turnDown: String? = null,
            faceStraight: String? = null,
            keepEyesOpenAndFaceStraight: String? = null
        ) = apply {
            config.uiTexts.also {
                if (faceNotInside != null) it.faceNotInside = faceNotInside
                if (faceNotStraight != null) it.faceNotStraight = faceNotStraight
                if (faceIsTooFar != null) it.faceTooFar = faceIsTooFar
                if (holdPhoneVertically != null) it.holdPhoneVertically = holdPhoneVertically
                if (alertDescription != null) it.alertDescription = alertDescription
                if (alertTitle != null) it.alertTitle = alertTitle
                if (alertTryAgain != null) it.alertTryAgain = alertTryAgain
                if (turnLeft != null) it.turnLeft = turnLeft
                if (turnRight != null) it.turnRight = turnRight
                if (turnUp != null) it.turnUp = turnUp
                if (turnDown != null) it.turnDown = turnDown
                if (faceStraight != null) it.faceStraight = faceStraight
                if (keepEyesOpenAndFaceStraight != null)
                    it.keepEyesOpenAndFaceStraight = keepEyesOpenAndFaceStraight
            }
        }

        /** Overrides any of the nine guide drawables shown during the v1 pose flow. */
        @NonMandatory("Has default values")
        fun userInterfaceDrawables(
            @DrawableRes mainGuideLeft: Int? = null,
            @DrawableRes mainGuideRight: Int? = null,
            @DrawableRes mainGuideUp: Int? = null,
            @DrawableRes mainGuideDown: Int? = null,
            @DrawableRes mainGuideStraight: Int? = null,
            @DrawableRes secondaryGuideLeft: Int? = null,
            @DrawableRes secondaryGuideRight: Int? = null,
            @DrawableRes secondaryGuideUp: Int? = null,
            @DrawableRes secondaryGuideDown: Int? = null,
        ) = apply {
            config.uiDrawables.also {
                if (mainGuideLeft != null) it.mainGuideLeft = mainGuideLeft
                if (mainGuideRight != null) it.mainGuideRight = mainGuideRight
                if (mainGuideUp != null) it.mainGuideUp = mainGuideUp
                if (mainGuideDown != null) it.mainGuideDown = mainGuideDown
                if (mainGuideStraight != null) it.mainGuideStraight = mainGuideStraight
                if (secondaryGuideLeft != null) it.secondaryGuideLeft = secondaryGuideLeft
                if (secondaryGuideRight != null) it.secondaryGuideRight = secondaryGuideRight
                if (secondaryGuideUp != null) it.secondaryGuideUp = secondaryGuideUp
                if (secondaryGuideDown != null) it.secondaryGuideDown = secondaryGuideDown
            }
        }

        @NonMandatory("Has default values as true")
        fun userInterfaceVisibilities(
            mainGuideVisibility: Boolean = true,
            secondaryGuideVisibility: Boolean = true
        ) = apply {
            config.uiVisibilities.also {
                it.mainGuideVisibility = mainGuideVisibility
                it.secondaryGuideVisibility = secondaryGuideVisibility
            }
        }

        /** Number of random poses to request (must be ≥ 1, default 2). */
        @Throws
        @NonMandatory("Has default value as 2")
        fun requestedPoseNumber(numberOfPose: Int = 2) = apply {
            if (numberOfPose >= 1) {
                config.selfieType = numberOfPose
            } else throw Exception("IllegalPoseNumberException: Pose number cannot be smaller than 1")
        }

        @NonMandatory("Has default value as 3000 milliseconds")
        fun ovalViewAnimationDurationMilSec(milSec: Int) = apply {
            config.ovalViewAnimationDurationMilSec = milSec
        }

        @NonMandatory("It has default value as false, in that case video will not be recorded")
        fun videoRecord(videoRecord: Boolean?) = apply {
            if (videoRecord == null) return@apply
            config.recordVideo = videoRecord
        }

        @Throws
        @Mandatory("Has no default value")
        fun observe(poseEstimationObserver: PoseEstimationObserver?) = apply {
            if (poseEstimationObserver == null)
                throw Exception("NullPointerException: Observer cannot be null")
            this.observer = poseEstimationObserver
        }

        fun onException(exception: ExceptionCallBack) = apply {
            this.exceptionCallBack = exception
        }

        /** Validates colours and returns the v1 fragment, or `null` on colour validation failure. */
        @Mandatory("To finalise the V1 builder")
        fun build(context: Context): BaseFragment? {
            _operationID = OperationIdProvider.startNew()
            AmaniLog.essential(LogArea.SELFIE) { "pose estimation selfie started (v1) docType=$_docType op=${LogFormat.op(_operationID)}" }
            _docType = _docType
            _recordVideo = config.recordVideo

            val colorsValid =
                colorValidator.validate(config.uiColors.ovalViewErrorColor, context) &&
                colorValidator.validate(config.uiColors.ovalViewStartColor, context) &&
                colorValidator.validate(config.uiColors.ovalViewSuccessColor, context) &&
                colorValidator.validate(config.uiColors.appFontColor, context)

            if (!colorsValid) return null

            val versionConfig = try {
                SessionManager.getVersion(type = _docType)
            } catch (e: Exception) {
                AmaniLog.w(LogArea.SELFIE, e) { "pose estimation config could not be read docType=$_docType" }
                null
            }

            val arg = Bundle().apply {
                putParcelable(AppConstants.KEY_VERSION_LIST, versionConfig)
                putParcelable(AppConstants.KEY_POSE_ESTIMATION, config)
                putString(AppConstants.OPERATION_ID, _operationID)
            }

            return SelfiePoseEstimationFrag().also { frag ->
                frag.arguments = arg
                frag.observer = this.observer
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // V2 Builder — continuous 360° head-rotation flow
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Builder for the continuous 360° head-rotation selfie liveness challenge.
     *
     * Returned by [SelfiePoseEstimation.HeadRotation]. Only rotation-specific options
     * appear in IDE autocomplete — discrete-pose settings are intentionally absent.
     */
    class V2Builder {

        private val config = PoseEstimationV2Config()
        private val colorValidator = ColorValidator()
        private lateinit var observer: PoseEstimationObserver
        private var exceptionCallBack: ExceptionCallBack? = null
        private var uiStateListener: ((PoseEstimationV2UiState) -> Unit)? = null

        @Mandatory
        fun documentType(documentType: String) = apply {
            _docType = documentType
        }

        /**
         * Sets the v2-specific UI colours.
         *
         * @param overlayBackgroundColor       Full-screen overlay colour surrounding the camera oval.
         * @param progressRingColor            Progress ring arc colour (both in-progress and completed segments).
         * @param progressRingTrackColor       Dim background ring track.
         * @param directionArrowColor          Spinning direction arrow inside the oval.
         * @param appFontColor                 Instruction text below the oval.
         * @param alertTitleFontColor          Retry alert dialog title text.
         * @param alertDescriptionFontColor    Retry alert dialog body text.
         * @param alertTryAgainFontColor       Retry alert dialog button text.
         * @param alertBackgroundColor         Retry alert dialog background.
         */
        @NonMandatory("Has default values")
        fun userInterfaceColors(
            overlayBackgroundColor: Int? = null,
            progressRingColor: Int? = null,
            progressRingTrackColor: Int? = null,
            directionArrowColor: Int? = null,
            appFontColor: Int? = null,
            alertTitleFontColor: Int? = null,
            alertDescriptionFontColor: Int? = null,
            alertTryAgainFontColor: Int? = null,
            alertBackgroundColor: Int? = null,
        ) = apply {
            config.v2Colors.also {
                if (overlayBackgroundColor != null)      it.overlayBackgroundColor      = overlayBackgroundColor
                if (progressRingColor != null)           it.progressRingColor           = progressRingColor
                if (progressRingTrackColor != null)      it.progressRingTrackColor      = progressRingTrackColor
                if (directionArrowColor != null)         it.directionArrowColor         = directionArrowColor
                if (appFontColor != null)                it.appFontColor                = appFontColor
                if (alertTitleFontColor != null)         it.alertFontTitleColor         = alertTitleFontColor
                if (alertDescriptionFontColor != null)   it.alertFontDescriptionColor   = alertDescriptionFontColor
                if (alertTryAgainFontColor != null)      it.alertFontTryAgainColor      = alertTryAgainFontColor
                if (alertBackgroundColor != null)        it.alertBackgroundColor        = alertBackgroundColor
            }
        }

        /**
         * Overrides any subset of the v2 instruction and alert texts.
         *
         * Only the texts actually displayed during the 360° rotation flow are included.
         * Texts irrelevant to v2 (e.g. turnUp / turnDown / keepEyesOpen) are intentionally absent.
         */
        @NonMandatory("Has default values")
        fun userInterfaceTexts(
            faceStraight: String? = null,
            turnLeft: String? = null,
            turnRight: String? = null,
            faceNotInside: String? = null,
            faceTooFar: String? = null,
            holdPhoneVertically: String? = null,
            keepRotating: String? = null,
            alertTitle: String? = null,
            alertDescription: String? = null,
            alertTryAgain: String? = null,
        ) = apply {
            config.v2Texts.also {
                if (faceStraight != null)        it.faceStraight        = faceStraight
                if (turnLeft != null)            it.turnLeft            = turnLeft
                if (turnRight != null)           it.turnRight           = turnRight
                if (faceNotInside != null)       it.faceNotInside       = faceNotInside
                if (faceTooFar != null)          it.faceTooFar          = faceTooFar
                if (holdPhoneVertically != null) it.holdPhoneVertically = holdPhoneVertically
                if (keepRotating != null)        it.keepRotating        = keepRotating
                if (alertTitle != null)          it.alertTitle          = alertTitle
                if (alertDescription != null)    it.alertDescription    = alertDescription
                if (alertTryAgain != null)       it.alertTryAgain       = alertTryAgain
            }
        }

        @NonMandatory("Has default value as 3000 milliseconds")
        fun ovalViewAnimationDurationMilSec(milSec: Int) = apply {
            config.ovalViewAnimationDurationMilSec = milSec
        }

        @NonMandatory("It has default value as false, in that case video will not be recorded")
        fun videoRecord(videoRecord: Boolean?) = apply {
            if (videoRecord == null) return@apply
            config.recordVideo = videoRecord
        }

        /**
         * Enables the preparation screen shown before the liveness process starts.
         *
         * The animation supplied through [preparationAnimation] loops inside the circle
         * while the progress ring around it sweeps 0→360°, both going the way the user will
         * be asked to rotate. A button at the bottom lets the user start the process when
         * ready. The [message] is displayed below the circle as an instruction.
         *
         * Omit this call to skip the preparation screen and start directly. **The screen
         * also needs an animation**: without `preparationAnimation(animation = …)` there is
         * nothing to demonstrate, so the flow goes straight to capture even if this method
         * was called.
         *
         * Use [preparationAnimation] to style the animation on this screen, and
         * [processingAnimation] for what the capture screen shows.
         *
         * ```kotlin
         * .showPreparationScreen(
         *     message               = "Watch and follow the head movement",
         *     buttonText            = "Start",
         *     buttonTextColor       = R.color.white,
         *     buttonBackgroundColor = R.color.approve_green,
         *     buttonRadiusDp        = 28f
         * )
         * ```
         *
         * @param message              Instruction text shown below the circle during preparation.
         * @param buttonText           Text displayed on the start button.
         * @param buttonTextColor      Color resource for the button text.
         * @param buttonBackgroundColor Color resource for the button background.
         * @param buttonRadiusDp       Corner radius of the button in dp.
         * @param overlayColor         Color resource for the circle overlay background during preparation.
         *                             Defaults to the main overlay color if not set.
         */
        @JvmOverloads
        @NonMandatory("Preparation screen is skipped if not set")
        fun showPreparationScreen(
            message: String = "Follow the head movement shown in the animation",
            buttonText: String = "Start",
            @ColorRes buttonTextColor: Int? = null,
            @ColorRes buttonBackgroundColor: Int? = null,
            buttonRadiusDp: Float = 28f,
            @ColorRes overlayColor: Int? = null
        ) = apply {
            config.showPreparationScreen = true
            config.guideInstructionText = message
            config.preparationButtonText = buttonText
            if (buttonTextColor != null) config.preparationButtonTextColor = buttonTextColor
            if (buttonBackgroundColor != null) config.preparationButtonBackgroundColor = buttonBackgroundColor
            config.preparationButtonRadiusDp = buttonRadiusDp
            if (overlayColor != null) config.preparationOverlayColor = overlayColor
        }

        /**
         * Hex-string variant of [showPreparationScreen] for callers who prefer passing colors
         * as ARGB/RGB hex strings (e.g. `"#FFFFFF"`, `"#CC000000"`) instead of color resource IDs.
         *
         * Accepted formats — anything [android.graphics.Color.parseColor] supports:
         *  - `#RRGGBB`   (e.g. `"#34C759"`)
         *  - `#AARRGGBB` (e.g. `"#80000000"` for 50% black)
         *  - Named colors: `"red"`, `"blue"`, `"white"`, …
         *
         * ```kotlin
         * .showPreparationScreenWithHexColors(
         *     message               = "Watch and follow the head movement",
         *     buttonText            = "Start",
         *     buttonTextColor       = "#FFFFFF",
         *     buttonBackgroundColor = "#34C759",
         *     buttonRadiusDp        = 28f,
         *     overlayColor          = "#80000000"
         * )
         * ```
         *
         * @param message              Instruction text shown below the circle during preparation.
         * @param buttonText           Text displayed on the start button.
         * @param buttonTextColor      Hex color string for the button text (e.g. `"#FFFFFF"`).
         * @param buttonBackgroundColor Hex color string for the button background.
         * @param buttonRadiusDp       Corner radius of the button in dp.
         * @param overlayColor         Hex color string for the circle overlay background during preparation.
         *                             Defaults to the main overlay color if not set.
         *
         * @throws IllegalArgumentException if any hex color string cannot be parsed.
         */
        @JvmOverloads
        @NonMandatory("Preparation screen is skipped if not set")
        fun showPreparationScreenWithHexColors(
            message: String = "Follow the head movement shown in the animation",
            buttonText: String = "Start",
            buttonTextColor: String? = null,
            buttonBackgroundColor: String? = null,
            buttonRadiusDp: Float = 28f,
            overlayColor: String? = null
        ) = apply {
            config.showPreparationScreen = true
            config.guideInstructionText = message
            config.preparationButtonText = buttonText
            if (buttonTextColor != null)
                config.preparationButtonTextColorArgb = buttonTextColor.toColorInt()
            if (buttonBackgroundColor != null)
                config.preparationButtonBackgroundColorArgb = buttonBackgroundColor.toColorInt()
            config.preparationButtonRadiusDp = buttonRadiusDp
            if (overlayColor != null)
                config.preparationOverlayColorArgb = overlayColor.toColorInt()
        }

        /**
         * Every setting of the **preparation screen** animation, in one call: which Lottie
         * file plays, the color of the disc behind the head and the overall opacity.
         *
         * This is the full-size animation shown before capture, above the confirm button
         * (see [showPreparationScreen]). What the processing screen shows is configured
         * separately, with [processingAnimation].
         *
         * The animation is **yours to supply** — the SDK ships no artwork for this screen.
         * Without an [animation] the preparation screen is skipped entirely.
         *
         * ```kotlin
         * .preparationAnimation(
         *     animation       = R.raw.my_head_circle,   // optional, Lottie JSON
         *     backgroundColor = R.color.white,
         *     opacity         = 0.9f
         * )
         * ```
         *
         * Pass [backgroundColor] as a hex string instead to use the string overload.
         *
         * ### Supplying your own animation
         *
         * [animation] must be a **Lottie JSON** raw resource — MP4 and other video formats
         * are not supported. Two expectations, both met by the built-in file:
         *
         *  - **two equal-length segments**, marked `clockwise` and `counterclockwise`, so
         *    the SDK can play the one matching the direction the user must rotate. Without
         *    markers the animation is split in half: first half clockwise, second half
         *    counter-clockwise.
         *  - **a transparent background** — the disc behind the head is drawn by the SDK and
         *    colored by [backgroundColor]; so is the progress ring, which takes its colors
         *    from [userInterfaceColors].
         *
         * @param animation       Lottie JSON raw resource. 0 = no preparation screen.
         * @param backgroundColor Color resource of the disc behind the head. 0 keeps black.
         * @param opacity         0f (fully transparent) to 1f (fully opaque).
         *
         * @throws IllegalArgumentException if [opacity] is outside `0f..1f`.
         */
        @JvmOverloads
        @NonMandatory("Preparation screen is skipped if no animation is set")
        fun preparationAnimation(
            @RawRes animation: Int = 0,
            @ColorRes backgroundColor: Int = 0,
            opacity: Float = 1f
        ) = apply {
            requireAnimationOpacity("preparationAnimation", opacity)
            if (animation != 0) config.preparationAnimationRawRes = animation
            config.preparationAnimationBackgroundColor = backgroundColor
            config.preparationAnimationBackgroundColorArgb = null
            config.preparationAnimationOpacity = opacity
        }

        /**
         * Hex-color variant of [preparationAnimation], for callers who keep their palette as
         * strings rather than color resources. Everything else behaves identically.
         *
         * ```kotlin
         * .preparationAnimation(backgroundColor = "#FFFFFF", opacity = 0.9f)
         * ```
         *
         * Accepted formats — anything [android.graphics.Color.parseColor] supports:
         * `#RRGGBB`, `#AARRGGBB` (e.g. `"#80000000"` for 50 % black) and named colors.
         *
         * @param animation       Lottie JSON raw resource. 0 = no preparation screen.
         * @param backgroundColor Hex color of the disc behind the head.
         * @param opacity         0f (fully transparent) to 1f (fully opaque).
         *
         * @throws IllegalArgumentException if [opacity] is outside `0f..1f`, or if
         *         [backgroundColor] cannot be parsed.
         */
        @JvmOverloads
        @NonMandatory("Preparation screen is skipped if no animation is set")
        fun preparationAnimation(
            @RawRes animation: Int = 0,
            backgroundColor: String,
            opacity: Float = 1f
        ) = apply {
            requireAnimationOpacity("preparationAnimation", opacity)
            if (animation != 0) config.preparationAnimationRawRes = animation
            config.preparationAnimationBackgroundColor = 0
            config.preparationAnimationBackgroundColorArgb = backgroundColor.toColorInt()
            config.preparationAnimationOpacity = opacity
        }

        /**
         * Every setting of what the **processing screen** draws in the centre of the camera
         * circle, in one call: the rotation hint animation, the icon shown while the user
         * holds their face straight, and the opacity both are drawn with.
         *
         * The hint plays for the whole rotation, scaled down over the camera feed, so it
         * carries no background of its own. [faceGuideDrawable] and the animation take turns
         * in the same spot, at the same size, and share [opacity].
         *
         * Both are **yours to supply** — the SDK ships no artwork. Each is optional and
         * degrades on its own: with no [animation] the overlay falls back to its built-in
         * spinning direction arrow, and with no [faceGuideDrawable] the "hold still" step
         * relies on the instruction text alone.
         *
         * ```kotlin
         * .processingAnimation(
         *     animation         = R.raw.my_head_circle,      // optional, Lottie JSON
         *     faceGuideDrawable = R.drawable.my_face_guide,  // optional, any drawable
         *     opacity           = 0.8f
         * )
         * ```
         *
         * [animation] has the same requirements as in [preparationAnimation]: a Lottie JSON
         * with `clockwise` / `counterclockwise` markers and a transparent background — the
         * camera feed has to stay visible underneath.
         *
         * @param animation         Lottie JSON raw resource. 0 = no centre hint; the overlay
         *                          draws its spinning direction arrow instead.
         * @param faceGuideDrawable Icon shown while the user holds still, before the rotation
         *                          starts. 0 = no icon.
         * @param opacity           0f (fully transparent) to 1f (fully opaque), applied to
         *                          both the hint animation and [faceGuideDrawable].
         *
         * @throws IllegalArgumentException if [opacity] is outside `0f..1f`.
         */
        @JvmOverloads
        @NonMandatory("Centre hint and face guide are skipped if not set")
        fun processingAnimation(
            @RawRes animation: Int = 0,
            @DrawableRes faceGuideDrawable: Int = 0,
            opacity: Float = 1f
        ) = apply {
            requireAnimationOpacity("processingAnimation", opacity)
            if (animation != 0) config.processingAnimationRawRes = animation
            if (faceGuideDrawable != 0) config.faceGuideDrawable = faceGuideDrawable
            config.processingAnimationOpacity = opacity
        }

        private fun requireAnimationOpacity(caller: String, opacity: Float) {
            require(opacity in 0f..1f) {
                "$caller opacity must be between 0f and 1f, was $opacity"
            }
        }

        @Throws
        @Mandatory("Has no default value")
        fun observe(poseEstimationObserver: PoseEstimationObserver?) = apply {
            if (poseEstimationObserver == null)
                throw Exception("NullPointerException: Observer cannot be null")
            this.observer = poseEstimationObserver
        }

        fun onException(exception: ExceptionCallBack) = apply {
            this.exceptionCallBack = exception
        }

        /**
         * Registers a listener for high-level UI states of the v2 liveness flow:
         * [PoseEstimationV2UiState.PREPARATION_STARTED] when the preparation screen is shown,
         * [PoseEstimationV2UiState.PREPARATION_CONFIRMED] when the user taps its confirm button,
         * and [PoseEstimationV2UiState.CAPTURE_STARTED] when the camera opens and capture begins.
         *
         * Useful for analytics or driving your own UI around the flow. The listener is invoked on
         * the main thread. The preparation states are only emitted when a preparation screen is
         * configured via [showPreparationScreen]; otherwise the flow emits only CAPTURE_STARTED.
         */
        fun onUiStateChanged(listener: (PoseEstimationV2UiState) -> Unit) = apply {
            this.uiStateListener = listener
        }

        /** Validates colours and returns the v2 fragment, or `null` on colour validation failure. */
        @Mandatory("To finalise the V2 builder")
        fun build(context: Context): BaseFragment? {
            _operationID = OperationIdProvider.startNew()
            AmaniLog.essential(LogArea.SELFIE) { "pose estimation selfie started (v2) docType=$_docType op=${LogFormat.op(_operationID)}" }
            _recordVideo = config.recordVideo

            val colorsValid =
                colorValidator.validate(config.v2Colors.progressRingColor, context) &&
                colorValidator.validate(config.v2Colors.appFontColor, context)

            if (!colorsValid) return null

            val versionConfig = try {
                SessionManager.getVersion(type = _docType)
            } catch (e: Exception) {
                AmaniLog.w(LogArea.SELFIE, e) { "pose estimation config could not be read docType=$_docType" }
                null
            }

            val arg = Bundle().apply {
                putParcelable(AppConstants.KEY_VERSION_LIST, versionConfig)
                putParcelable(SelfiePoseEstimationV2Frag.KEY_V2_CONFIG, config)
                putString(AppConstants.OPERATION_ID, _operationID)
            }

            return SelfiePoseEstimationV2Frag().also { frag ->
                frag.arguments = arg
                frag.observer = this.observer
                frag.uiStateListener = this.uiStateListener
            }
        }
    }
}
