package ai.amani.sdk.modules.selfie.manual_capture.model

import ai.amani.R
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

/**
 * @Author: zekiamani
 * @Date: 17.11.2022
 */
@Parcelize
data class ManualSelfieCaptureConfig(
    @SerializedName("uiColors")
    var uiColors: UIColors = UIColors(),

    @SerializedName("uiTexts")
    var uiTexts: UITexts = UITexts()
) : Parcelable

@Parcelize
data class UIColors(
    @SerializedName("appFontColor")
    var appFontColor: Int = R.color.white,

    @SerializedName("appBackgroundColor")
    var appBackgroundColor: Int = R.color.white,

    @SerializedName("manualCaptureButtonColor")
    var manualCaptureButtonColor: Int = R.color.white,

    @SerializedName("ovalViewColor")
    var ovalViewColor: Int = R.color.white
) : Parcelable

@Parcelize
data class UITexts(
    @SerializedName("selfieDescriptionText")
    var selfieDescriptionText: String = "Please, be sure you are in the area while taking photo"
) : Parcelable