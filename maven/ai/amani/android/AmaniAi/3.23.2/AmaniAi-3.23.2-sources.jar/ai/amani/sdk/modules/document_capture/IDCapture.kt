package ai.amani.sdk.modules.document_capture

import ai.amani.base.logger.core.ActionTypes
import ai.amani.base.logger.local.AmaniLog
import ai.amani.base.logger.local.LogArea
import ai.amani.base.logger.local.LogFormat
import ai.amani.base.logger.util.OperationIdProvider
import ai.amani.base.util.CacheUtility
import ai.amani.base.util.SessionManager
import ai.amani.base.utility.AmaniVersion
import ai.amani.base.utility.AppConstants
import ai.amani.sdk.Amani
import ai.amani.sdk.interfaces.ExceptionCallBack
import ai.amani.sdk.interfaces.IFragmentCallBack
import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.mapper.AmaniEventMapper.asAmaniEventType
import ai.amani.sdk.model.amani_events.error.AmaniError
import ai.amani.sdk.model.amani_events.error.AmaniErrorTypes
import ai.amani.sdk.model.mrz.MRZResult
import ai.amani.sdk.modules.amani_events.AmaniEvent
import ai.amani.sdk.modules.document_capture.IDCapture.DEFAULT_CAPTURE_AREA_SCALE
import ai.amani.sdk.modules.document_capture.IDCapture.MAX_CAPTURE_AREA_SCALE
import ai.amani.sdk.modules.document_capture.IDCapture.MIN_CAPTURE_AREA_SCALE
import ai.amani.sdk.modules.document_capture.IDCapture.isSendOriginalImagesEnabled
import ai.amani.sdk.modules.document_capture.IDCapture.setCaptureAreaScaleFactor
import ai.amani.sdk.modules.document_capture.IDCapture.start
import ai.amani.sdk.modules.document_capture.IDCapture.withNFC
import ai.amani.sdk.modules.document_capture.mrz.GetMRZ
import ai.amani.sdk.modules.document_capture.usecase.UploadHologramVideoUseCase
import ai.amani.sdk.modules.document_capture.view.DocumentCaptureFrag
import ai.amani.sdk.service.upload.ErrorConstants
import ai.amani.sdk.service.upload.HitUploadApi
import ai.amani.sdk.service.upload.HitUploadNFCApi
import ai.amani.sdk.service.v2.upload.HitUploadApiV2
import android.app.Activity
import android.os.Bundle
import android.widget.FrameLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import datamanager.model.config.Version
import datamanager.repomanager.id_video.UploadIDVideoImp
import datamanager.v2.model.upload.request.NFCData
import datamanager.v2.model.upload.request.Photo
import datamanager.v2.model.upload.request.ReqUploadV2
import datamanager.v2.model.upload.request.Video
import datamanager.v2.repomanager.id_capture_save.IDCaptureSaveRepositoryImp
import datamanager.v2.repomanager.id_capture_save.IIDCaptureSaveRepository
import datamanager.v2.repomanager.id_capture_save.IIDCaptureSaveRepository.Side
import datamanager.v2.repomanager.video_record.UploadVideoRecordImp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import ml_amani.auto_capture.generic_auto_capture.detector.MODEL_TF_LITE_ID_PASSPORT_DETECTOR
import ml_amani.hologram_detection.HologramDetector
import ml_amani.ocr.mrz.MRZReaderCache
import ml_amani.util.ModelFileUtility
import okhttp3.MultipartBody
import okhttp3.MultipartBody.Part.Companion.createFormData

object IDCapture : IDCaptureI {

    /** Default capture-area scale (full-size rectangle, original behaviour). */
    const val DEFAULT_CAPTURE_AREA_SCALE = 1.0f

    /** Smallest capture-area scale accepted by [setCaptureAreaScaleFactor]. */
    const val MIN_CAPTURE_AREA_SCALE = 0.75f

    /** Largest capture-area scale accepted by [setCaptureAreaScaleFactor]. */
    const val MAX_CAPTURE_AREA_SCALE = 1.0f

    /** handles fragment events*/
    private var callBackF: IFragmentCallBack? = null

    /** handles upload events properly*/
    private var callBackU: IUploadCallBack? = null

    /**
     * Callback of any exception within ID Capture
     */
    private var exceptionCallBack: ExceptionCallBack? = null

    /** Default Manual Crop time out is 30*/
    private var timeOut = 15

    /** Represents process will be handled with NFC or with-out NFC
     * Default value false*/
    private var withNFC: Boolean = false

    /**
     * Whether detection of hologram top of ID Card is required while ID scanning process or not
     */
    private var hologramDetection: Boolean = false

    /**
     * Whether video recording of ID Card is required while ID scanning process or not
     */
    private var videoRecord: Boolean = false

    /**
     * Activates the MRZ area reading with OCR to use get MRZInfo to use inside NFCScan module
     */
    private var isMRZReaderEnabled: Boolean = false

    /**
     * Whether the session is front side or backside
     */
    private var frontSide: Boolean = true

    /**
     * Uniform scale of the on-screen ID/document capture guide rectangle relative
     * to its default (full) size. 1.0f keeps the original behaviour.
     */
    private var captureAreaSizeFactor: Float = DEFAULT_CAPTURE_AREA_SCALE

    /**
     * Unique ID for each session start to end
     */
    var operationID : String = ""
        private set

    /** Read-side counterpart to the ViewModel's save repository. */
    private val saveRepository: IIDCaptureSaveRepository = IDCaptureSaveRepositoryImp()

    /**
     * This function must be called before the start() function.
     * Default timeOut: 15 seconds, if you are not calling this func.
     * @param timeOut The time required seconds for the Manual Crop button to activate.
     */
    fun setManualCropTimeOut(timeOut: Int) {
        if (timeOut < 15 && timeOut != 0 ){
            AmaniLog.w(LogArea.CAPTURE) {
                "manual crop timeout cannot be less than 15 seconds, the default (15 seconds) is applied"
            }
            return
        }
        this.timeOut = timeOut
    }

    /**
     * This function must be called before the start() function.
     * Default value is false.
     * @param withNFC : Represents process withNFC or withOutNFC
     */
    fun withNFC(withNFC: Boolean = false) {
        this.withNFC = withNFC
    }

    fun hologramDetection(hologramDetection: Boolean = false) {
        if (frontSide) this.hologramDetection = hologramDetection
        else {
            this.hologramDetection = false
            AmaniLog.w(LogArea.CAPTURE) { "hologram detection cannot be enabled when the back side is selected" }
        }
    }

    fun videoRecord(videoRecord: Boolean = false) {
        this.videoRecord = videoRecord
    }

    fun setIsMRZReaderEnabled(enable: Boolean = true) {
        this.isMRZReaderEnabled = enable
    }

    /**
     * Configures the size of the on-screen ID/document capture guide rectangle
     * relative to its default (full) size. Must be called before [start].
     *
     * The factor uniformly scales the rectangle's width and height, so its aspect
     * ratio — and the position of the face/chip guide icons drawn inside it — stay
     * correct. So that a smaller rectangle (which invites the user to hold the
     * document a little farther from the camera) doesn't start failing the
     * auto-capture minimum-area check, that size threshold is relaxed by the same
     * factor.
     *
     * When this function is never called the default is [DEFAULT_CAPTURE_AREA_SCALE]
     * (1.0f) and the capture screen behaves exactly as before.
     *
     * @param factor Desired scale in the range
     * [[MIN_CAPTURE_AREA_SCALE], [MAX_CAPTURE_AREA_SCALE]] where 1.0f = default
     * full-size rectangle. Out-of-range values are coerced into the range (and
     * logged); non-positive values are ignored and the previous value is kept.
     */
    fun setCaptureAreaScaleFactor(factor: Float) = apply {
        if (factor <= 0f) {
            AmaniLog.w(LogArea.CAPTURE) {
                "capture area scale factor must be greater than 0, ignoring $factor, keeping $captureAreaSizeFactor"
            }
            return@apply
        }
        val coerced = factor.coerceIn(MIN_CAPTURE_AREA_SCALE, MAX_CAPTURE_AREA_SCALE)
        if (coerced != factor) {
            AmaniLog.w(LogArea.CAPTURE) {
                "capture area scale factor $factor is out of range [$MIN_CAPTURE_AREA_SCALE, $MAX_CAPTURE_AREA_SCALE], using $coerced"
            }
        }
        this.captureAreaSizeFactor = coerced
    }

    override fun start(
        activity: FragmentActivity,
        frameLayout: FrameLayout,
        docType: String,
        frontSide: Boolean,
        callBack: IFragmentCallBack,
    ): Fragment? {
        callBackF = callBack
        this.frontSide = frontSide
        operationID = OperationIdProvider.startNew()
        AmaniLog.essential(LogArea.CAPTURE) {
            "ID capture started docType=$docType side=${if (frontSide) "front" else "back"} op=${LogFormat.op(operationID)}"
        }
        return startIDCapture(frameLayout, docType, frontSide)
    }

    /** Must be only called after Back Side of ID which includes MRZ field is captured correctly
     *
     * @param type : Document type
     * @param onComplete: Unit callback during success cases
     * @param onError: Unit callback during errors
     */
    @Synchronized
    fun getMRZ(
        type: String,
        onComplete: (mrz: MRZResult) -> Unit,
        onError: (error: AmaniError) -> Unit
    ) {
        // Get cached client side MRZ result if it 's enabled  or request MRZ with backside of
        // the captured document in else block {}
        if (isMRZReaderEnabled) {
            try {
                val mrzResult = MRZReaderCache.getCache()

                if (mrzResult == null) {
                    // Fallback to backend request if the current MRZ result is null
                    GetMRZ().requestMRZ(
                        type,
                        onComplete,
                        onError
                    )
                    return
                }

                if (mrzResult.mRZBirthDate.isNullOrEmpty() || mrzResult.mRZExpiryDate.isNullOrEmpty()
                    || mrzResult.mRZDocumentNumber.isNullOrEmpty()) {
                    onError.invoke(ErrorConstants.MRZ_RESULT_ERROR)
                    return
                }

                onComplete.invoke(mrzResult)
                return
            } catch (e: Exception) {
                onError.invoke(ErrorConstants.MRZ_RESULT_ERROR)
            }
        } else {
            // Request MRZ from backend with previous captured backside of the document
            GetMRZ().requestMRZ(
                type,
                onComplete,
                onError
            )
        }
    }

    private fun startIDCapture(
        frameLayout: FrameLayout?,
        docType: String?,
        frontSide: Boolean
    ): Fragment? {
        if (frameLayout != null && docType != null) {
            val documentCaptureFrag = DocumentCaptureFrag()
            val arg = Bundle()
            var version: Version? = null

            try {
                version = SessionManager.getVersion(docType)
                if (version == null) {
                    AmaniEvent.getEvent()?.onError(
                        type = docType.asAmaniEventType(),
                        error = arrayListOf(ErrorConstants.CONFIG_ERROR)
                    )
                    return null
                }
            } catch (e: Exception) {
                AmaniEvent.getEvent()?.onError(
                    type = docType.asAmaniEventType(),
                    error = arrayListOf(ErrorConstants.CONFIG_ERROR)
                )
                return null
            }

            val context = frameLayout.context
            val idModelReady = ModelFileUtility.isModelAvailable(
                context, MODEL_TF_LITE_ID_PASSPORT_DETECTOR
            )
            val hologramModelReady = if (hologramDetection) {
                ModelFileUtility.isModelAvailable(
                    context, HologramDetector.MODEL_TF_LITE_HOLOGRAM_DETECTION
                )
            } else true

            if (!idModelReady || !hologramModelReady) {
                AmaniEvent.getEvent()?.onError(
                    type = docType.asAmaniEventType(),
                    error = arrayListOf(ErrorConstants.DYNAMIC_FEATURE_ASSET_NOT_FOUND)
                )
                return null
            }

            arg.putParcelable(AppConstants.KEY_VERSION_LIST, version)
            arg.putBoolean(AppConstants.FRONT_SIDE, frontSide)
            if (frameLayout.height != 0 || frameLayout.width != 0) {
                arg.putInt(AppConstants.FRAME_LAYOUT_HEIGHT, frameLayout.height)
                arg.putInt(AppConstants.FRAME_LAYOUT_WIDTH, frameLayout.width)
            }
            arg.putInt(AppConstants.MANUAL_CROP_TIME_OUT, timeOut)
            arg.putBoolean(AppConstants.HOLOGRAM_DETECTION, this.hologramDetection)
            arg.putBoolean(AppConstants.VIDEO_RECORD, this.videoRecord)
            arg.putBoolean(AppConstants.ENABLE_MRZ_READER, this.isMRZReaderEnabled)
            arg.putString(AppConstants.OPERATION_ID, this.operationID)
            arg.putFloat(AppConstants.CAPTURE_AREA_SIZE_FACTOR, this.captureAreaSizeFactor)
            documentCaptureFrag.arguments = arg
            documentCaptureFrag.fragmentCallBack = callBackF
            documentCaptureFrag.exceptionCallBack = exceptionCallBack
            return documentCaptureFrag
        }
        return null
    }

    override fun upload(activity: FragmentActivity, docType: String, callBack: IUploadCallBack) {
        callBackU = AmaniEvent.observeUpload(callBack)

        if (withNFC) uploadIDWithNFC(activity, docType)
        else uploadId(activity, docType)
    }

    override fun onException(exception: ExceptionCallBack): IDCapture = apply {
        this.exceptionCallBack = exception
    }

    /** True when the active config opts in to shipping uncropped originals. */
    private fun isSendOriginalImagesEnabled(docType: String): Boolean {
        val version = try { SessionManager.getVersion(docType) } catch (e: Exception) { null }
        return version?.sendOriginalImages == true
    }

    /**
     * Builds the `original_pages` payload mirroring [ReqUploadV2.pages]. Pre-condition:
     * caller has already verified [isSendOriginalImagesEnabled]. Returns null when
     * nothing was cached (e.g. capture finished before the flag flipped on), so the
     * legacy single-`pages` payload shape stays untouched.
     */
    private fun buildOriginalPages(): List<String>? {
        val pages = listOfNotNull(
            saveRepository.getOriginalPage(Side.FRONT)?.let { "data:image/jpeg;base64, $it" },
            saveRepository.getOriginalPage(Side.BACK)?.let { "data:image/jpeg;base64, $it" }
        )
        return pages.ifEmpty { null }
    }

    private fun uploadId(activity: Activity, docType: String) {

        val frontID = saveRepository.getCroppedPage(Side.FRONT)
        val backID = saveRepository.getCroppedPage(Side.BACK)

        when (Amani.VERSION.version) {
            AmaniVersion.V1.version -> {
                val fileList: MutableList<MultipartBody.Part> = ArrayList<MultipartBody.Part>()
                val version = SessionManager.getVersion(docType)
                if (version == null) {
                    callBackU!!.cb(false)
                    AmaniEvent.getEvent()?.onError(
                        type = docType.asAmaniEventType(),
                        error = arrayListOf(ErrorConstants.DOCUMENT_VERSION_NULL_ERROR)
                    )
                }
                val hitUploadApi = HitUploadApi()
                val file1: MultipartBody.Part = createFormData(
                    "files[]",
                    "data:image/jpeg;base64,$frontID"
                )
                val file2: MultipartBody.Part = createFormData(
                    "files[]",
                    "data:image/jpeg;base64,$backID"
                )
                if (frontID != null) fileList.add(file1)
                if (backID != null) fileList.add(file2)

                //Clearing the cached ID data
                CacheUtility.clearIDCache()

                hitUploadApi.iUploadCallBack = object : IUploadCallBack {
                    override fun cb(isSuccess: Boolean) {
                        //If hologram detection is false return actual ID upload result
                        if (!videoRecord) {
                            callBackU!!.cb(isSuccess)
                            return
                        }

                        //If ID upload result is success, request for hologram video upload
                        // return the hologram video result
                        if (isSuccess) {
                            CoroutineScope(Dispatchers.IO).launch {
                                val result = UploadHologramVideoUseCase(
                                    UploadVideoRecordImp(),
                                    UploadIDVideoImp()
                                ).invoke()
                                callBackU!!.cb(result)
                            }
                        } else callBackU!!.cb(false)
                    }

                }
                hitUploadApi.UploadFunction(activity, fileList, version!!)
            }

            AmaniVersion.V2.version -> {

                val request = ReqUploadV2()
                request.documentType = docType
                request.uploadSource = Amani.getUploadSource()

                val encodedFrontSide =
                    "data:image/jpeg;base64, $frontID"
                val encodedBackSide =
                    "data:image/jpeg;base64, $backID"

                if (backID == null) {
                    request.pages = listOf(
                        encodedFrontSide
                    )
                } else if (frontID != null) {
                    request.pages = listOf(
                        encodedFrontSide,
                        encodedBackSide
                    )
                } else {
                    callBackU!!.cb(false)
                    AmaniEvent.getEvent()?.onError(
                        type = AmaniErrorTypes.ID.name,
                        error = arrayListOf(ErrorConstants.ID_NULL_ERROR))
                    return
                }

                request.checkMrz = true
                request.profile = SessionManager.getCustomerIdV2()
                // Explicit gate at the upload boundary: only attach `original_pages`
                // when the active Version config asks for it. Without the flag the
                // request keeps the legacy `pages`-only shape.
                if (isSendOriginalImagesEnabled(docType)) {
                    request.originalPages = buildOriginalPages()
                }

                if (videoRecord) {
                    val videoPathFrontSide = SessionManager.getFrontSideVideoPath()
                    val videoPathBackSide = SessionManager.getBackSideVideoPath()

                    if (videoPathFrontSide != null) {
                        request.videos?.add(
                            Video(
                                path = videoPathFrontSide,
                                name = "1_id_front"
                            ).modifyFileNameAccordinglyExtension()
                        )
                    }

                    if (videoPathBackSide != null) {
                        val fileName = if (hologramDetection) "3_id_back" else "2_id_back"
                        request.videos?.add(
                            Video(
                                path = videoPathBackSide,
                                name = fileName
                            ).modifyFileNameAccordinglyExtension()
                        )
                    }
                }

                val hitUploadV2 = HitUploadApiV2()

                hitUploadV2.requestUpload(
                    iUploadCallBack = object : IUploadCallBack {
                        override fun cb(isSuccess: Boolean) {
                            callBackU!!.cb(isSuccess)
                            CacheUtility.clearIDCache()
                        }

                        override fun cb(isSuccess: Boolean, documentID: String?) {
                            callBackU!!.cb(isSuccess, documentID)
                            CacheUtility.clearIDCache()
                        }
                    },
                    uploadRequest = request,
                    activity = activity,
                    operationID = operationID,
                    actionType = ActionTypes.ID_CAPTURE_UPLOAD_RESP
                )
            }
        }
    }

    private fun uploadIDWithNFC(activity: Activity, docType: String) {

        when(Amani.VERSION.version)  {
            AmaniVersion.V1.version -> {
                val version = SessionManager.getVersion(docType)
                if (version == null) {
                    callBackU!!.cb(false)
                    AmaniEvent.getEvent()?.onError(
                        type = docType.asAmaniEventType(),
                        error =  arrayListOf(ErrorConstants.DOCUMENT_VERSION_NULL_ERROR
                        )
                    )
                    return
                }
                val hitUploadApi = HitUploadNFCApi()

                val file1: MultipartBody.Part = createFormData(
                    "files[]",
                    "data:image/jpeg;base64," + SessionManager.getFrontImage(AppConstants.FRONT_IMAGE)
                )
                val file2: MultipartBody.Part = createFormData(
                    "files[]",
                    "data:image/jpeg;base64," + SessionManager.getFrontImage(AppConstants.BACK_IMAGE)
                )

                //Clearing the cached ID data
                CacheUtility.clearIDCache()
                
                hitUploadApi.iUploadCallBack = object : IUploadCallBack {
                    override fun cb(isSuccess: Boolean) {
                        //If hologram detection is false return actual ID upload result
                        if (!videoRecord) {
                            callBackU!!.cb(isSuccess)
                            return
                        }

                        //If ID upload result is success, request for hologram video upload
                        // return the hologram video result
                        if (isSuccess) {
                            CoroutineScope(Dispatchers.IO).launch {
                                val result = UploadHologramVideoUseCase(
                                    UploadVideoRecordImp(),
                                    UploadIDVideoImp()
                                ).invoke()
                                callBackU!!.cb(result)
                            }
                        } else callBackU!!.cb(false)
                    }

                }
                hitUploadApi.hitUploadNFC(activity, file1, file2, version)
            }

            AmaniVersion.V2.version -> {

                val frontID = saveRepository.getCroppedPage(Side.FRONT)
                val backID = saveRepository.getCroppedPage(Side.BACK)

                val request = ReqUploadV2()
                request.documentType = docType
                request.uploadSource = Amani.getUploadSource()

                val encodedFrontSide =
                    "data:image/jpeg;base64, $frontID"
                val encodedBackSide =
                    "data:image/jpeg;base64, $backID"

                if (backID == null) {
                    request.pages = listOf(
                        encodedFrontSide
                    )
                } else if (frontID != null) {
                    request.pages = listOf(
                        encodedFrontSide,
                        encodedBackSide
                    )
                } else {
                    callBackU!!.cb(false)
                    AmaniEvent.getEvent()?.onError(
                        type = AmaniErrorTypes.ID.name,
                        error = arrayListOf(ErrorConstants.ID_NULL_ERROR))
                    return
                }

                request.profile = SessionManager.getCustomerIdV2()
                // Explicit gate at the upload boundary: only attach `original_pages`
                // when the active Version config asks for it. Without the flag the
                // request keeps the legacy `pages`-only shape.
                if (isSendOriginalImagesEnabled(docType)) {
                    request.originalPages = buildOriginalPages()
                }

                request.nfcData = NFCData(
                    mrz = SessionManager.getMrzOnlyValue()
                        .replace("\n", ""),
                    photo = Photo(
                        base64 = SessionManager.getNFC(),
                        width = SessionManager.getNfcWidthAndHeight()[0],
                        height = SessionManager.getNfcWidthAndHeight()[1]
                    )
                )

                if (videoRecord) {
                    val videoPathFrontSide = SessionManager.getFrontSideVideoPath()
                    val videoPathBackSide = SessionManager.getBackSideVideoPath()

                    if (videoPathFrontSide != null) {
                        request.videos?.add(
                            Video(
                                path = videoPathFrontSide,
                                name = "1_id_front"
                            ).modifyFileNameAccordinglyExtension()
                        )
                    }

                    if (videoPathBackSide != null) {
                        val fileName = if (hologramDetection) "3_id_back" else "2_id_back"
                        request.videos?.add(
                            Video(
                                path = videoPathBackSide,
                                name = fileName
                            ).modifyFileNameAccordinglyExtension()
                        )
                    }
                }

                val hitUploadV2 = HitUploadApiV2()

                //Clearing the cached ID data
                CacheUtility.clearIDCache()

                hitUploadV2.requestUpload(
                    iUploadCallBack = object : IUploadCallBack {
                        override fun cb(isSuccess: Boolean) {
                            callBackU!!.cb(isSuccess)
                            CacheUtility.clearIDCache()
                        }

                        override fun cb(isSuccess: Boolean, documentID: String?) {
                            callBackU!!.cb(isSuccess, documentID)
                            CacheUtility.clearIDCache()
                        }
                    },
                    uploadRequest = request,
                    activity = activity,
                    operationID = operationID,
                    actionType = ActionTypes.ID_CAPTURE_UPLOAD_RESP
                )
            }
        }
    }
}