package ai.amani.sdk.interfaces

interface PINCallback {

    fun onSuccess()

    fun onError(exception: Exception)
}
