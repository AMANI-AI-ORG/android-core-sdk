package ai.amani.sdk.interfaces

import android.graphics.Bitmap
import java.io.File

/**
 * @Author: zekiamani
 * @Date: 17.11.2022
 */

interface ManualSelfieCaptureObserver {
    fun cb(bitmap: Bitmap?)
}