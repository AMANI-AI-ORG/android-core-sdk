package datamanager.v2.model.socket.step


import ai.amani.base.util.JSONConvertable
import com.google.gson.annotations.SerializedName

data class StepResultSocketModel(
    @SerializedName("message")
    val message: List<Message?>?,
    @SerializedName("profile")
    val profile: String?,
    @SerializedName("type")
    val type: String?
): JSONConvertable