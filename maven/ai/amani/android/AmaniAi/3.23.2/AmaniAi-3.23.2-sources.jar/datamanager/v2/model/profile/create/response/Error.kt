package datamanager.v2.model.profile.create.response


import com.google.gson.annotations.SerializedName

data class Error(
    @SerializedName("error_code")
    val errorCode: Int?,
    @SerializedName("error_message")
    val errorMessage: Any?
)