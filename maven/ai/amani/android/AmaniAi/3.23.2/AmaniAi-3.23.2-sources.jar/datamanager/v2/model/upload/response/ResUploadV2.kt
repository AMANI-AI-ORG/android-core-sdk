package datamanager.v2.model.upload.response


import com.google.gson.annotations.SerializedName

data class ResUploadV2(
    @SerializedName("approved")
    val approved: Any?,
    @SerializedName("archived")
    val archived: Boolean?,
    @SerializedName("attempt")
    val attempt: Int?,
    @SerializedName("created_at")
    val createdAt: String?,
    @SerializedName("document_type")
    val documentType: DocumentType?,
    @SerializedName("expiry_date")
    val expiryDate: Any?,
    @SerializedName("extras")
    val extras: Extras?,
    @SerializedName("id")
    val id: String?,
    @SerializedName("mrz_from_nfc")
    val mrzFromNfc: Any?,
    @SerializedName("nfc_data")
    val nfcData: Any?,
    @SerializedName("pages")
    val pages: List<Page?>?,
    @SerializedName("passed")
    val passed: Any?,
    @SerializedName("profile")
    val profile: String?,
    @SerializedName("reject_reason")
    val rejectReason: Any?,
    @SerializedName("signed")
    val signed: Boolean?,
    @SerializedName("updated_at")
    val updatedAt: String?,
    @SerializedName("upload_source")
    val uploadSource: Int?,
    @SerializedName("user")
    val user: String?,
    @SerializedName("videocall")
    val videocall: Any?
)