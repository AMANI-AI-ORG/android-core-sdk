package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Documents(
    @SerializedName("DL")
    val mDL: DocumentList? = null,

    @SerializedName("ID")
    val mID: ID? = null
) : Parcelable
