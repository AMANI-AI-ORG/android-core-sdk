package datamanager.v2.model.socket.step


import com.google.gson.annotations.SerializedName

data class Message(
    @SerializedName("adapter")
    val adapter: String?,
    @SerializedName("attempt")
    val attempt: Int?,
    @SerializedName("company")
    val company: String?,
    @SerializedName("document_classes")
    val documentClasses: List<String?>?,
    @SerializedName("id")
    val id: String?,
    @SerializedName("phase")
    val phase: Int?,
    @SerializedName("sort_order")
    val sortOrder: Int?,
    @SerializedName("status")
    val status: String?,
    @SerializedName("title")
    val title: String?,
    @SerializedName("errors")
    val errors: List<Any?>? = null,
    @SerializedName("upload_source")
    val uploadSource: String? = "kyc",
    @SerializedName("document")
    val document: String? = null,
    @SerializedName("optional")
    val optional: Boolean? = null
)