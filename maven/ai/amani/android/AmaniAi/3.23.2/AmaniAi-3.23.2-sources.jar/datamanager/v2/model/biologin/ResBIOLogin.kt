package datamanager.v2.model.biologin

import com.google.gson.annotations.SerializedName

data class ResBIOLogin(
    @SerializedName("status")
    val status: String? = null,
    /** Document id of the uploaded bio login selfie. Null when the backend does not return one. */
    @SerializedName("id")
    val id: String? = null
)
