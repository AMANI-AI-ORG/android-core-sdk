package datamanager.model.upload.bio_login.request


import com.google.gson.annotations.SerializedName
import datamanager.v2.model.upload.request.DeviceData
import datamanager.v2.model.upload.request.Location
import okhttp3.MultipartBody
import okhttp3.RequestBody

data class ReqBioLogin(
    @SerializedName("pages")
    var pages: List<String?>? = null,
    @SerializedName("cropped")
    var cropped: Boolean? = true,
    @SerializedName("device_data")
    var deviceData: DeviceData? = null,
    @SerializedName("type")
    var documentType: String? = "",
    @SerializedName("location")
    var location: Location? = null,
    @SerializedName("rotated")
    var rotated: Boolean? = true,
    @SerializedName("attempt")
    var attempt: String? = "1",
    @SerializedName("docType")
    var docType: String? = "XXX_SE_0",

) {
    fun asMultipartBody(): RequestBody {
        val builder = MultipartBody.Builder().setType(MultipartBody.FORM)
        rotated?.let { builder.addFormDataPart("rotated", it.toString()) }
        pages?.let { pagesList ->
            pagesList.forEach { page ->
                builder.addFormDataPart("pages", page!!)
            }
        }
        deviceData?.let { builder.addFormDataPart("device_data", it.toJSON()) }
        location?.let { builder.addFormDataPart("location", it.toJSON()) }
        cropped?.let { builder.addFormDataPart("cropped", it.toString()) }
        documentType?.let { builder.addFormDataPart("type", it) }
        attempt?.let { builder.addFormDataPart("attempt", it) }
        return builder.build()
    }
}