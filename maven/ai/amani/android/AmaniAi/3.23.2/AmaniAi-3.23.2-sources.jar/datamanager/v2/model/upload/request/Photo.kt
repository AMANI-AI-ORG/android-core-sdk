package datamanager.v2.model.upload.request


import com.google.gson.annotations.SerializedName
import com.google.gson.annotations.Expose

data class Photo(
    @SerializedName("base64")
    @Expose
    val base64: String?,
    @SerializedName("height")
    @Expose
    val height: Int?,
    @SerializedName("width")
    @Expose
    val width: Int?
)