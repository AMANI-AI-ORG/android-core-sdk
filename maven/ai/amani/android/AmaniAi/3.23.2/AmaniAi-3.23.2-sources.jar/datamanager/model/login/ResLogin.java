
package datamanager.model.login;

import com.google.gson.annotations.SerializedName;

import java.util.List;


public class ResLogin {

    @SerializedName("available_documents")
    private List<String> mAvailableDocuments;
    @SerializedName("company_id")
    private String mCompanyId;
    @SerializedName("email")
    private String mEmail;
    @SerializedName("groups")
    private List<String> mGroups;
    @SerializedName("name")
    private String mName;
    @SerializedName("token")
    private String mToken;

    public List<String> getAvailableDocuments() {
        return mAvailableDocuments;
    }

    public void setAvailableDocuments(List<String> availableDocuments) {
        mAvailableDocuments = availableDocuments;
    }

    public String getCompanyId() {
        return mCompanyId;
    }

    public void setCompanyId(String companyId) {
        mCompanyId = companyId;
    }

    public String getEmail() {
        return mEmail;
    }

    public void setEmail(String email) {
        mEmail = email;
    }

    public List<String> getGroups() {
        return mGroups;
    }

    public void setGroups(List<String> groups) {
        mGroups = groups;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getToken() {
        return mToken;
    }

    public void setToken(String token) {
        mToken = token;
    }

}
