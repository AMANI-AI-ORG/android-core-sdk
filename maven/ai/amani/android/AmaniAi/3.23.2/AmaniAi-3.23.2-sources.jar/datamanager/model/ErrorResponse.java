package datamanager.model;

import com.google.gson.annotations.SerializedName;


public class ErrorResponse extends Throwable {
    @SerializedName("code")
    private int mCode;

    @SerializedName("messageCode")
    private String mMessageCode;

    @SerializedName("descrption")
    private String mDescription;

    public int getCode() {
        return mCode;
    }

    public void setCode(int code) {
        this.mCode = code;
    }

    public String getMessageCode() {
        return mMessageCode;
    }

    public void setMessageCode(String messageCode) {
        this.mMessageCode = messageCode;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String description) {
        this.mDescription = description;
    }
}
