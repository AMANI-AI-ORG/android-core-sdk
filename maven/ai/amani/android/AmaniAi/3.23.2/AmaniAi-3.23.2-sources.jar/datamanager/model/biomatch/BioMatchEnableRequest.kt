package datamanager.model.biomatch

import com.google.gson.annotations.SerializedName

data class BioMatchEnableRequest(
    @SerializedName("pin") val pin: String
)