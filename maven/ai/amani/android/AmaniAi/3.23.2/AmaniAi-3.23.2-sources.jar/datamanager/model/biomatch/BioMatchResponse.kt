package datamanager.model.biomatch

import com.google.gson.annotations.SerializedName

data class BioMatchResponse(
    @SerializedName("status")
    val status: String
)