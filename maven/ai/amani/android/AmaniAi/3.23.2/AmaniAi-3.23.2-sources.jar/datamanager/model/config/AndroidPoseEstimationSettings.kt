package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class AndroidPoseEstimationSettings(
    @SerializedName("eyesClosureThreshold")
    val eyesClosureThreshold: Double = 0.15,

    @SerializedName("enableEyesClosureCheck")
    val enableEyesClosure: Boolean = false
): Parcelable
