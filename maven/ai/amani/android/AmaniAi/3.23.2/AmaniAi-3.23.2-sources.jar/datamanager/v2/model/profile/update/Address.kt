package datamanager.v2.model.profile.update


import com.google.gson.annotations.SerializedName
import com.google.gson.annotations.Expose

data class Address(
    @SerializedName("address")
    @Expose
    val address: String?,
    @SerializedName("city")
    @Expose
    val city: String?,
    @SerializedName("province")
    @Expose
    val province: String?
)