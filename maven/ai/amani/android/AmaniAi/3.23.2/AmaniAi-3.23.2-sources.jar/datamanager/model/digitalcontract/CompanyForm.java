package datamanager.model.digitalcontract;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CompanyForm {

    @SerializedName("document_url")
    @Expose
    private String documentUrl = null;
    @SerializedName("encoded_document")
    @Expose
    private String encodedDocument;

    public String getDocumentUrl() {
        return documentUrl;
    }

    public void setDocumentUrl(String documentUrl) {
        this.documentUrl = documentUrl;
    }

    public String getEncodedDocument() {
        return encodedDocument;
    }

    public void setEncodedDocument(String encodedDocument) {
        this.encodedDocument = encodedDocument;
    }
}
