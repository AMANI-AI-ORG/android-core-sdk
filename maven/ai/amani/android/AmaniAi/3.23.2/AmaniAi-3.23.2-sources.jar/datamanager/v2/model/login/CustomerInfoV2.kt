package datamanager.v2.model.login

/**
 * @Author: zekiamani
 * @Date: 6.03.2023
 */
data class CustomerInfoV2(
    var customerId: String = "",
    var companyId: String = ""
)
