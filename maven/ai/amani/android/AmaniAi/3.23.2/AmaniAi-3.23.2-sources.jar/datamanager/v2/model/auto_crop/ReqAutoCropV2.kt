package datamanager.v2.model.auto_crop


import com.google.gson.annotations.SerializedName

data class ReqAutoCropV2(
    @SerializedName("pages")
    val pages: List<String?>?,
    @SerializedName("type")
    val type: String?
)