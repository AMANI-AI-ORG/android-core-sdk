package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class StepConfig (
    @SerializedName("buttonColor")
    val buttonColor: ButtonColor = ButtonColor(),

    @SerializedName("buttonText")
    val buttonText: ButtonText = ButtonText(),

    @SerializedName("documentSelectionDescription")
    val documentSelectionDescription: String = "",

    @SerializedName("documentSelectionTitle")
    val documentSelectionTitle: String = "",

    @SerializedName("documents")
    val mDocuments: ArrayList<DocumentList?>? = null,

    @SerializedName("id")
    val id: String = "",

    @SerializedName("maxAttempt")
    var maxAttempt: Long = 3,

    @SerializedName("phase")
    var phase: Long = 0,

    @SerializedName("title")
    val title: String = "",

    @SerializedName("buttonTextColor")
    val buttonTextColor: ButtonTextColor = ButtonTextColor(),

    @SerializedName("formID")
    var formID: Int = 0,

    @SerializedName("documentGlaredText")
    @Expose
    var documentGlaredText: String = "",

    @SerializedName("documentBlurredText")
    @Expose
    var documentBlurredText: String = "",

    @SerializedName("documentNotCroppedText")
    @Expose
    var documentNotCroppedText: String = "",

    @SerializedName("type")
    @Expose
    var type: String? = null,

    @SerializedName("identifier")
    @Expose
    var identifier: String = "",

    @SerializedName("mandatoryStepIDs")
    @Expose
    var mandatoryStepIDs: List<String>? = null
):Parcelable
