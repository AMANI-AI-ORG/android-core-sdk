package datamanager.v2.model.video_record

import com.google.gson.annotations.SerializedName


data class VideoRecordResponseModel(
    @SerializedName("created_at")
    val createdAt: Int,
    @SerializedName("document")
    val document: Any,
    @SerializedName("file")
    val `file`: String,
    @SerializedName("id")
    val id: String,
    @SerializedName("profile")
    val profile: String,
    @SerializedName("updated_at")
    val updatedAt: Int,
    @SerializedName("user")
    val user: String,
    @SerializedName("video_type")
    val videoType: String
)