package datamanager.v2.model.questionnaire


import com.google.gson.annotations.SerializedName

data class Answer(
    @SerializedName("id")
    val id: String,
    @SerializedName("is_enabled")
    val isEnabled: Boolean,
    @SerializedName("title")
    val title: String
)