package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class ResGetConfig(
    @SerializedName("general_configs")
    val generalConfigs: GeneralConfigs? = GeneralConfigs(),
    @SerializedName("step_configs")
    val stepConfigs: List<StepConfig> = listOf(StepConfig())
) : Parcelable