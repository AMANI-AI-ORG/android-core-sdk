package datamanager.model.customer;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Address {

    @SerializedName("city")
    @Expose
    private String city;
    @SerializedName("address")
    @Expose
    private String address;
    @SerializedName("province")
    @Expose
    private String province;
    @SerializedName("confidence")
    @Expose
    private Integer confidence;

    public String getCity() { return city; }

    public void setCity(String city) { this.city = city; }

    public String getAddress() { return address; }

    public void setAddress(String address) { this.address = address; }

    public String getProvince() { return province; }

    public void setProvince(String province) { this.province = province; }

    public Integer getConfidence() { return confidence; }

    public void setConfidence(Integer confidence) { this.confidence = confidence; }
}
