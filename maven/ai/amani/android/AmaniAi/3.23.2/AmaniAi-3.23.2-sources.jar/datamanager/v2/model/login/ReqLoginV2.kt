package datamanager.v2.model.login


import com.google.gson.annotations.SerializedName

data class ReqLoginV2(
    @SerializedName("password")
    val password: String?,
    @SerializedName("username")
    val username: String?
)