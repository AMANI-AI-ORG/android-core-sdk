package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class ButtonTextColor(
    @SerializedName("APPROVED")
    @Expose
    var approved: String = "#5BC792",
    @SerializedName("REJECTED")
    @Expose
    var rejected: String = "#0A0202",
    @SerializedName("PROCESSING")
    @Expose
    var processing: String = "#EA3365",
    @SerializedName("NOT_UPLOADED")
    @Expose
    var notUploaded: String = "#5BC792",
    @SerializedName("PENDING_REVIEW")
    @Expose
    var pendingReview: String = "#565656",
    @SerializedName("AUTOMATICALLY_REJECTED")
    @Expose
    var automaticallyRejected: String = "#0A0202"
) : Parcelable
