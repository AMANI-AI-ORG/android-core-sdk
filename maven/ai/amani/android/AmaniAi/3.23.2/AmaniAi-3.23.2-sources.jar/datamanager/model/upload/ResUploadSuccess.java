package datamanager.model.upload;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import datamanager.model.customer.Errors;

public class ResUploadSuccess {
    @SerializedName("status")
    @Expose
    private String status;

    @SerializedName("result")
    @Expose
    private boolean result;

    @SerializedName("recognition_id")
    @Expose
    private Integer recognition_id;


   /* @SerializedName("status_message")
    @Expose
    private Object statusMessage;
    @SerializedName("recognition_id")
    @Expose
    private Integer recognitionId;
    @SerializedName("accepted_documents")
    @Expose
    private List<String> acceptedDocuments = null;
    */
    @SerializedName("errors")
    @Expose
    private List<Errors> errors = null;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    public boolean getResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    /*public Object getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(Object statusMessage) {
        this.statusMessage = statusMessage;
    }

    public Integer getRecognitionId() {
        return recognitionId;
    }

    public void setRecognitionId(Integer recognitionId) {
        this.recognitionId = recognitionId;
    }

    public List<String> getAcceptedDocuments() {
        return acceptedDocuments;
    }

    public void setAcceptedDocuments(List<String> acceptedDocuments) {
        this.acceptedDocuments = acceptedDocuments;
    }



    public void setErrors(List<Errors> errors) {
        this.errors = errors;
    }*/

    public List<Errors> getErrors() {
        return errors;
    }

    public Integer getRecognitionID() {return recognition_id; }

}
