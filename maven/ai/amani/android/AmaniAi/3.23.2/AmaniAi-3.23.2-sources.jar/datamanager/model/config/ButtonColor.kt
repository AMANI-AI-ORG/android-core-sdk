package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class ButtonColor (
    @SerializedName("APPROVED")
    val approved: String = "#5BC792",

    @SerializedName("AUTOMATICALLY_REJECTED")
    val automaticallyRejected: String = "#0A0202",

    @SerializedName("NOT_UPLOADED")
    val notUploaded: String = "#EA3365",

    @SerializedName("PENDING_REVIEW")
    val pendingReview: String = "#5BC792",

    @SerializedName("PROCESSING")
    val processing: String = "#565656",

    @SerializedName("REJECTED")
    val rejected: String = "#0A0202"
):Parcelable
