package datamanager.v2.model.socket.profile_status


import com.google.gson.annotations.SerializedName

data class Message(
    @SerializedName("aml_status")
    val amlStatus: Boolean?,
    @SerializedName("risk")
    val risk: Int?,
    @SerializedName("status")
    val status: String?
)