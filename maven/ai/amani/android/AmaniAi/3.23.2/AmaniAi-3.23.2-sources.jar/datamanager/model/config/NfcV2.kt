package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

/**
 * Remote configuration for the V2 NFC scan screen.
 *
 * Delivered by the backend inside [Version.nfcV2]. Its [animationStates] carry the copy the V2 UI
 * renders natively over the NFC animation — the animation JSON itself has no baked text, so each
 * state marker in the timeline picks its line from here.
 *
 * Example JSON:
 * ```json
 * "nfcV2": {
 *   "animationHint": "Follow the instructions in the animation below",
 *   "animationStates": {
 *     "place": "Place the document behind your phone",
 *     "detected": "Chip located",
 *     "hold": "Hold still",
 *     "reading": "Reading…",
 *     "dontMove": "Don't move your phone",
 *     "remove": "You can take the phone away",
 *     "retry": "Try again and reposition the phone",
 *     "success": "Read complete"
 *   }
 * }
 * ```
 */
@Parcelize
data class NfcV2(

    /** Per-state copy for the NFC animation, keyed by the animation's state markers. */
    @SerializedName("animationStates")
    var animationStates: NfcV2AnimationStates? = NfcV2AnimationStates(),

    /** Line shown above the animation, introducing it. */
    @SerializedName("animationHint")
    var animationHint: String = "Follow the instructions in the animation below",

) : Parcelable

/**
 * The eight NFC animation states, in timeline order. A blank value falls back to the SDK default
 * for that state.
 */
@Parcelize
data class NfcV2AnimationStates(

    /** Shown while waiting for the document to be placed against the phone. */
    @SerializedName("place")
    var place: String = "Place the document behind your phone",

    /** Shown the moment the chip is found. */
    @SerializedName("detected")
    var detected: String = "Chip located",

    /** Shown while the connection settles, before reading starts. */
    @SerializedName("hold")
    var hold: String = "Hold still",

    /** Shown while the chip is being read. */
    @SerializedName("reading")
    var reading: String = "Reading…",

    /** Shown mid-read, warning the user not to move the phone. */
    @SerializedName("dontMove")
    var dontMove: String = "Don't move your phone",

    /** Shown once the read finished and the phone can be taken away. */
    @SerializedName("remove")
    var remove: String = "You can take the phone away",

    /** Shown when the read failed and the user should reposition the phone. */
    @SerializedName("retry")
    var retry: String = "Try again and reposition the phone",

    /** Shown on a completed read. */
    @SerializedName("success")
    var success: String = "Read complete",

) : Parcelable
