package datamanager.v2.model.questionnaire


import com.google.gson.annotations.SerializedName

data class QuestionnarieResponseModelItem(
    @SerializedName("answer_type")
    val answerType: String,
    @SerializedName("answers")
    val answers: List<Answer>,
    @SerializedName("id")
    val id: String,
    @SerializedName("is_enabled")
    val isEnabled: Boolean,
    @SerializedName("optional")
    val optional: Boolean,
    @SerializedName("sort_order")
    val sortOrder: Int,
    @SerializedName("title")
    val title: String
)