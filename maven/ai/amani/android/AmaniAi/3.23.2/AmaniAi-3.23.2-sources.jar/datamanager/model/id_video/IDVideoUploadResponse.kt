package datamanager.model.id_video


import com.google.gson.annotations.SerializedName

data class IDVideoUploadResponse(
    @SerializedName("created_at")
    val createdAt: String,
    @SerializedName("customer")
    val customer: Int,
    @SerializedName("customer_id")
    val customerId: Int,
    @SerializedName("file")
    val file: String,
    @SerializedName("id")
    val id: Int,
    @SerializedName("recognition")
    val recognition: Int,
    @SerializedName("video_type")
    val videoType: Int
)