package datamanager.v2.model.socket.validation


import com.google.gson.annotations.SerializedName

data class Message(
    @SerializedName("result")
    val result: List<Result?>?
)