package datamanager.v2.model.upload.request


import ai.amani.base.util.JSONConvertable
import com.google.gson.annotations.SerializedName

data class DeviceData(
    @SerializedName("brand")
    val brand: String?,
    @SerializedName("model")
    val model: String?,
    @SerializedName("carrier")
    val carrier: String?,
    @SerializedName("id")
    val id: String?,
    @SerializedName("os")
    val os: String?,
    @SerializedName("osVersion")
    val osVersion: String?,
    @SerializedName("sdkVersion")
    val sdkVersion: String?,
    @SerializedName("isRooted")
    val isRooted: Boolean = false,
    @SerializedName("isSSLPinningEnabled")
    val isSSLPinningEnabled: Boolean = false
):JSONConvertable