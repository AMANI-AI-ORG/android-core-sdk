package datamanager.model.customer

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Errors (
    @SerializedName("error_code")
    @Expose
    var errorCode: Int = 0,

    @SerializedName("error_message")
    @Expose
    var errorMessage: String = "null"
):Parcelable