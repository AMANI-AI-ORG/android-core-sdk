package datamanager.model.customer;

import com.google.gson.annotations.SerializedName;

public class ReqCreateCustomer {
    @SerializedName("id_card_number")
    private String mIdCardNumber;
    @SerializedName("name")
    private String mName;
    @SerializedName("email")
    private String mEmail;
    @SerializedName("phone")
    private String mPhone;

    public String getIdCardNumber() {
        return mIdCardNumber;
    }

    public String getName() {
        return mName;
    }

    public String getEmail() {
        return mEmail;
    }

    public String getPhone() {
        return mPhone;
    }

    public static class Builder {
        @SerializedName("id_card_number")
        private String mIdCardNumber;
        private String mName;
        private String mEmail;
        private String mPhone;

        public Builder withIdCardNumber(String idCardNumber) {
            mIdCardNumber = idCardNumber;
            return this;
        }

        public Builder withName(String name) {
            mName = name;
            return this;
        }

        public Builder withEmail(String email) {
            mEmail = email;
            return this;
        }

        public Builder withPhone(String phone) {
            mPhone = phone;
            return this;
        }

        public ReqCreateCustomer build() {
            ReqCreateCustomer reqCreateCustomer = new ReqCreateCustomer();
            reqCreateCustomer.mIdCardNumber = mIdCardNumber;
            reqCreateCustomer.mName = mName;
            reqCreateCustomer.mEmail = mEmail;
            reqCreateCustomer.mPhone = mPhone;
            return reqCreateCustomer;
        }
    }
}