package datamanager.model.upload;

import com.google.gson.annotations.SerializedName;


public class ReqNfcOnly {
    @SerializedName("nfc")
    private String mNfc;


    public String getNfc() {
        return mNfc;
    }



    public static class Builder {

        private String mNfc;

        public Builder withNfc (String nfc) {
            mNfc = nfc;
            return this;
        }



        public ReqNfcOnly build() {
            ReqNfcOnly reqNfcOnly = new ReqNfcOnly();
            reqNfcOnly.mNfc = mNfc;
            return reqNfcOnly;
        }

    }
}
