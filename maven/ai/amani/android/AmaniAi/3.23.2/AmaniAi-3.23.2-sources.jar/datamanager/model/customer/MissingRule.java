package datamanager.model.customer;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class MissingRule {

    @SerializedName("id")
    @Expose
    public Integer id;
    @SerializedName("title")
    @Expose
    public String title;
    @SerializedName("phase")
    @Expose
    public Integer phase;
    @SerializedName("document_classes")
    @Expose
    public List<String> documentClasses = null;
    @SerializedName("sort_order")
    @Expose
    public Integer sortOrder;

    public Integer getId() { return id; }

    public void setId(Integer id) { this.id = id; }

    public String getTitle() { return title; }

    public void setTitle(String title) { this.title = title; }

    public Integer getPhase() { return phase; }

    public void setPhase(Integer phase) { this.phase = phase; }

    public List<String> getDocumentClasses() { return documentClasses; }

    public void setDocumentClasses(List<String> documentClasses) { this.documentClasses = documentClasses; }

    public Integer getSortOrder() { return sortOrder; }

    public void setSortOrder(Integer sortOrder) { this.sortOrder = sortOrder; }
}
