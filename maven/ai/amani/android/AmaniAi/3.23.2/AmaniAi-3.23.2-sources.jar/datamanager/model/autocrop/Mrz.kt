package datamanager.model.autocrop

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Mrz(
    @SerializedName("value")
    @Expose
    var value: String? = null,

    @SerializedName("MRZFullName")
    @Expose
    var mrzFullName: String? = null,

    @SerializedName("MRZDocumentNumber")
    @Expose
    var mrzDocumentNumber: String? = null,

    @SerializedName("MRZDocumentNumberCD")
    @Expose
    var mrzDocumentNumberCD: String? = null,

    @SerializedName("MRZIDNumber")
    @Expose
    var mrzIDNumber: String? = null,

    @SerializedName("MRZBirthDate")
    @Expose
    var mrzBirthDate: String? = null,

    @SerializedName("MRZBirthDateCD")
    @Expose
    var mrzBirthDateCD: String? = null,

    @SerializedName("MRZExpiryDate")
    @Expose
    var mrzExpiryDate: String? = null,

    @SerializedName("MRZExpiryDateCD")
    @Expose
    var mrzExpiryDateCD: String? = null,

    @SerializedName("MRZIDNumberCD")
    @Expose
    var mrzIDNumberCD: String? = null,

    @SerializedName("MRZFirstName")
    @Expose
    var mrzFirstName: String? = null,

    @SerializedName("MRZLastName")
    @Expose
    var mrzLastName: String? = null,

    @SerializedName("MRZSex")
    @Expose
    var mrzSex: String? = null,

    @SerializedName("MRZType")
    @Expose
    var mrzType: String? = null,

    @SerializedName("MRZCountryCode")
    @Expose
    var mrzCountryCode: String? = null,

    @SerializedName("MRZNationality")
    @Expose
    var mrzNationality: String? = null,

    @SerializedName("MRZOptionalData")
    @Expose
    var mrzOptionalData: String? = null,

    @SerializedName("MRZOverallCD")
    @Expose
    var mrzOverallCD: String? = null,

    @SerializedName("confidence")
    @Expose
    var confidence: Int? = null,

    @SerializedName("x")
    @Expose
    var x: Int? = null,

    @SerializedName("y")
    @Expose
    var y: Int? = null,

    @SerializedName("w")
    @Expose
    var w: Int? = null,

    @SerializedName("h")
    @Expose
    var h: Int? = null,

    @SerializedName("roi")
    @Expose
    var roi: String? = null,

    @SerializedName("letter_height")
    @Expose
    var letterHeight: Int? = null,

    @SerializedName("letter_spacing")
    @Expose
    var letterSpacing: Int? = null
) : Parcelable
