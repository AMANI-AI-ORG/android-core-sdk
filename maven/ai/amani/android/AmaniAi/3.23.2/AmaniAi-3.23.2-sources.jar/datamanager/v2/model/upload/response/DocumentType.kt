package datamanager.v2.model.upload.response


import com.google.gson.annotations.SerializedName

data class DocumentType(
    @SerializedName("code")
    val code: String?,
    @SerializedName("document_class")
    val documentClass: Any?,
    @SerializedName("name")
    val name: String?,
    @SerializedName("page_count")
    val pageCount: Any?
)