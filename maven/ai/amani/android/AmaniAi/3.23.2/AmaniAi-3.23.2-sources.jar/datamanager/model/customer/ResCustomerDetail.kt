package datamanager.model.customer

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ResCustomerDetail {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("email")
    @Expose
    var email: String? = null

    @SerializedName("phone")
    @Expose
    var phone: String? = null

    @SerializedName("type")
    @Expose
    var type: Any? = null

    @SerializedName("occupation")
    @Expose
    var occupation: String? = null

    @SerializedName("company_id")
    @Expose
    var companyId: Int? = null

    @SerializedName("name")
    @Expose
    var name: String? = null

    @SerializedName("gender")
    @Expose
    var gender: String? = null

    @SerializedName("nationality")
    @Expose
    var nationality: String? = null

    @SerializedName("date_of_birth")
    @Expose
    var dateOfBirth: String? = null

    @SerializedName("address")
    @Expose
    var address: Address? = null

    @SerializedName("status")
    @Expose
    var status: String? = null

    @SerializedName("last_status_update")
    @Expose
    var lastStatusUpdate: String? = null

    @SerializedName("aml_status")
    @Expose
    var amlStatus: Boolean? = null

    @SerializedName("aml_last_check")
    @Expose
    var amlLastCheck: String? = null

    @SerializedName("date")
    @Expose
    var date: String? = null

    @SerializedName("risk")
    @Expose
    var risk: Any? = null

    @SerializedName("created_by")
    @Expose
    var createdBy: String? = null

    @SerializedName("photo")
    @Expose
    var photo: String? = null

    @SerializedName("id_card_number")
    @Expose
    var idCardNumber: String? = null

    @SerializedName("passport_number")
    @Expose
    var passportNumber: Any? = null

    @SerializedName("company_short_code")
    @Expose
    var companyShortCode: String? = null

    @SerializedName("rules")
    @Expose
    var rules: ArrayList<Rule> = arrayListOf()

    @SerializedName("approval_expiration")
    @Expose
    var approvalExpiration: Any? = null

    @SerializedName("missing_rules")
    @Expose
    var missingRules: List<MissingRule> = emptyList()

    @SerializedName("extra")
    @Expose
    var extra: Extra? = null

    @SerializedName("token")
    @Expose
    val customerToken: String? = null
}
