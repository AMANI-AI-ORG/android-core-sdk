package datamanager.model.biomatch

import com.google.gson.annotations.SerializedName

data class BioPayDisableRequest(
    @SerializedName("disable") val disable: Boolean = true
)