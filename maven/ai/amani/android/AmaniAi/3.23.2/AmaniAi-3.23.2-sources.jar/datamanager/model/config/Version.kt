package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Version(
    @SerializedName("aspectRatio")
    var aspectRatio: Double? = null,

    @SerializedName("cameraFacing")
    var cameraFacing: String = "front",

    @SerializedName("manualCrop")
    var manualCrop: Boolean = false,

    @SerializedName("nfc")
    var nfc: Boolean = false,

    @SerializedName("photoLibrary")
    var photoLibrary: Boolean = false,

    @SerializedName("documentSource")
    var documentSource: String = "camera",

    /**
     * Label of the gallery option of the source dialog an `optional` [documentSource] shows.
     * Empty when the config leaves it out, so the UI falls back to its own text.
     */
    @SerializedName("uploadViaGalleryText")
    var uploadViaGalleryText: String = "",

    /**
     * Label of the PDF option of the source dialog an `optional` [documentSource] shows; the
     * recommended one, so the text carries the recommendation (e.g. "Upload via PDF
     * (Recommended)"). Empty when the config leaves it out, so the UI falls back to its own text.
     */
    @SerializedName("uploadViaPdfText")
    var uploadViaPdfText: String = "",

    /**
     * Label of the camera option of the source dialog an `optional` [documentSource] shows.
     * Empty when the config leaves it out, so the UI falls back to its own text.
     */
    @SerializedName("uploadViaCameraText")
    var uploadViaCameraText: String = "",

    @SerializedName("steps")
    var steps: List<Step> = listOf(),

    @SerializedName("title")
    var title: String = "title",

    @SerializedName("type")
    var type: String = "XXX",

    @SerializedName("nfcOnly")
    private var mNfcOnly: Boolean = false,

    @SerializedName("nfcTitle")
    var nfcTitle: String = "NFC",

    @SerializedName("nfcFailed")
    var nfcFailed: String = "NFC Failed",

    @SerializedName("nfcFailedDescription")
    var nfcFailedDescription: String = "NFC is failed",

    @SerializedName("nfcDescription1")
    var nfcDescription1: String = "",

    @SerializedName("nfcDescription2")
    var nfcDescription2: String = "",

    @SerializedName("nfcDescription3")
    var nfcDescription3: String = "",

    @SerializedName("nfcDialogTitle")
    var nfcDialogTitle: String = "NFC Scanning",

    @SerializedName("nfcDialogDescription")
    var nfcDialogDescription: String = "While NFC is scanning please hold your ID Card stable",

    @SerializedName("mrzReadErrorText")
    var mrzReadErrorText: String = "MRZ read error",

    @SerializedName("maxAttempt")
    var maxAttempt: Int = 3,

    @SerializedName("holdStable")
    var holdStableText: String = "Please hold stable",

    @SerializedName("nfcPleaseHold")
    var nfcPleaseHold: String = "NFC please hold stable",

    @SerializedName("nfcFailedScreen")
    private var nfcFailedScreen: Boolean = false,

    @SerializedName("nfcFailedScreenText1")
    var nfcFailedScreenText1: String = "",

    @SerializedName("nfcFailedScreenText2")
    var nfcFailedScreenText2: String = "",

    @SerializedName("nfcFailedScreenText3")
    var nfcFailedScreenText3: String = "",

    @SerializedName("cancelButtonText")
    var cancelButtonText: String = "",

    @SerializedName("continueButtonText")
    var continueButtonText: String = "",

    @SerializedName("enableNfcHeader")
    var enableNfcHeader: String = "",

    @SerializedName("enableNfcDescription")
    var enableNfcDescription: String = "",

    @SerializedName("nfcAnimationColor")
    var nfcAnimationColor: String = "#ffffff",

    @SerializedName("neigborhoodText")
    var neigborhoodText: String = "",

    @SerializedName("exteriorDoorText")
    var exteriorDoorText: String = "",

    @SerializedName("interiorDoorText")
    var interiorDoorText: String = "",

    @SerializedName("selectCountryText")
    var selectCountryText: String = "",

    @SerializedName("captureDocumentText")
    var captureDocumentText: String = "",

    @SerializedName("occupationText")
    var occupationText: String = "",

    @SerializedName("basicInfoText")
    var basicInfoText: String = "",

    @SerializedName("signatureMatchText")
    var signatureMatchText: String = "",

    @SerializedName("contractConfirmText")
    var contractConfirmText: String = "",

    @SerializedName("contractCheckBoxText")
    var contractCheckBoxText: String = "",

    @SerializedName("clearText")
    var clearText: String = "",

    @SerializedName("selectCityText")
    var selectCityText: String = "",

    @SerializedName("selectProvinceText")
    var selectProvinceText: String = "",

    @SerializedName("mainRoadText")
    var mainRoadText: String = "",

    @SerializedName("COdesc1Text")
    var cOdesc1Text: String = "",

    @SerializedName("COdesc2Text")
    var cOdesc2Text: String = "",

    @SerializedName("COdesc3Text")
    var cOdesc3Text: String = "",

    @SerializedName("COheaderText")
    var cOheaderText: String = "",

    @SerializedName("COuploadText")
    var cOuploadText: String = "",

    @SerializedName("COdownloadText")
    var cOdownloadText: String = "",

    @SerializedName("disableDocUploadBtn")
    var disableDocUploadBtn: Boolean = false,

    @SerializedName("manualTextEntry")
    var manualTextEntry: Boolean = false, // Default value is false (if config is empty)

    //----- Pose Estimation/ Auto Selfie ----
    @SerializedName("selfieType")
    var selfieType: Int = -1,

    @SerializedName("informationScreenTitle")
    var informationScreenTitle: String = "",

    @SerializedName("turnLeftText")
    var turnLeftText: String = "",

    @SerializedName("turnRightText")
    var turnRightText: String = "",

    @SerializedName("turnUpText")
    var turnUpText: String = "",

    @SerializedName("turnDownText")
    var turnDownText: String = "",

    @SerializedName("selfieAnimationColor")
    var selfieAnimationColor: String = "#ffffff",

    @SerializedName("informationScreenDesc1")
    var informationScreenDesc1: String = "",

    @SerializedName("informationScreenDesc2")
    var informationScreenDesc2: String = "",

    @SerializedName("selfieAlertTitle")
    var selfieAlertTitle: String = "",

    @SerializedName("selfieAlertDescription")
    var selfieAlertDescription: String = "",

    @SerializedName("selfieAlertTryAgain")
    var selfieAlertTryAgain: String = "",

    @SerializedName("ovalViewSuccess ")
    var ovalViewSuccessColor: String = "#ffffff",

    @SerializedName("ovalViewStartColor")
    var ovalViewStartColor: String = "#ffffff",

    @SerializedName("ovalViewErrorColor")
    var ovalViewErrorColor: String = "#ffffff",

    @SerializedName("faceIsTooFarText")
    var faceIsTooFarText: String = "",

    @SerializedName("keepStraightText")
    var keepStraightText: String = "",

    @SerializedName("faceNotStraightText")
    var faceNotStraightText: String = "",

    @SerializedName("faceNotInsideText")
    var faceNotInsideText: String = "",

    /** GenericAutoCapture/DefaultAutoCapture */
    @SerializedName("genericAutoCaptureAndroid")
    var genericAutoCaptureAndroid: Boolean = false,

    @SerializedName("isHidden")
    var isHidden: Boolean = false,

    /** Enables the camera auto focusing */
    @SerializedName("autoFocus")
    var autoFocus: Int = 5,

    /** Enables the recording video */
    @SerializedName("recordVideo")
    var videoRecord: Boolean = false,

    /** Enabled the hologram check */
    @SerializedName("hologramDetection")
    var hologramDetection: Boolean = false,

    @Transient
    var documentId: String = "ID",

    @Transient
    var stepId: Int = 0,

    @SerializedName("birthDateHint")
    val birthDateHint: String = "",

    @SerializedName("birthDateTitle")
    val birthDateTitle: String = "",

    @SerializedName("emailHint")
    val emailHint: String = "",

    @SerializedName("emailTitle")
    val emailTitle: String = "",

    @SerializedName("invalidEmailError")
    val invalidEmailError: String = "",

    @SerializedName("invalidPhoneNumberError")
    val invalidPhoneNumberError: String = "",

    @SerializedName("nameHint")
    val nameHint: String = "",

    @SerializedName("nameTitle")
    val nameTitle: String = "",

    @SerializedName("phoneHint")
    val phoneHint: String = "",

    @SerializedName("phoneTitle")
    val phoneTitle: String = "",

    @SerializedName("resendOTP")
    val resendOTP: String = "",

    @SerializedName("surnameHint")
    val surnameHint: String = "",

    @SerializedName("surnameTitle")
    val surnameTitle: String = "",

    @SerializedName("missingQuestionError")
    val missingQuestionError: String = "",

    @SerializedName("otpTitle")
    val otpTitle: String = "",

    @SerializedName("documentNoTitle")
    var documentNoTitle: String = "",

    @SerializedName("nfcConfigureTitle")
    var nfcConfigureTitle: String = "",

    @SerializedName("documentDateOfBirth")
    var documentDateOfBirth: String = "",

    @SerializedName("documentDateOfExpiry")
    var documentDateOfExpiry: String = "",

    @SerializedName("nfcAndroid")
    var nfcAndroid: Boolean? = null,

    @SerializedName("imageSharpnessThreshold")
    var imageSharpnessThreshold: Int = 3400,

    @SerializedName("androidAutoCaptureSettings")
    var androidAutoCaptureSettings: AndroidAutoCaptureSettings? = AndroidAutoCaptureSettings(),

    @SerializedName("androidPoseEstimationSettings")
    var androidPoseEstimationSettings: AndroidPoseEstimationSettings? = AndroidPoseEstimationSettings(),

    /** Remote config for the Pose Estimation v2 preparation screen. */
    @SerializedName("poseEstimationV2Preparation")
    var poseEstimationV2Preparation: PoseEstimationV2Preparation? = null,

    /** Remote config for the V2 NFC scan screen (animation state copy). */
    @SerializedName("nfcV2")
    var nfcV2: NfcV2? = null,

    @SerializedName("sendOriginalImages")
    var sendOriginalImages: Boolean = false,

    // ----- V2 Step Configs (shared by ID & Selfie versions) -----
    @SerializedName("v2EstimatedTime")
    var v2EstimatedTime: String = "about 30 sec",

    @SerializedName("v2StepRejectionTitle")
    var v2StepRejectionTitle: String = "This step could not be verified",

    @SerializedName("v2StepRejectionDescription")
    var v2StepRejectionDescription: String = "Please capture again in good lighting.",

    @SerializedName("v2DocumentConfirmationNavTitle")
    var v2DocumentConfirmationNavTitle: String = "Review your capture",

    @SerializedName("v2DocumentConfirmationHeader")
    var v2DocumentConfirmationHeader: String = "Everything look right?",

    @SerializedName("v2DocumentConfirmationSubtitle")
    var v2DocumentConfirmationSubtitle: String = "Make sure everything is clear and fully visible.",

    @SerializedName("v2DocumentQualityHeader")
    var v2DocumentQualityHeader: String = "QUALITY CHECKS",

    @SerializedName("v2DocumentQuality1")
    var v2DocumentQuality1: String = "Clear and in focus",

    @SerializedName("v2DocumentQuality2")
    var v2DocumentQuality2: String = "Fully visible in frame",

    @SerializedName("v2DocumentQuality3")
    var v2DocumentQuality3: String = "No glare or heavy shadows",

    // ----- V2 Step Configs (ID only) -----
    @SerializedName("v2DocSelectionPlaceholder")
    var v2DocSelectionPlaceholder: String = "Choose a document type to proceed",

    @SerializedName("v2NfcChipLabel")
    var v2NfcChipLabel: String = "Quickest via NFC",

    @SerializedName("v2NfcSearchingText")
    var v2NfcSearchingText: String = "Looking for the chip...",

    // ----- Speech verification (ST document, "XXX_ST_0") -----
    /** Per-step time window in seconds before an attempt fails. */
    @SerializedName("timeoutSeconds")
    var timeoutSeconds: Int = 60,

    /** Ordered verification flow + thresholds + word-exemption for the speech verifier. */
    @SerializedName("speechVerification")
    var speechVerification: SpeechVerification? = null,

    /** On-screen prompt overrides for the identity questions. */
    @SerializedName("speechVerifierIdentityPrompts")
    var speechVerifierIdentityPrompts: SpeechVerifierIdentityPrompts? = null,

    /** On-camera text overrides for the speech verifier. */
    @SerializedName("speechVerifierUiTexts")
    var speechVerifierUiTexts: SpeechVerifierUiTexts? = null,

    /** Color overrides for the speech verifier. */
    @SerializedName("speechVerifierUiColors")
    var speechVerifierUiColors: SpeechVerifierUiColors? = null,

    // ----- V2 prep/guide (ID & Selfie) — one param per position; each Version (ID vs
    // Selfie) fills them with its own copy. "primary" = front / first selfie screen,
    // "second" = back / pose screen. Blank = fall back to the built-in UI default.
    @SerializedName("v2GuideEyebrow")
    var v2GuideEyebrow: String = "",

    /**
     * Prefix shown before [v2GuideEyebrow] on a two-sided document, e.g. "Step 1 of 2 · ".
     * `{current}` and `{total}` are replaced with the side being captured and the side count.
     */
    @SerializedName("v2GuideStepPrefix")
    var v2GuideStepPrefix: String = "Step {current} of {total} · ",

    @SerializedName("v2GuideTitle")
    var v2GuideTitle: String = "",

    @SerializedName("v2GuideDescription")
    var v2GuideDescription: String = "",

    @SerializedName("v2GuideChecklistHeader")
    var v2GuideChecklistHeader: String = "",

    @SerializedName("v2GuideCheck1")
    var v2GuideCheck1: String = "",

    @SerializedName("v2GuideCheck2")
    var v2GuideCheck2: String = "",

    @SerializedName("v2GuideCheck3")
    var v2GuideCheck3: String = "",

    @SerializedName("v2GuideSecondTitle")
    var v2GuideSecondTitle: String = "",

    @SerializedName("v2GuideSecondDescription")
    var v2GuideSecondDescription: String = "",

    @SerializedName("v2GuideSecondCheck1")
    var v2GuideSecondCheck1: String = "",

    @SerializedName("v2GuideSecondCheck2")
    var v2GuideSecondCheck2: String = "",

    @SerializedName("v2GuideSecondCheck3")
    var v2GuideSecondCheck3: String = "",

): Parcelable