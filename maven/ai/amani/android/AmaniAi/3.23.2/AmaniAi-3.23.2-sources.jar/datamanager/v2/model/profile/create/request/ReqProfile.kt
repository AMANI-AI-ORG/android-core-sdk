package datamanager.v2.model.profile.create.request


import com.google.gson.annotations.SerializedName

data class ReqProfile(
    @SerializedName("email")
    val email: String?,
    @SerializedName("id_card_number")
    val idCardNumber: String?,
    @SerializedName("name")
    val name: String?,
    @SerializedName("phone")
    val phone: String?
)