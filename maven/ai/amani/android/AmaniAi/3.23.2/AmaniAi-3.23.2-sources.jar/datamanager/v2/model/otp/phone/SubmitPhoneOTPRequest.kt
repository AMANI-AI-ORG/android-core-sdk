package datamanager.v2.model.otp.phone


import com.google.gson.annotations.SerializedName

data class SubmitPhoneOTPRequest(
    @SerializedName("otp")
    val otp: String
)