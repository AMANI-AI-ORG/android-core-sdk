
package datamanager.model.login;

import com.google.gson.annotations.SerializedName;

@SuppressWarnings("unused")

public class ReqLogin {

    @SerializedName("email")
    private String mEmail;
    @SerializedName("password")
    private String mPassword;

    public String getEmail() {
        return mEmail;
    }

    public String getPassword() {
        return mPassword;
    }

    public static class Builder {

        private String mEmail;
        private String mPassword;

        public Builder withEmail(String email) {
            mEmail = email;
            return this;
        }

        public Builder withPassword(String password) {
            mPassword = password;
            return this;
        }

        public ReqLogin build() {
            ReqLogin reqLogin = new ReqLogin();
            reqLogin.mEmail = mEmail;
            reqLogin.mPassword = mPassword;
            return reqLogin;
        }

    }

}
