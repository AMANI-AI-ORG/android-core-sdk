package datamanager.model.upload.bio_login.response


import com.google.gson.annotations.SerializedName

data class ResBioLogin(
    @SerializedName("additional_data")
    val additionalData: AdditionalData?,
    @SerializedName("result")
    val result: Boolean?
)