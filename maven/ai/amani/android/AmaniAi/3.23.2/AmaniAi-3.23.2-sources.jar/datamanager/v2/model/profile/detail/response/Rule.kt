package datamanager.v2.model.profile.detail.response


import com.google.gson.annotations.SerializedName

data class Rule(
    @SerializedName("adapter")
    val adapter: String?,
    @SerializedName("attempt")
    val attempt: Int?,
    @SerializedName("document_classes")
    val documentClasses: List<String?>?,
    @SerializedName("errors")
    val errors: List<Error?>?,
    @SerializedName("id")
    val id: String?,
    @SerializedName("phase")
    val phase: Int?,
    @SerializedName("sort_order")
    val sortOrder: Int?,
    @SerializedName("status")
    val status: String?,
    @SerializedName("title")
    val title: String?,
    @SerializedName("identifier")
    val identifier: String = "",
    @SerializedName("document")
    val document: String? = null,
    @SerializedName("optional")
    val optional: Boolean? = null
)