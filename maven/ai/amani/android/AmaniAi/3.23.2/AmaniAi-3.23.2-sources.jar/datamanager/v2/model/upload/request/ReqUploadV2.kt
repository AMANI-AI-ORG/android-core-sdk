package datamanager.v2.model.upload.request


import com.google.gson.annotations.SerializedName
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File

data class ReqUploadV2(
    @SerializedName("check_mrz")
    var checkMrz: Boolean? = false,
    @SerializedName("cropped")
    var cropped: Boolean? = true,
    @SerializedName("type")
    var documentType: String? = "",
    @SerializedName("location")
    var location: Location? = null,
    @SerializedName("pages")
    var pages: List<String?>? = null,
    @SerializedName("original_pages")
    var originalPages: List<String?>? = null,
    @SerializedName("profile")
    var profile: String? = null,
    @SerializedName("rotated")
    var rotated: Boolean? = true,
    @SerializedName("stream")
    var stream: Boolean? = false,
    @SerializedName("upload_source")
    var uploadSource: String? = null,
    @SerializedName("device_data")
    var deviceData: DeviceData? = null,
    @SerializedName("nfc")
    var nfcData: NFCData? = null,
    @SerializedName("videos")
    var videos: ArrayList<Video>? = arrayListOf()
) {

    /** This step's attempt in the session, sent as the `attempt` form field when set. */
    internal var attempt: Int? = null

    fun asMultipartBodyPart(): RequestBody {
        val builder = MultipartBody.Builder().setType(MultipartBody.FORM)
        cropped?.let { builder.addFormDataPart("cropped", it.toString()) }
        rotated?.let { builder.addFormDataPart("rotated", it.toString()) }
        documentType?.let { builder.addFormDataPart("type", it) }
        uploadSource?.let { builder.addFormDataPart("upload_source", it.toString()) }
        pages?.let { pagesList ->
            pagesList.forEach { page ->
                builder.addFormDataPart("pages", page!!)
            }
        }
        originalPages?.let { originalPagesList ->
            originalPagesList.forEach { page ->
                builder.addFormDataPart("original_pages", page!!)
            }
        }
        videos?.let { videos ->
            videos.forEach { video ->
                val videoFile = File(video.path)
                builder.addFormDataPart(
                    "videos", video.name,
                    videoFile.asRequestBody("application/octet-stream".toMediaType())
                )
            }
        }
        nfcData?.let { builder.addFormDataPart("nfc", it.toJSON()) }
        deviceData?.let { builder.addFormDataPart("device_data", it.toJSON()) }
        location?.let { builder.addFormDataPart("location", it.toJSON()) }
        attempt?.let { builder.addFormDataPart("attempt", it.toString()) }
        return builder.build()
    }
}

