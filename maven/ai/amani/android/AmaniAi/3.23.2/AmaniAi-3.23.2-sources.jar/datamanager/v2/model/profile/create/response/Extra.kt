package datamanager.v2.model.profile.create.response


import com.google.gson.annotations.SerializedName

data class Extra(
    @SerializedName("nvi_data_formatted")
    val nviDataFormatted: Any?,
    @SerializedName("nvi_data_raw")
    val nviDataRaw: Any?,
    @SerializedName("parameters")
    val parameters: Any?,
    @SerializedName("stream")
    val stream: Any?
)