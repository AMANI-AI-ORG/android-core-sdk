package datamanager.model.customer;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Rule {

    @SerializedName("id")
    private Integer id;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("phase")
    @Expose
    private Integer phase;
    @SerializedName("document_classes")
    @Expose
    private List<String> documentClasses = null;
    @SerializedName("sort_order")
    @Expose
    private Integer sortOrder;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("attempt")
    @Expose
    private Integer attempt;
    private transient boolean showLoader;

    public boolean isShowLoader() {
        return showLoader;
    }

    public void setShowLoader(boolean showLoader) {
        this.showLoader = showLoader;
    }
    @SerializedName("errors")
    @Expose
    private List<Errors> errors = null;

    public String getStatus() {
        return status;
    }

    public Integer getId() {
        return id;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setId(Integer id) { this.id = id; }

    public String getTitle() { return title; }

    public void setTitle(String title) { this.title = title; }

    public Integer getPhase() { return phase; }

    public void setPhase(Integer phase) { this.phase = phase; }

    public List<String> getDocumentClasses() { return documentClasses; }

    public void setDocumentClasses(List<String> documentClasses) { this.documentClasses = documentClasses; }

    public void setSortOrder(Integer sortOrder) { this.sortOrder = sortOrder; }

    public void setStatus(String status) { this.status = status; }

    public Integer getAttempt() { return attempt; }

    public void setAttempt(Integer attempt) { this.attempt = attempt; }

    public List<Errors> getErrors() { return errors; }

    public void setErrors(List<Errors> errors) { this.errors = errors; }
}
