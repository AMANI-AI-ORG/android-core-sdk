package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

/**
 * Color overrides for the speech-verifier module, delivered inside
 * [Version.speechVerifierUiColors]. Values are ARGB/RGB hex strings (e.g. `"#FFFFFF"`).
 *
 * Example JSON:
 * ```json
 * "speechVerifierUiColors": {
 *   "speechTextColor": "#0F172A",
 *   "speechTextHighlightColor": "#4CC0A1",
 *   "micActiveColor": "#4CC0A1"
 * }
 * ```
 */
@Parcelize
data class SpeechVerifierUiColors(

    @SerializedName("overlayBackgroundColor")
    var overlayBackgroundColor: String = "",

    @SerializedName("scrimColor")
    var scrimColor: String = "",

    @SerializedName("speechTextColor")
    var speechTextColor: String = "",

    @SerializedName("speechTextHighlightColor")
    var speechTextHighlightColor: String = "",

    @SerializedName("instructionTextColor")
    var instructionTextColor: String = "",

    @SerializedName("statusTextColor")
    var statusTextColor: String = "",

    @SerializedName("micActiveColor")
    var micActiveColor: String = "",

    @SerializedName("micIdleColor")
    var micIdleColor: String = "",

    @SerializedName("resultSuccessColor")
    var resultSuccessColor: String = "",

    @SerializedName("resultErrorColor")
    var resultErrorColor: String = "",

    @SerializedName("failedTextColor")
    var failedTextColor: String = "",

    @SerializedName("retryButtonTextColor")
    var retryButtonTextColor: String = "",

    @SerializedName("retryButtonBackgroundColor")
    var retryButtonBackgroundColor: String = "",

) : Parcelable
