package datamanager.model.autocrop

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class AdditionalData(
    @SerializedName("mrz")
    @Expose
    var mrz: Mrz? = null
) : Parcelable