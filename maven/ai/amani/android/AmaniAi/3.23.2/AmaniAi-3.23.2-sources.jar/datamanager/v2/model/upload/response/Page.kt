package datamanager.v2.model.upload.response


import com.google.gson.annotations.SerializedName

data class Page(
    @SerializedName("document")
    val document: String?,
    @SerializedName("extraction_result")
    val extractionResult: Any?,
    @SerializedName("id")
    val id: String?,
    @SerializedName("mrz_info")
    val mrzInfo: Any?,
    @SerializedName("original_image")
    val originalImage: String?,
    @SerializedName("page")
    val page: Int?,
    @SerializedName("processed_image")
    val processedImage: Any?,
    @SerializedName("status")
    val status: Int?
)