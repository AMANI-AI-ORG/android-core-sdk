package datamanager.v2.model.upload.request


import ai.amani.base.util.JSONConvertable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class NFCData(
    @SerializedName("mrz")
    @Expose
    val mrz: String?,
    @SerializedName("photo")
    @Expose
    val photo: Photo?
):JSONConvertable