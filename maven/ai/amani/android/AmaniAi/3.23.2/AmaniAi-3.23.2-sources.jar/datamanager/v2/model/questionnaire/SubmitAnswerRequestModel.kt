package datamanager.v2.model.questionnaire


class SubmitAnswerRequestModel : ArrayList<SubmitAnswerRequestModelItem>()