package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

/**
 * On-screen prompt overrides for the identity questions, delivered inside
 * [Version.speechVerifierIdentityPrompts]. Each field backs one `IDENTITY_QUESTION` type.
 *
 * [instruction] is the small line shown ABOVE the question during the identity phase; the other
 * fields are the question text itself, one per `IDENTITY_QUESTION` type.
 *
 * Example JSON:
 * ```json
 * "speechVerifierIdentityPrompts": {
 *   "instruction": "Answer the question below out loud",
 *   "ID_NUMBER": "Say all the digits of your ID number, one by one",
 *   "MOTHER_NAME": "Say your mother's given name"
 * }
 * ```
 */
@Parcelize
data class SpeechVerifierIdentityPrompts(

    /**
     * Instruction line for the identity phase. Blank keeps the speech-verifier module default.
     * Note this is a SEPARATE line from `speechVerifierUiTexts.instruction`, which drives the
     * spoken-passphrase phase.
     */
    @SerializedName("instruction")
    var instruction: String = "",

    @SerializedName("ID_NUMBER")
    var idNumber: String = "",

    @SerializedName("MOTHER_NAME")
    var motherName: String = "",

    @SerializedName("FATHER_NAME")
    var fatherName: String = "",

    @SerializedName("DOCUMENT_NUMBER")
    var documentNumber: String = "",

) : Parcelable
