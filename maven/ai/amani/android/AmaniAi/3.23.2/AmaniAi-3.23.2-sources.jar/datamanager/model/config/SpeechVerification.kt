package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

/**
 * Speech-verification (`ST` document) configuration, delivered inside [Version.speechVerification].
 *
 * Drives the standalone amani-speech-verifier module: the ordered [steps] (spoken passphrases
 * and/or knowledge-based identity questions), the default similarity threshold, and the
 * word-exemption options.
 *
 * Threshold resolution (most specific wins):
 *  item threshold → step `matchThresholdPercent` → [defaultMatchThresholdPercent].
 *
 * Example JSON:
 * ```json
 * "speechVerification": {
 *   "defaultMatchThresholdPercent": 90,
 *   "autoDetectForeignWords": true,
 *   "detectTurkishNegation": true,
 *   "ignoreTurkishDiacritics": false,
 *   "exemptWords": ["Bybit"],
 *   "rejectWords": ["hayır", "reddediyorum", "iptal", "onaylamıyorum"],
 *   "steps": [
 *     { "type": "SPOKEN_TEXT", "texts": [ { "text": "Onaylıyorum" } ] }
 *   ]
 * }
 * ```
 */
@Parcelize
data class SpeechVerification(

    /** Similarity threshold (1..100) used when neither the step nor the item declares one. */
    @SerializedName("defaultMatchThresholdPercent")
    var defaultMatchThresholdPercent: Int = 100,

    /** When true, non-Turkish-looking words are auto-excluded from verification. */
    @SerializedName("autoDetectForeignWords")
    var autoDetectForeignWords: Boolean = true,

    /**
     * When true (default), an added Turkish negation ("onaylamıyorum" for "onaylıyorum") fails
     * the step regardless of similarity — a semantic inversion of the consent text.
     */
    @SerializedName("detectTurkishNegation")
    var detectTurkishNegation: Boolean = true,

    /** Words shown but excluded from verification (brand names, foreign terms). */
    @SerializedName("exemptWords")
    var exemptWords: List<String> = listOf(),

    /**
     * Words/phrases that FAIL the step on sight (extra negatives, "hayır", "iptal", …) —
     * complements [detectTurkishNegation] for forms the automatic guard doesn't cover.
     */
    @SerializedName("rejectWords")
    var rejectWords: List<String> = listOf(),

    /**
     * When true, Turkish letters are folded to ASCII (ş→s, ç→c, ğ→g, ı/İ→i, ö→o, ü→u, â/î/û→a/i/u)
     * on both the target and the transcription before matching. Off by default (strict Turkish).
     */
    @SerializedName("ignoreTurkishDiacritics")
    var ignoreTurkishDiacritics: Boolean = false,

    /** Ordered verification steps; the list order is the order the user experiences. */
    @SerializedName("steps")
    var steps: List<SpeechVerificationStep> = listOf(),

) : Parcelable
