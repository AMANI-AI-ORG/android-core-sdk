package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class ID(
    @SerializedName("id")
    val id: String? = null,

    @SerializedName("versions")
    val versions: List<Version>? = null
) : Parcelable
