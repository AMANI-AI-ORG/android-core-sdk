package datamanager.v2.model.auto_crop


import com.google.gson.annotations.SerializedName

data class ResAutoCropV2(
    @SerializedName("document")
    val document: String?,
    @SerializedName("status")
    val status: String?
)