package datamanager.model.customer;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class ResCreateCustomer {

    @SerializedName("id")
    @Expose
    public Integer id;
    @SerializedName("name")
    @Expose
    public String name;
    @SerializedName("phone")
    @Expose
    public String phone;
    @SerializedName("email")
    @Expose
    public String email;
    @SerializedName("token")
    @Expose
    public String token;
    @SerializedName("id_card_number")
    @Expose
    public String idCardNumber;
    @SerializedName("occupation")
    @Expose
    public Object occupation;
    @SerializedName("rules")
    private ArrayList<Rule> rules;
    @SerializedName("address")
    @Expose
    public Object address;
    @SerializedName("approval_expiration")
    @Expose
    public Object approvalExpiration;
    @SerializedName("missing_rules")
    @Expose
    public List<MissingRule> missingRules = null;
    @SerializedName("date_of_birth")
    @Expose
    public Object dateOfBirth;
    @SerializedName("status")
    @Expose
    public String status;
    @SerializedName("extra")
    @Expose
    public Extra extra;

    public ArrayList<Rule> getRules() {
        return rules;
    }

    public void setRules(ArrayList<Rule> rules) {
        this.rules = rules;
    }

    public Integer getId() {
        return id;
    }
}
