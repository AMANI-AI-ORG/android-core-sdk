package datamanager.model.documents


import com.google.gson.annotations.SerializedName

data class ResDocuments(
    @SerializedName("data")
    val documents: List<Document>
)

data class Document(
    @SerializedName("approved")
    val approved: Boolean?,
    @SerializedName("document_class")
    val documentClass: String,
    @SerializedName("document_type")
    val documentType: String,
    @SerializedName("document_type_string")
    val documentTypeString: String,
    @SerializedName("id")
    val id: Int,
    @SerializedName("in_process")
    val inProcess: Boolean,
    @SerializedName("passed")
    val passed: Boolean,
    @SerializedName("reject_reason")
    val rejectReason: String,
    @SerializedName("upload_source")
    val uploadSource: String
)