package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

/**
 * Remote configuration for the Pose Estimation v2 preparation screen.
 *
 * Delivered by the backend inside [Version.poseEstimationV2Preparation]. When present, the SDK
 * uses these values for the preparation screen shown before the 360° rotation liveness challenge
 * starts. Color values are ARGB/RGB hex strings (e.g. `"#FFFFFF"`, `"#4CC0A1"`).
 *
 * Example JSON:
 * ```json
 * "poseEstimationV2Preparation": {
 *   "message": "Follow the head movement shown in the video",
 *   "buttonText": "Start",
 *   "overlayColor": "#FFFFFFFF",
 *   "buttonTextColor": "#FFFFFFFF",
 *   "buttonBackgroundColor": "#4CC0A1"
 * }
 * ```
 */
@Parcelize
data class PoseEstimationV2Preparation(

    /** Instruction text shown below the circle during the preparation phase. */
    @SerializedName("message")
    var message: String = "Follow the head movement shown in the video",

    /** Text displayed on the start button. */
    @SerializedName("buttonText")
    var buttonText: String = "Start",

    /** Hex color (e.g. `"#FFFFFFFF"`) for the circle overlay background during preparation. */
    @SerializedName("overlayColor")
    var overlayColor: String = "#FFFFFFFF",

    /** Hex color (e.g. `"#FFFFFFFF"`) for the preparation button text. */
    @SerializedName("buttonTextColor")
    var buttonTextColor: String = "#FFFFFFFF",

    /** Hex color (e.g. `"#4CC0A1"`) for the preparation button background. */
    @SerializedName("buttonBackgroundColor")
    var buttonBackgroundColor: String = "#4CC0A1",

) : Parcelable
