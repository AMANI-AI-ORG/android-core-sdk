package datamanager.v2.model.socket.step


import com.google.gson.annotations.SerializedName
import com.google.gson.annotations.Expose

data class Errors(
    @SerializedName("error_code")
    @Expose
    val errorCode: Int?,
    @SerializedName("error_message")
    @Expose
    val errorMessage: Any?
)