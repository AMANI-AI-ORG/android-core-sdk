package datamanager.v2.model.profile.detail.response


import com.google.gson.annotations.SerializedName

data class ResProfileDetail(
    @SerializedName("address")
    val address: Any?, //
    @SerializedName("aml_last_check")
    val amlLastCheck: String?,
    @SerializedName("aml_status")
    val amlStatus: Boolean?,
    @SerializedName("approval_expiration")
    val approvalExpiration: Any?,
    @SerializedName("birthdate")
    val birthdate: String?,//
    @SerializedName("company_name")
    val companyName: String?,
    @SerializedName("created_at")
    val createdAt: String?,
    @SerializedName("email")
    val email: Any?, //
    @SerializedName("external_id")
    val externalId: Any?, //
    @SerializedName("extra")
    val extra: Extra?,
    @SerializedName("gender")
    val gender: Any?, //
    @SerializedName("has_nfc")
    val hasNfc: Boolean?,
    @SerializedName("id")
    val id: String?, //
    @SerializedName("id_card_number")
    val idCardNumber: String?, //
    @SerializedName("last_status_update")
    val lastStatusUpdate: String?,
    @SerializedName("missing_rules")
    val missingRules: List<MissingRule?>?,
    @SerializedName("name")
    val name: String?, //
    @SerializedName("nationality")
    val nationality: Any?, //
    @SerializedName("occupation")
    val occupation: Any?, //
    @SerializedName("phone")
    val phone: Any?, //
    @SerializedName("photo")
    val photo: String?, //
    @SerializedName("reject_reason")
    val rejectReason: Any?, //
    @SerializedName("risk")
    val risk: Any?, //
    @SerializedName("rules")
    val rules: List<Rule?>?, //
    @SerializedName("status")
    val status: String?, //
    @SerializedName("verification_steps")
    val verificationSteps: List<String?>?,
    @SerializedName("email_verified")
    val emailVerified: Boolean? = false,
    @SerializedName("phone_verified")
    val phoneVerified: Boolean? = false,
    @SerializedName("biopay_enabled")
    val bioMatchEnabled: Boolean? = null,
    @SerializedName("terms_accepted_at")
    val termsAcceptedAt: String? = null
)