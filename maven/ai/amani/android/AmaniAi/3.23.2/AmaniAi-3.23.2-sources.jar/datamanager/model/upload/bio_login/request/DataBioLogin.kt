package datamanager.model.upload.bio_login.request


import com.google.gson.annotations.SerializedName

data class DataBioLogin(
    @SerializedName("data")
    val data: String?,
    @SerializedName("type")
    val type: Int? = 4
)