package datamanager.v2.model.socket.mrz


import com.google.gson.annotations.SerializedName

data class Result(
    @SerializedName("confidence")
    val confidence: Int?,
    @SerializedName("h")
    val h: Int?,
    @SerializedName("letter_height")
    val letterHeight: Int?,
    @SerializedName("letter_spacing")
    val letterSpacing: Int?,
    @SerializedName("MRZBirthDate")
    val mRZBirthDate: String?,
    @SerializedName("MRZBirthDateCD")
    val mRZBirthDateCD: String?,
    @SerializedName("MRZCountryCode")
    val mRZCountryCode: String?,
    @SerializedName("MRZDocumentNumber")
    val mRZDocumentNumber: String?,
    @SerializedName("MRZDocumentNumberCD")
    val mRZDocumentNumberCD: String?,
    @SerializedName("MRZExpiryDate")
    val mRZExpiryDate: String?,
    @SerializedName("MRZExpiryDateCD")
    val mRZExpiryDateCD: String?,
    @SerializedName("MRZFirstName")
    val mRZFirstName: String?,
    @SerializedName("MRZFullName")
    val mRZFullName: String?,
    @SerializedName("MRZIDNumber")
    val mRZIDNumber: Any?,
    @SerializedName("MRZIDNumberCD")
    val mRZIDNumberCD: Any?,
    @SerializedName("MRZLastName")
    val mRZLastName: String?,
    @SerializedName("MRZNationality")
    val mRZNationality: String?,
    @SerializedName("MRZOptionalData")
    val mRZOptionalData: Any?,
    @SerializedName("MRZOverallCD")
    val mRZOverallCD: String?,
    @SerializedName("MRZSex")
    val mRZSex: String?,
    @SerializedName("MRZType")
    val mRZType: String?,
    @SerializedName("roi")
    val roi: Any?,
    @SerializedName("value")
    val value: String?,
    @SerializedName("w")
    val w: Int?,
    @SerializedName("x")
    val x: Int?,
    @SerializedName("y")
    val y: Int?
)