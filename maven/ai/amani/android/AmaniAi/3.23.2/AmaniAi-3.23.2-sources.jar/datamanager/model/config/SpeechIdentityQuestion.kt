package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

/**
 * One knowledge-based question in a [SpeechVerificationStep] of type `IDENTITY_QUESTION`. The
 * module picks one at random from the step's pool (among the types the customer profile can
 * back) per attempt.
 *
 * Example JSON:
 * ```json
 * { "type": "MOTHER_NAME", "matchThresholdPercent": 85 }
 * ```
 */
@Parcelize
data class SpeechIdentityQuestion(

    /**
     * Question type — one of: `ID_NUMBER`, `MOTHER_NAME`, `FATHER_NAME`, `DOCUMENT_NUMBER`.
     * Kept as a String so an unknown/new value never breaks config parsing.
     */
    @SerializedName("type")
    var type: String = "",

    /**
     * Similarity threshold (1..100) this question's spoken answer must reach. `null` falls back
     * to the step's `matchThresholdPercent`, then [SpeechVerification.defaultMatchThresholdPercent].
     */
    @SerializedName("matchThresholdPercent")
    var matchThresholdPercent: Int? = null,

    /**
     * Per-question delay (ms) kept recording after this question's answer matches so its last
     * digit/word is fully captured. `null` uses the module default.
     */
    @SerializedName("successCaptureDelayMs")
    var successCaptureDelayMs: Long? = null,

) : Parcelable
