package datamanager.v2.model.upload.request

import java.io.File

data class Video(
        val path: String = "",
        val name: String = ""
    )
{
    fun modifyFileNameAccordinglyExtension(): Video {
        val file = File(path)
        val extension = file.extension
        return Video(
            path = this.path,
            name = "$name.$extension"
        )
    }
}