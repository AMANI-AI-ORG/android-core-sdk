package datamanager.v2.model.socket.mrz


import com.google.gson.annotations.SerializedName

data class Message(
    @SerializedName("document")
    val document: String?,
    @SerializedName("page")
    val page: Any?,
    @SerializedName("profile")
    val profile: String?,
    @SerializedName("result")
    val result: Result?
)