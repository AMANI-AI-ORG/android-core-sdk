package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

/**
 * One spoken passphrase in a [SpeechVerificationStep] of type `SPOKEN_TEXT`. The module picks
 * one at random from the step's pool per attempt.
 *
 * Example JSON:
 * ```json
 * { "text": "Onaylıyorum", "matchThresholdPercent": 95 }
 * ```
 */
@Parcelize
data class SpeechSpokenText(

    /** The phrase shown on screen and verified. */
    @SerializedName("text")
    var text: String = "",

    /**
     * Whole-phrase similarity threshold (1..100) this phrase must reach. `null` falls back to
     * the step's `matchThresholdPercent`, then [SpeechVerification.defaultMatchThresholdPercent].
     */
    @SerializedName("matchThresholdPercent")
    var matchThresholdPercent: Int? = null,

    /**
     * Per-phrase delay (ms) kept recording after this phrase matches so its last word is fully
     * captured. `null` uses the module default.
     */
    @SerializedName("successCaptureDelayMs")
    var successCaptureDelayMs: Long? = null,

) : Parcelable
