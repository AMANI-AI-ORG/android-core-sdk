package datamanager.v2.model


import com.google.gson.annotations.SerializedName

data class ResSocketToken(
    @SerializedName("token")
    val socketToken: String?
)