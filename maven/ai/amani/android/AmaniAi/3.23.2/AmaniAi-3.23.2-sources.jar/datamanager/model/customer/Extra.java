package datamanager.model.customer;


public class Extra {


}
