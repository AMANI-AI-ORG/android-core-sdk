package datamanager.v2.model.socket.step.with_error


import com.google.gson.annotations.SerializedName
import com.google.gson.annotations.Expose

data class Message(
    @SerializedName("adapter")
    @Expose
    val adapter: String?,
    @SerializedName("attempt")
    @Expose
    val attempt: Int?,
    @SerializedName("company")
    @Expose
    val company: String?,
    @SerializedName("document_classes")
    @Expose
    val documentClasses: List<String?>?,
    @SerializedName("errors")
    @Expose
    val errors: List<Error?>?,
    @SerializedName("id")
    @Expose
    val id: String?,
    @SerializedName("phase")
    @Expose
    val phase: Int?,
    @SerializedName("sort_order")
    @Expose
    val sortOrder: Int?,
    @SerializedName("status")
    @Expose
    val status: String?,
    @SerializedName("title")
    @Expose
    val title: String?
)