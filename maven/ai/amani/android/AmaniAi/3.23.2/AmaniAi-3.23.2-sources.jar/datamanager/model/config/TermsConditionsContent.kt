package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class TermsConditionsContent(
    @SerializedName("title")
    val title: String?,

    @SerializedName("description")
    val description: String?,

    @SerializedName("acceptButtonText")
    val acceptButtonText: String?,

    @SerializedName("declineButtonText")
    val declineButtonText: String?
): Parcelable

