package datamanager.model.customer

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class CustomerNewInfo (
    @SerializedName("id")
    @Expose
    var id: Int? = null,

    @SerializedName("occupation")
    @Expose
    var occupation: String? = null,

    @SerializedName("address")
    @Expose
    var address: Address? = null,

    @SerializedName("email")
    @Expose
    var email: String? = null,

    @SerializedName("phone")
    @Expose
    var phone: String? = null,

    @SerializedName("birthdate")
    @Expose
    var birthdate: String? = null,

    @SerializedName("name")
    @Expose
    var name: String? = null,


)
