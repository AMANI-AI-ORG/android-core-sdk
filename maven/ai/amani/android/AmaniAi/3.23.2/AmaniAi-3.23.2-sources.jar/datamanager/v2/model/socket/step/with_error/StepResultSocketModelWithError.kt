package datamanager.v2.model.socket.step.with_error


import ai.amani.base.util.JSONConvertable
import com.google.gson.annotations.SerializedName
import com.google.gson.annotations.Expose

data class StepResultSocketModelWithError(
    @SerializedName("message")
    @Expose
    val message: List<Message?>?,
    @SerializedName("profile")
    @Expose
    val profile: String?,
    @SerializedName("type")
    @Expose
    val type: String?
): JSONConvertable