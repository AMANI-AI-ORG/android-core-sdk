package datamanager.model.autocrop;

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import datamanager.model.customer.Errors
import kotlinx.parcelize.Parcelize

@Parcelize
data class ResAutocrop(
    /**
     * for autocapture endpoint
     * */
    @SerializedName("image")
    @Expose
    var image: String? = null,

    @SerializedName("errors")
    @Expose
    var errors: List<Errors>? = null,

    @SerializedName("additional_data")
    @Expose
    var additionalData: AdditionalData? = null
) : Parcelable
