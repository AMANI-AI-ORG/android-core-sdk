package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class ButtonText(
    @SerializedName("APPROVED")
    val approved: String = "Approved",
    @SerializedName("AUTOMATICALLY_REJECTED")
    val automaticallyRejected: String = "Automatically rejected",
    @SerializedName("NOT_UPLOADED")
    val notUploaded: String? = "Not Uploaded",
    @SerializedName("PENDING_REVIEW")
    val pendingReview: String = "Pending Review",
    @SerializedName("PROCESSING")
    val processing: String = "Processing",
    @SerializedName("REJECTED")
    val rejected: String = "Rejected"
) : Parcelable