package datamanager.v2.model.socket.validation


import ai.amani.base.util.JSONConvertable
import com.google.gson.annotations.SerializedName

data class ValidationResultSocketModel(
    @SerializedName("message")
    val message: Message?,
    @SerializedName("profile")
    val profile: String?,
    @SerializedName("type")
    val type: String?
): JSONConvertable