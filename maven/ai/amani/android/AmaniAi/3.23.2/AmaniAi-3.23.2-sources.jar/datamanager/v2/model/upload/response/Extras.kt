package datamanager.v2.model.upload.response


import com.google.gson.annotations.SerializedName

data class Extras(
    @SerializedName("check_mrz")
    val checkMrz: Boolean?,
    @SerializedName("cropped")
    val cropped: Any?,
    @SerializedName("device_data")
    val deviceData: Any?,
    @SerializedName("ip")
    val ip: String?,
    @SerializedName("location")
    val location: Any?,
    @SerializedName("rotated")
    val rotated: Any?,
    @SerializedName("type_input")
    val typeInput: String?,
    @SerializedName("user_agent")
    val userAgent: String?
)