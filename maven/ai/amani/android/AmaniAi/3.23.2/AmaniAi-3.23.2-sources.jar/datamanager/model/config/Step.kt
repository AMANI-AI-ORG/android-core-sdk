package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Step(
    @SerializedName("captureDescription")
    var captureDescription: String = "",

    @SerializedName("captureTitle")
    var captureTitle: String = "",

    @SerializedName("confirmationDescription")
    var confirmationDescription: String = "",

    @SerializedName("confirmationTitle")
    var confirmationTitle: String = "",

    @SerializedName("nfcFailed")
    var nfcFailed: String = "",

    @SerializedName("nfcFailedDescription")
    var nfcFailedDescription: String = "",

    @SerializedName("nfcDescription")
    var nfcDescription: String = "",

    @SerializedName("uploadPdf")
    var uploadPdf: String = "",

    @SerializedName("clear")
    var clearText: String = "",

    @SerializedName("adress")
    var address: String = "",

    @SerializedName("continue")
    var continueText: String = "",

    @SerializedName("district")
    var district: String = "",

    @SerializedName("province")
    var province: String = "",

    @SerializedName("occupation")
    var occupation: String = "",

    @SerializedName("basicInfoText")
    var basicInfoText: String = "",

    @SerializedName("selectProvinceText")
    var selectProvinceText: String = "",

    @SerializedName("signatureMatchText")
    var signatureMatchText: String = "",

    @SerializedName("contractConfirmText")
    var contractConfirmText: String = "",

    @SerializedName("contractCheckBoxText")
    var contractCheckBoxText: String = "",

    @SerializedName("selectCountry")
    var selectCountry: String = "",

    @SerializedName("confirm")
    var confirm: String = "",

    @Transient
    var id: String = "",

    @Transient
    var crop: String = "",

    @Transient
    var stepId: Int = 0,

    @Transient
    var typeOfDoc: String = "",

    @SerializedName("aspectRatio")
    var aspectRatio: Double? = null,

    @SerializedName("androidAutoCaptureSettings")
    var androidAutoCaptureSettings: AndroidAutoCaptureSettings? = null

) : Parcelable