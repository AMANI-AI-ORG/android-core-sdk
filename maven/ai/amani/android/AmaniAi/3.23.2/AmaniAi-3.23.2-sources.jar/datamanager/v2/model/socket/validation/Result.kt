package datamanager.v2.model.socket.validation


import com.google.gson.annotations.SerializedName
import datamanager.model.customer.Errors

data class Result(
    @SerializedName("accepted_document")
    val acceptedDocument: String?,
    @SerializedName("document")
    val document: String?,
    @SerializedName("errors")
    val errors: List<Errors?>?,
    @SerializedName("status")
    val status: String?,
    @SerializedName("status_message")
    val statusMessage: Any?,
    @SerializedName("requested_type")
    val requestedType: String?
)