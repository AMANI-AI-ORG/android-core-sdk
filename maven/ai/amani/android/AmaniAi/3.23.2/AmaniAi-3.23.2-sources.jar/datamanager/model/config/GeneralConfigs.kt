package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

/**
 * The button colours fall back to this when the dashboard leaves them unset: fully transparent,
 * so an unconfigured button paints nothing instead of a brand colour the customer never chose.
 * Consumers read a fully transparent value as "not configured" and keep their own default.
 */
const val TRANSPARENT = "#00000000"

@Parcelize
data class GeneralConfigs(

    @SerializedName("appBackground")
    val appBackground: String = "#F5F5F5",

    @SerializedName("topBarBackground")
    val topBarBackground: String = "#FF8005E2",

    @SerializedName("errorIconColor")
    val errorIconColor: String = "#FF5C65",

    @SerializedName("successIconColor")
    val successIconColor: String = "#00FFD1",

    @SerializedName("primaryButtonTextColor")
    val primaryButtonTextColor: String = TRANSPARENT,

    @SerializedName("primaryButtonBorderColor")
    val primaryButtonBorderColor: String = TRANSPARENT,

    @SerializedName("secondaryButtonTextColor")
    val secondaryButtonTextColor: String = TRANSPARENT,

    @SerializedName("secondaryButtonBorderColor")
    val secondaryButtonBorderColor: String = TRANSPARENT,

    @SerializedName("primaryButtonBackgroundColor")
    var primaryButtonBackgroundColor: String = TRANSPARENT,

    @SerializedName("secondaryButtonBackgroundColor")
    val secondaryButtonBackgroundColor: String = TRANSPARENT,

    @SerializedName("language")
    val language: String = "en",

    @SerializedName("appFontColor")
    val appFontColor: String = "#1a1b1f",

    @SerializedName("topBarFontColor")
    val topBarFontColor: String = "#FFFFFF",

    @SerializedName("mainTitleText")
    val mainTitleText: String = "Complete The Steps",

    @SerializedName("tryAgainText")
    val tryAgainText: String = "Try Again",

    @SerializedName("confirmText")
    val confirmText: String = "Confirm",

    @SerializedName("cropManuallyText")
    val cropManuallyText: String = "Crop",

    @SerializedName("cropAndUploadText")
    val cropAndUploadText: String = "Crop and Upload",

    @SerializedName("hideLogo")
    val hideLogo: Boolean = true,

    // Completed Screen
    @SerializedName("successHeaderText")
    val successHeaderText: String = "Checking Documents, Thanks",

    @SerializedName("successInfo1Text")
    val successInfo1Text: String = "Congratulations, you have completed all the necessary steps.",

    @SerializedName("successInfo2Text")
    val successInfo2Text: String = "We are checking the documents, we will let you know within two working days at the latest.",

    @SerializedName("successTitle")
    val successTitle: String = "Steps Completed",

    @SerializedName("okText")
    val okText: String = "OK",

    @SerializedName("permissionDeniedText")
    val permissionDeniedText: String = "Permission denied.",

    @SerializedName("changePermissionText")
    val changePermissionText: String = "Please change permissions",

    @SerializedName("skipConfirmationScreen")
    val skipConfirmation: Boolean = false,

    @SerializedName("buttonRadiusAndroid")
    var buttonRadiusAndroid: Int = 20,

    @SerializedName("loaderColor")
    val loaderColor: String = "#FFFFFF",

    @SerializedName("continueText")
    val continueText: String = "Continue",

    @SerializedName("mainDescriptionText")
    val mainDescriptionText: String = "",

    @SerializedName("ttsVoices_android")
    val ttsVoices: String? = null,

    @SerializedName("isContinueVideoSDK")
    val isContinueVideoSDK: Boolean? = null,

    @SerializedName("terms_and_conditions")
    val termsAndConditions: TermsConditionsContent? = null,

    @SerializedName("show_terms_and_conditions")
    val showTermsAndConditions: Boolean = false,

    @SerializedName("termsConditionsURL")
    val termsConditionsURL: String? = null,

    // ----- V2 Home & Step Flow -----
    @SerializedName("v2HomeCtaStart")
    val v2HomeCtaStart: String = "Begin with",

    @SerializedName("v2HomeCtaRetake")
    val v2HomeCtaRetake: String = "Try again",

    @SerializedName("v2HomeCtaContinue")
    val v2HomeCtaContinue: String = "Resume with",

    @SerializedName("v2StepUpNextLabel")
    val v2StepUpNextLabel: String = "Next step",

    @SerializedName("v2StepStartHereLabel")
    val v2StepStartHereLabel: String = "Begin here",

    @SerializedName("v2HomeInitialTitle")
    val v2HomeInitialTitle: String = "Let's verify your identity",

    @SerializedName("v2HomeInitialSubtitle")
    val v2HomeInitialSubtitle: String = "quick steps. It takes around 2 minutes.",

    @SerializedName("v2HomeProgressTitle")
    val v2HomeProgressTitle: String = "You're almost there",

    @SerializedName("v2HomeProgressSubtitle")
    val v2HomeProgressSubtitle: String = "to complete your verification.",

    @SerializedName("v2HomeRejectedTitle")
    val v2HomeRejectedTitle: String = "Verification needs attention",

    @SerializedName("v2HomeRejectedSubtitle")
    val v2HomeRejectedSubtitle: String = "your review before we can proceed.",

    // ----- V2 shared guide texts -----
    @SerializedName("v2OpenCameraButtonText")
    val v2OpenCameraButtonText: String = "Open camera",

    @SerializedName("v2FrontSideText")
    val v2FrontSideText: String = "Front of ID",

    @SerializedName("v2BackSideText")
    val v2BackSideText: String = "Back of ID",

    @SerializedName("v2SelfieText")
    val v2SelfieText: String = "Selfie",

    // ----- V2 approved (success) screen -----
    /** Badge above the success title, e.g. "Approved instantly". */
    @SerializedName("v2ApprovedBadgeText")
    val v2ApprovedBadgeText: String = "Approved instantly",

    /** Title of the summary card on the success screen. */
    @SerializedName("v2ApprovedCardTitle")
    val v2ApprovedCardTitle: String = "All checks passed",

    // ----- V2 address verification -----
    /** Secondary action on the address step: upload a PDF instead of photographing. */
    @SerializedName("v2UploadPdfButtonText")
    val v2UploadPdfButtonText: String = "Upload PDF instead",

    // ----- V2 error copy -----
    /** Generic failure message for OTP / profile / upload calls that report no message. */
    @SerializedName("v2GenericErrorText")
    val v2GenericErrorText: String = "Something went wrong. Please try again.",

    /** Shown when the entered phone/email OTP code is rejected. */
    @SerializedName("v2InvalidOtpText")
    val v2InvalidOtpText: String = "The code is invalid. Please try again.",

    /** Shown when the profile-info step comes back rejected. */
    @SerializedName("v2StepRejectedText")
    val v2StepRejectedText: String = "This step is rejected.",

    /** Shown when the questionnaire questions cannot be fetched. */
    @SerializedName("v2QuestionnaireErrorText")
    val v2QuestionnaireErrorText: String = "Something went wrong!",

    /** Shown when the questionnaire answers cannot be submitted. */
    @SerializedName("v2QuestionnaireSubmitErrorText")
    val v2QuestionnaireSubmitErrorText: String =
        "Could not submit your answers. Please try again.",

    // ----- V2 home step states -----
    /**
     * Title of the generic rejection card, used when neither the server nor the step version
     * config (`v2StepRejectionTitle`) provided a per-step message.
     */
    @SerializedName("v2StepRejectionFallbackTitle")
    val v2StepRejectionFallbackTitle: String = "We couldn't verify this step",

    /** Description of the generic rejection card (see [v2StepRejectionFallbackTitle]). */
    @SerializedName("v2StepRejectionFallbackDescription")
    val v2StepRejectionFallbackDescription: String =
        "Something didn't look right. Please tap the step and try again.",

    /** Estimated duration shown on a step row when its version carries no `v2EstimatedTime`. */
    @SerializedName("v2StepDefaultDuration")
    val v2StepDefaultDuration: String = "~30 sec",

    /**
     * Text of the button that skips an optional step (a step result with `optional = true`).
     * Null when the dashboard does not set it; the UI then picks its own text.
     */
    @SerializedName("buttonTextOptionalSteps")
    val buttonTextOptionalSteps: String? = null

) : Parcelable