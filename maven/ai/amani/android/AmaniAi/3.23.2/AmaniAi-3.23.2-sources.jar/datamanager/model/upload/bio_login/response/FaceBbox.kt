package datamanager.model.upload.bio_login.response


import com.google.gson.annotations.SerializedName

data class FaceBbox(
    @SerializedName("x1")
    val x1: Int?,
    @SerializedName("x2")
    val x2: Int?,
    @SerializedName("y1")
    val y1: Int?,
    @SerializedName("y2")
    val y2: Int?
)