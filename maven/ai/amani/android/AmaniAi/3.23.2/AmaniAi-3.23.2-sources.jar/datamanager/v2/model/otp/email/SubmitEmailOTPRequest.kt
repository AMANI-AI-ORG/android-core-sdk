package datamanager.v2.model.otp.email


import com.google.gson.annotations.SerializedName

data class SubmitEmailOTPRequest(
    @SerializedName("otp")
    val otp: String
)