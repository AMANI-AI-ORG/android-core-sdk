package datamanager.v2.model.questionnaire


import com.google.gson.annotations.SerializedName

data class SubmitAnswerRequestModelItem(
    @SerializedName("multiple_option_answer")
    val multipleOptionAnswer: List<String>? = null,
    @SerializedName("question")
    val question: String? = null,
    @SerializedName("single_option_answer")
    val singleOptionAnswer: String? = null,
    @SerializedName("typed_answer")
    val typedAnswer: String? = null
)