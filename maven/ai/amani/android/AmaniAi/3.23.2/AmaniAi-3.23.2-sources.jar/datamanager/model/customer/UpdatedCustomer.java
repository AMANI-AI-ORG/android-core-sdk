package datamanager.model.customer;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class UpdatedCustomer {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("phone")
    @Expose
    private String phone;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("token")
    @Expose
    private String token;
    @SerializedName("id_card_number")
    @Expose
    private String idCardNumber;
    @SerializedName("occupation")
    @Expose
    private String occupation;
    @SerializedName("rules")
    @Expose
    private List<Rule> rules = null;
    @SerializedName("address")
    @Expose
    private Address address;
    @SerializedName("approval_expiration")
    @Expose
    private Object approvalExpiration;
    @SerializedName("missing_rules")
    @Expose
    private List<MissingRule> missingRules = null;
    @SerializedName("date_of_birth")
    @Expose
    private String dateOfBirth;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("extra")
    @Expose
    private Extra extra;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getIdCardNumber() {
        return idCardNumber;
    }

    public void setIdCardNumber(String idCardNumber) {
        this.idCardNumber = idCardNumber;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public List<Rule> getRules() {
        return rules;
    }

    public void setRules(List<Rule> rules) {
        this.rules = rules;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Object getApprovalExpiration() {
        return approvalExpiration;
    }

    public void setApprovalExpiration(Object approvalExpiration) {
        this.approvalExpiration = approvalExpiration;
    }

    public List<MissingRule> getMissingRules() {
        return missingRules;
    }

    public void setMissingRules(List<MissingRule> missingRules) {
        this.missingRules = missingRules;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Extra getExtra() {
        return extra;
    }

    public void setExtra(Extra extra) {
        this.extra = extra;
    }

}
