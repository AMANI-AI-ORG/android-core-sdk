package datamanager.model.login;

public class CustomerInfoModel {
    public int customerId;
    public int companyId;
    void init(int customerId, int companyId){
        this.companyId = companyId;
        this.customerId = customerId;
    }
}
