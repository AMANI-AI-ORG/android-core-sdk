package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

/**
 * On-camera text overrides for the speech-verifier module, delivered inside
 * [Version.speechVerifierUiTexts].
 *
 * Example JSON:
 * ```json
 * "speechVerifierUiTexts": {
 *   "instruction": "Read the highlighted text aloud",
 *   "listening": "Listening…",
 *   "verified": "Verified"
 * }
 * ```
 */
@Parcelize
data class SpeechVerifierUiTexts(

    @SerializedName("instruction")
    var instruction: String = "",

    @SerializedName("listening")
    var listening: String = "",

    @SerializedName("verifying")
    var verifying: String = "",

    @SerializedName("verified")
    var verified: String = "",

    @SerializedName("failed")
    var failed: String = "",

    @SerializedName("recognizerNotAvailable")
    var recognizerNotAvailable: String = "",

    @SerializedName("retry")
    var retry: String = "",

) : Parcelable
