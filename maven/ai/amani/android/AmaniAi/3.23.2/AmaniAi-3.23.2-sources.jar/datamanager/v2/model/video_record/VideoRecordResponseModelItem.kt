package datamanager.v2.model.video_record


import com.google.gson.annotations.SerializedName

