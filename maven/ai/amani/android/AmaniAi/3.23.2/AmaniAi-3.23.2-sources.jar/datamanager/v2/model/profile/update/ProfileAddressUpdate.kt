package datamanager.v2.model.profile.update


import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class ProfileAddressUpdate(
    @SerializedName("address")
    @Expose
    val address: Address? = null,

    @SerializedName("occupation")
    @Expose
    val occupation: String? = null,

    @SerializedName("email")
    @Expose
    val email: String? = null,

    @SerializedName("phone")
    @Expose
    val phone: String? = null,

    @SerializedName("birthdate")
    @Expose
    val birthdate: String? = null,

    @SerializedName("name")
    @Expose
    var name: String? = null,



)