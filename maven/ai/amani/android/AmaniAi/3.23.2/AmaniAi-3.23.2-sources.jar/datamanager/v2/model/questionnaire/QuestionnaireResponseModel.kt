package datamanager.v2.model.questionnaire


class QuestionnaireResponseModel : ArrayList<QuestionnarieResponseModelItem>()