package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

/**
 * One ordered step of the speech-verification flow (see [SpeechVerification.steps]). The list
 * order is the order the user experiences.
 *
 * The active fields depend on [type]:
 *  - `SPOKEN_TEXT`      → [texts] (a passphrase pool, one picked at random per attempt)
 *  - `IDENTITY_QUESTION`→ [questions] (a question pool, one picked at random per attempt)
 *
 * Example JSON:
 * ```json
 * { "type": "SPOKEN_TEXT", "matchThresholdPercent": 90,
 *   "texts": [ { "text": "Onaylıyorum", "matchThresholdPercent": 95 } ] }
 * ```
 */
@Parcelize
data class SpeechVerificationStep(

    /**
     * Step type — one of: `SPOKEN_TEXT`, `IDENTITY_QUESTION`. Kept as a String so an
     * unknown/new value never breaks config parsing.
     */
    @SerializedName("type")
    var type: String = "SPOKEN_TEXT",

    /**
     * Step-level similarity threshold (1..100), the fallback for items in this step that don't
     * declare their own. `null` falls back to [SpeechVerification.defaultMatchThresholdPercent].
     */
    @SerializedName("matchThresholdPercent")
    var matchThresholdPercent: Int? = null,

    /** Passphrase pool — used when [type] is `SPOKEN_TEXT`. */
    @SerializedName("texts")
    var texts: List<SpeechSpokenText> = listOf(),

    /** Question pool — used when [type] is `IDENTITY_QUESTION`. */
    @SerializedName("questions")
    var questions: List<SpeechIdentityQuestion> = listOf(),

) : Parcelable
