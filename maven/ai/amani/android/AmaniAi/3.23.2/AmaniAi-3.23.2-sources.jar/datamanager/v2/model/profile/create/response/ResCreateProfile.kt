package datamanager.v2.model.profile.create.response


import com.google.gson.annotations.SerializedName

data class ResCreateProfile(
    @SerializedName("access")
    val access: String?,
    @SerializedName("address")
    val address: Any?,
    @SerializedName("aml_last_check")
    val amlLastCheck: String?,
    @SerializedName("aml_status")
    val amlStatus: Boolean?,
    @SerializedName("approval_expiration")
    val approvalExpiration: Any?,
    @SerializedName("birthdate")
    val birthdate: String?,
    @SerializedName("company_name")
    val companyName: String?,
    @SerializedName("created_at")
    val createdAt: String?,
    @SerializedName("email")
    val email: Any?,
    @SerializedName("external_id")
    val externalId: Any?,
    @SerializedName("extra")
    val extra: Extra?,
    @SerializedName("gender")
    val gender: Any?,
    @SerializedName("has_nfc")
    val hasNfc: Boolean?,
    @SerializedName("id")
    val id: String?,
    @SerializedName("id_card_number")
    val idCardNumber: String?,
    @SerializedName("last_status_update")
    val lastStatusUpdate: String?,
    @SerializedName("missing_rules")
    val missingRules: List<MissingRule?>?,
    @SerializedName("name")
    val name: String?,
    @SerializedName("nationality")
    val nationality: Any?,
    @SerializedName("occupation")
    val occupation: Any?,
    @SerializedName("phone")
    val phone: Any?,
    @SerializedName("refresh")
    val refresh: String?,
    @SerializedName("reject_reason")
    val rejectReason: Any?,
    @SerializedName("risk")
    val risk: Int?,
    @SerializedName("rules")
    val rules: List<Rule?>?,
    @SerializedName("status")
    val status: String?,
    @SerializedName("verification_steps")
    val verificationSteps: List<String?>?
)