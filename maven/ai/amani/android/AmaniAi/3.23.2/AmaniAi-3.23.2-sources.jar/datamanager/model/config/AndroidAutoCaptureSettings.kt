package datamanager.model.config

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class AndroidAutoCaptureSettings(
    @SerializedName("autoCaptureThresholdV2")
    val autoCaptureThreshold: Double = 0.7,

    @SerializedName("hologramDetectionThreshold")
    val hologramDetectionThreshold: Double = 0.3,

    @SerializedName("aspectRatioTolerance")
    val aspectRatioTolerance: Double = 0.08,

    @SerializedName("sharpnessThreshold")
    val imageSharpnessThreshold: Int = 2600,

    @SerializedName("idCardOCRThreshold")
    val idCardOCRThreshold: Double = 0.22,

    @SerializedName("passportOCRThreshold")
    val passportOCRThreshold: Double = 0.2,

    @SerializedName("focusTimeOut")
    val cameraFocusTimeOut: Int? = null,

    @SerializedName("imageRegistrationEnabled")
    val imageRegistrationEnabled: Boolean = true,

    @SerializedName("imageRegistrationMediumLevel")
    val imageRegistrationMedium: Double = 0.5,

    @SerializedName("imageRegistrationHighLevel")
    val imageRegistrationHigh: Double = 0.5,

    @SerializedName("imageRegistrationMaxCapacityMedium")
    val imageRegistrationMaxCapacityMedium: Int = 2,

    @SerializedName("imageRegistrationMaxCapacityHigh")
    val imageRegistrationMaxCapacityHigh: Int = 2,

    @SerializedName("highPerfMaxMs")
    val highPerfMaxMs: Int = 150,

    @SerializedName("mediumPerfMaxMs")
    val mediumPerfMaxMs: Int = 410,

    @SerializedName("autoRotationEnabled")
    val autoRotationEnabled: Boolean = false,

    @SerializedName("imageSizeThreshold")
    val imageSizeThreshold: Double = 0.15
): Parcelable