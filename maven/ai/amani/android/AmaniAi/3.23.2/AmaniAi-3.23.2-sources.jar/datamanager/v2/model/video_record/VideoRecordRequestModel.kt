package datamanager.v2.model.video_record


import com.google.gson.annotations.SerializedName
import okhttp3.MultipartBody

data class VideoRecordRequestModel(
    @SerializedName("document_id")
    val documentID: String,
    @SerializedName("video_type")
    val videoType: String
)