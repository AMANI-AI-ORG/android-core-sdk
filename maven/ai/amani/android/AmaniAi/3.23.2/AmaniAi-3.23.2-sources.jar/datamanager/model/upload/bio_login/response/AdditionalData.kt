package datamanager.model.upload.bio_login.response


import com.google.gson.annotations.SerializedName

data class AdditionalData(
    @SerializedName("face_bbox")
    val faceBbox: FaceBbox?,
    @SerializedName("idface_bbox")
    val idfaceBbox: IdfaceBbox?,
    @SerializedName("match_confidence")
    val matchConfidence: Double?
)