package datamanager.v2.model.login


import com.google.gson.annotations.SerializedName

data class ResLoginV2(
    @SerializedName("access")
    val access: String?,
    @SerializedName("company_id")
    val companyId: String?,
    @SerializedName("first_name")
    val firstName: String?,
    @SerializedName("groups")
    val groups: List<Any?>?,
    @SerializedName("last_name")
    val lastName: String?,
    @SerializedName("refresh")
    val refresh: String?,
    @SerializedName("username")
    val username: String?
)