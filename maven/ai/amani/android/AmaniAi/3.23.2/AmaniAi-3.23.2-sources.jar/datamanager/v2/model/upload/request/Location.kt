package datamanager.v2.model.upload.request


import ai.amani.base.util.JSONConvertable
import com.google.gson.annotations.SerializedName

data class Location(
    @SerializedName("accuracy")
    val accuracy: String?,
    @SerializedName("altitude")
    val altitude: String?,
    @SerializedName("heading")
    val heading: String?,
    @SerializedName("latitude")
    val latitude: String?,
    @SerializedName("longitude")
    val longitude: String?,
    @SerializedName("speed")
    val speed: String?
):JSONConvertable