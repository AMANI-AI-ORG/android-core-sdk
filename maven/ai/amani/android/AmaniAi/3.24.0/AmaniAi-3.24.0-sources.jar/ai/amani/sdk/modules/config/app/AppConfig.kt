package ai.amani.sdk.modules.config.app

object AppConfig: IAppConfig {

    override fun getApplicationConfig(appConfigObserver: AppConfigObserver) =
        AppConfigImpl.getApplicationConfig(appConfigObserver)

    override fun fetchApplicationConfig(appConfigObserver: AppConfigObserver) =
        AppConfigImpl.fetchApplicationConfig(appConfigObserver)
}
