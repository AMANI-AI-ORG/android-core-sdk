package ai.amani.sdk.modules.config.country

object CountryList : ICountryList {

    override fun getCountryList(observer: CountryListObserver) = CountryListImpl.getCountryList(observer)
}
