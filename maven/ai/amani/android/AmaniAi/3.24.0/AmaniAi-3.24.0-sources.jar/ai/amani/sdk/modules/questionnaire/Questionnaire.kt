package ai.amani.sdk.modules.questionnaire

import ai.amani.sdk.model.questionnaire.QuestionnaireModel
import ai.amani.sdk.model.questionnaire.SubmitAnswer

object Questionnaire {

    fun getQuestions(
        onComplete: (QuestionnaireModel) -> Unit,
        onError: (error: Exception) -> Unit
    ) = QuestionnaireImpl.getQuestions(onComplete, onError)

    fun submitAnswers(
        submitAnswer: List<SubmitAnswer>,
        onComplete: () -> Unit,
        onError: (exception :Exception) -> Unit
    ) = QuestionnaireImpl.submitAnswers(submitAnswer, onComplete, onError)
}
