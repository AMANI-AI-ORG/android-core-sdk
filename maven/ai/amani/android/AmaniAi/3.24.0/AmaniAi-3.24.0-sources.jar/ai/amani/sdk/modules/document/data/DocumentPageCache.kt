package ai.amani.sdk.modules.document.data

import ai.amani.base.logger.local.AmaniLog
import ai.amani.base.logger.local.LogArea
import ai.amani.base.util.AppPreferenceKey
import ai.amani.base.util.SessionManager
import ai.amani.sdk.modules.document_capture.camera.BitmapUtils
import android.content.Context
import android.graphics.Bitmap
import java.io.File

/**
 * The pages of the last document capture: JPEG files in the app's files dir, and their paths in
 * [AppPreferenceKey.DOCUMENT_LIST] so the upload can find them after the capture screen is gone.
 *
 * File and preference I/O only; call the functions that touch files off the main thread.
 */
internal object DocumentPageCache {

    private const val FILE_NAME_PREFIX = "Document"

    /** Writes [page] as a JPEG; returns its path, or null when the write failed. */
    fun savePage(context: Context, page: Bitmap, pageNumber: Int): String? =
        BitmapUtils.saveBitmapAsFile(
            page,
            FILE_NAME_PREFIX + SessionManager.getCustomerId() + pageNumber,
            context
        )?.absolutePath

    /** Records [paths] as the current capture's pages, replacing the previous capture's. */
    fun storePages(paths: List<String>) {
        SessionManager.addListString(ArrayList(paths), AppPreferenceKey.DOCUMENT_LIST)
    }

    /** Paths of the current capture's pages, as recorded; the files may be gone. */
    fun storedPages(): List<String> =
        SessionManager.getListString(AppPreferenceKey.DOCUMENT_LIST).filter { it.isNotBlank() }

    /**
     * The stored pages as `data:image/jpeg;base64,...` strings, in capture order.
     *
     * @return null when no page is stored or any page's file is missing or unreadable (deleted
     * after an earlier upload, or by deleteAllDocumentCaches): a partial document is never sent.
     */
    fun encodeStoredPages(): List<String>? {
        val paths = storedPages()
        if (paths.isEmpty()) {
            AmaniLog.w(LogArea.DOCUMENT) { "document upload has no captured pages" }
            return null
        }
        val encoded = ArrayList<String>(paths.size)
        paths.forEachIndexed { index, path ->
            val bytes = try {
                File(path).takeIf { it.isFile }?.readBytes()
            } catch (e: Exception) {
                AmaniLog.w(LogArea.DOCUMENT, e) { "document upload page unreadable page=${index + 1}" }
                null
            } catch (e: OutOfMemoryError) {
                AmaniLog.w(LogArea.DOCUMENT, e) { "document upload page too large page=${index + 1}" }
                null
            }
            if (bytes == null || bytes.isEmpty()) {
                AmaniLog.w(LogArea.DOCUMENT) {
                    "document upload page missing page=${index + 1} of ${paths.size}"
                }
                return null
            }
            encoded.add(DATA_URI_PREFIX + BitmapUtils.byteArrayToBase64(bytes))
        }
        return encoded
    }

    /** Deletes the stored pages' files and forgets their paths. */
    fun clear() {
        val paths = storedPages()
        storePages(emptyList())
        clearFiles(paths)
    }

    /** Deletes [paths]; a missing file is not an error. */
    fun clearFiles(paths: List<String>) {
        var deleted = 0
        paths.forEach { path ->
            try {
                if (BitmapUtils.deleteImageFile(path)) deleted++
            } catch (e: Exception) {
                AmaniLog.w(LogArea.DOCUMENT, e) { "document cache file delete failed" }
            }
        }
        AmaniLog.d(LogArea.DOCUMENT) { "document cache cleared pages=${paths.size} deleted=$deleted" }
    }

    private const val DATA_URI_PREFIX = "data:image/jpeg;base64,"
}
