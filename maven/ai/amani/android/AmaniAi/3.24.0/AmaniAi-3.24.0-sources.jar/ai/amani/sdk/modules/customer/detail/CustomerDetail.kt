package ai.amani.sdk.modules.customer.detail

object CustomerDetail : ICustomerDetail {

    override fun getCustomerDetail(profileDetailObserver: CustomerDetailObserver) =
        CustomerDetailImpl.getCustomerDetail(profileDetailObserver)
}
