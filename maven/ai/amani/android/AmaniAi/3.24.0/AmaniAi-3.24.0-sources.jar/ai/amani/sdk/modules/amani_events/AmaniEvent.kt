package ai.amani.sdk.modules.amani_events

import ai.amani.sdk.interfaces.AmaniEventCallBack

object AmaniEvent : IAmaniEvent {

    const val STEP_RESULT_PARSE_ERROR = "STEP_RESULT_PARSE"

    @JvmStatic
    fun getEvent(): AmaniEventCallBack? = AmaniEventImpl.getEvent()

    override fun setListener(event: AmaniEventCallBack) = AmaniEventImpl.setListener(event)

    override fun removeListener() = AmaniEventImpl.removeListener()

}
