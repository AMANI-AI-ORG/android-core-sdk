package ai.amani.sdk.modules.selfie.pose_estimation

import ai.amani.base.annotiations.AmaniExperimental
import ai.amani.base.annotiations.Mandatory
import ai.amani.base.annotiations.NonMandatory
import ai.amani.base.view.BaseFragment
import ai.amani.sdk.interfaces.ExceptionCallBack
import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.modules.selfie.pose_estimation.SelfiePoseEstimation.upload
import ai.amani.sdk.modules.selfie.pose_estimation.observable.PoseEstimationObserver
import ai.amani.sdk.modules.selfie.pose_estimation.v2.model.PoseEstimationV2UiState
import android.app.Activity
import android.content.Context
import androidx.annotation.ColorRes
import androidx.annotation.DrawableRes
import androidx.annotation.RawRes

/**
 * Entry point for the Selfie Pose-Estimation liveness challenge.
 *
 * Choose the flow variant first — each entry point returns a typed builder that
 * only exposes the configuration options relevant to that variant:
 *
 * ```kotlin
 * // Default discrete-pose flow: LEFT / RIGHT / UP / DOWN
 * val fragment = SelfiePoseEstimation.Builder()
 *     .documentType("XXX_SE_0")
 *     .requestedPoseNumber(2)
 *     .userInterfaceColors(...)
 *     .userInterfaceTexts(...)
 *     .observe(myObserver)
 *     .build(context)
 *
 * // 360° continuous head-rotation flow with arc progress ring
 * val fragment = SelfiePoseEstimation.BuilderV2()
 *     .documentType("XXX_SE_0")
 *     .userInterfaceColors(...)   // v2-specific colour params only
 *     .userInterfaceTexts(...)    // v2-specific text params only
 *     .observe(myObserver)
 *     .build(context)
 * ```
 *
 * Call [upload] after a successful result to submit the captured selfie and optional video.
 *
 * @Author: zekiamani
 * @Date: 2.08.2022
 */
object SelfiePoseEstimation {

    /**
     * Returns a [V1Builder] for the classic discrete-pose flow (LEFT / RIGHT / UP / DOWN).
     * This is the default liveness variant — existing callers continue to work unchanged.
     */
    fun Builder(): V1Builder = V1Builder()

    /**
     * Returns a [V2Builder] for the continuous 360° head-rotation flow.
     *
     * Only exposes configuration relevant to the rotation challenge
     * (ring colours, rotation texts, face guide drawable). Discrete-pose options
     * such as [V1Builder.requestedPoseNumber] or [V1Builder.userInterfaceDrawables]
     * are intentionally absent to prevent confusion.
     */
    @AmaniExperimental
    fun BuilderV2(): V2Builder = V2Builder()

    /**
     * Uploads the selfie captured during the last completed session.
     * Call this from your [PoseEstimationObserver.onSuccess] handler.
     */
    fun upload(context: Activity, docType: String, callback: IUploadCallBack) =
        SelfiePoseEstimationImpl.upload(context, docType, callback)

    /**
     * Builder for the classic discrete-pose selfie liveness challenge.
     *
     * Returned by [SelfiePoseEstimation.Builder]. Only discrete-pose options
     * appear in IDE autocomplete — head-rotation settings are absent.
     */
    class V1Builder {

        private val impl = SelfiePoseEstimationImpl.V1BuilderImpl()

        @Mandatory
        fun documentType(documentType: String) = apply { impl.documentType(documentType) }

        /**
         * Sets all eight UI colours at once. If any parameter is null the whole call is ignored
         * and default colours are used.
         */
        @NonMandatory("Has default values")
        fun userInterfaceColors(
            ovalViewStartColor: Int?,
            ovalViewSuccessColor: Int?,
            ovalViewErrorColor: Int?,
            alertTitleFontColor: Int?,
            alertDescriptionFontColor: Int?,
            alertTryAgainFontColor: Int?,
            alertBackgroundFontColor: Int?,
            appFontColor: Int?
        ) = apply { impl.userInterfaceColors(ovalViewStartColor, ovalViewSuccessColor, ovalViewErrorColor, alertTitleFontColor, alertDescriptionFontColor, alertTryAgainFontColor, alertBackgroundFontColor, appFontColor) }

        /** Overrides any subset of the 13 instruction / alert texts. */
        @NonMandatory("Has default values")
        fun userInterfaceTexts(
            faceNotInside: String? = null,
            faceNotStraight: String? = null,
            faceIsTooFar: String? = null,
            holdPhoneVertically: String? = null,
            alertTitle: String? = null,
            alertDescription: String? = null,
            alertTryAgain: String? = null,
            turnLeft: String? = null,
            turnRight: String? = null,
            turnUp: String? = null,
            turnDown: String? = null,
            faceStraight: String? = null,
            keepEyesOpenAndFaceStraight: String? = null
        ) = apply { impl.userInterfaceTexts(faceNotInside, faceNotStraight, faceIsTooFar, holdPhoneVertically, alertTitle, alertDescription, alertTryAgain, turnLeft, turnRight, turnUp, turnDown, faceStraight, keepEyesOpenAndFaceStraight) }

        /** Overrides any of the nine guide drawables shown during the v1 pose flow. */
        @NonMandatory("Has default values")
        fun userInterfaceDrawables(
            @DrawableRes mainGuideLeft: Int? = null,
            @DrawableRes mainGuideRight: Int? = null,
            @DrawableRes mainGuideUp: Int? = null,
            @DrawableRes mainGuideDown: Int? = null,
            @DrawableRes mainGuideStraight: Int? = null,
            @DrawableRes secondaryGuideLeft: Int? = null,
            @DrawableRes secondaryGuideRight: Int? = null,
            @DrawableRes secondaryGuideUp: Int? = null,
            @DrawableRes secondaryGuideDown: Int? = null,
        ) = apply { impl.userInterfaceDrawables(mainGuideLeft, mainGuideRight, mainGuideUp, mainGuideDown, mainGuideStraight, secondaryGuideLeft, secondaryGuideRight, secondaryGuideUp, secondaryGuideDown) }

        @NonMandatory("Has default values as true")
        fun userInterfaceVisibilities(
            mainGuideVisibility: Boolean = true,
            secondaryGuideVisibility: Boolean = true
        ) = apply { impl.userInterfaceVisibilities(mainGuideVisibility, secondaryGuideVisibility) }

        /** Number of random poses to request (must be ≥ 1, default 2). */
        @Throws
        @NonMandatory("Has default value as 2")
        fun requestedPoseNumber(numberOfPose: Int = 2) = apply { impl.requestedPoseNumber(numberOfPose) }

        @NonMandatory("Has default value as 3000 milliseconds")
        fun ovalViewAnimationDurationMilSec(milSec: Int) = apply { impl.ovalViewAnimationDurationMilSec(milSec) }

        @NonMandatory("It has default value as false, in that case video will not be recorded")
        fun videoRecord(videoRecord: Boolean?) = apply { impl.videoRecord(videoRecord) }

        @Throws
        @Mandatory("Has no default value")
        fun observe(poseEstimationObserver: PoseEstimationObserver?) = apply { impl.observe(poseEstimationObserver) }

        fun onException(exception: ExceptionCallBack) = apply { impl.onException(exception) }

        /** Validates colours and returns the v1 fragment, or `null` on colour validation failure. */
        @Mandatory("To finalise the V1 builder")
        fun build(context: Context): BaseFragment? = impl.build(context)

    }

    /**
     * Builder for the continuous 360° head-rotation selfie liveness challenge.
     *
     * Returned by [SelfiePoseEstimation.HeadRotation]. Only rotation-specific options
     * appear in IDE autocomplete — discrete-pose settings are intentionally absent.
     */
    class V2Builder {

        private val impl = SelfiePoseEstimationImpl.V2BuilderImpl()

        @Mandatory
        fun documentType(documentType: String) = apply { impl.documentType(documentType) }

        /**
         * Sets the v2-specific UI colours.
         *
         * @param overlayBackgroundColor       Full-screen overlay colour surrounding the camera oval.
         * @param progressRingColor            Progress ring arc colour (both in-progress and completed segments).
         * @param progressRingTrackColor       Dim background ring track.
         * @param directionArrowColor          Spinning direction arrow inside the oval.
         * @param appFontColor                 Instruction text below the oval.
         * @param alertTitleFontColor          Retry alert dialog title text.
         * @param alertDescriptionFontColor    Retry alert dialog body text.
         * @param alertTryAgainFontColor       Retry alert dialog button text.
         * @param alertBackgroundColor         Retry alert dialog background.
         */
        @NonMandatory("Has default values")
        fun userInterfaceColors(
            overlayBackgroundColor: Int? = null,
            progressRingColor: Int? = null,
            progressRingTrackColor: Int? = null,
            directionArrowColor: Int? = null,
            appFontColor: Int? = null,
            alertTitleFontColor: Int? = null,
            alertDescriptionFontColor: Int? = null,
            alertTryAgainFontColor: Int? = null,
            alertBackgroundColor: Int? = null,
        ) = apply { impl.userInterfaceColors(overlayBackgroundColor, progressRingColor, progressRingTrackColor, directionArrowColor, appFontColor, alertTitleFontColor, alertDescriptionFontColor, alertTryAgainFontColor, alertBackgroundColor) }

        /**
         * Overrides any subset of the v2 instruction and alert texts.
         *
         * Only the texts actually displayed during the 360° rotation flow are included.
         * Texts irrelevant to v2 (e.g. turnUp / turnDown / keepEyesOpen) are intentionally absent.
         */
        @NonMandatory("Has default values")
        fun userInterfaceTexts(
            faceStraight: String? = null,
            turnLeft: String? = null,
            turnRight: String? = null,
            faceNotInside: String? = null,
            faceTooFar: String? = null,
            holdPhoneVertically: String? = null,
            keepRotating: String? = null,
            alertTitle: String? = null,
            alertDescription: String? = null,
            alertTryAgain: String? = null,
        ) = apply { impl.userInterfaceTexts(faceStraight, turnLeft, turnRight, faceNotInside, faceTooFar, holdPhoneVertically, keepRotating, alertTitle, alertDescription, alertTryAgain) }

        @NonMandatory("Has default value as 3000 milliseconds")
        fun ovalViewAnimationDurationMilSec(milSec: Int) = apply { impl.ovalViewAnimationDurationMilSec(milSec) }

        @NonMandatory("It has default value as false, in that case video will not be recorded")
        fun videoRecord(videoRecord: Boolean?) = apply { impl.videoRecord(videoRecord) }

        /**
         * Enables the preparation screen shown before the liveness process starts.
         *
         * The animation supplied through [preparationAnimation] loops inside the circle
         * while the progress ring around it sweeps 0→360°, both going the way the user will
         * be asked to rotate. A button at the bottom lets the user start the process when
         * ready. The [message] is displayed below the circle as an instruction.
         *
         * Omit this call to skip the preparation screen and start directly. **The screen
         * also needs an animation**: without `preparationAnimation(animation = …)` there is
         * nothing to demonstrate, so the flow goes straight to capture even if this method
         * was called.
         *
         * Use [preparationAnimation] to style the animation on this screen, and
         * [processingAnimation] for what the capture screen shows.
         *
         * ```kotlin
         * .showPreparationScreen(
         *     message               = "Watch and follow the head movement",
         *     buttonText            = "Start",
         *     buttonTextColor       = R.color.white,
         *     buttonBackgroundColor = R.color.approve_green,
         *     buttonRadiusDp        = 28f
         * )
         * ```
         *
         * @param message              Instruction text shown below the circle during preparation.
         * @param buttonText           Text displayed on the start button.
         * @param buttonTextColor      Color resource for the button text.
         * @param buttonBackgroundColor Color resource for the button background.
         * @param buttonRadiusDp       Corner radius of the button in dp.
         * @param overlayColor         Color resource for the circle overlay background during preparation.
         *                             Defaults to the main overlay color if not set.
         */
        @JvmOverloads
        @NonMandatory("Preparation screen is skipped if not set")
        fun showPreparationScreen(
            message: String = "Follow the head movement shown in the animation",
            buttonText: String = "Start",
            @ColorRes buttonTextColor: Int? = null,
            @ColorRes buttonBackgroundColor: Int? = null,
            buttonRadiusDp: Float = 28f,
            @ColorRes overlayColor: Int? = null
        ) = apply { impl.showPreparationScreen(message, buttonText, buttonTextColor, buttonBackgroundColor, buttonRadiusDp, overlayColor) }

        /**
         * Hex-string variant of [showPreparationScreen] for callers who prefer passing colors
         * as ARGB/RGB hex strings (e.g. `"#FFFFFF"`, `"#CC000000"`) instead of color resource IDs.
         *
         * Accepted formats — anything [android.graphics.Color.parseColor] supports:
         *  - `#RRGGBB`   (e.g. `"#34C759"`)
         *  - `#AARRGGBB` (e.g. `"#80000000"` for 50% black)
         *  - Named colors: `"red"`, `"blue"`, `"white"`, …
         *
         * ```kotlin
         * .showPreparationScreenWithHexColors(
         *     message               = "Watch and follow the head movement",
         *     buttonText            = "Start",
         *     buttonTextColor       = "#FFFFFF",
         *     buttonBackgroundColor = "#34C759",
         *     buttonRadiusDp        = 28f,
         *     overlayColor          = "#80000000"
         * )
         * ```
         *
         * @param message              Instruction text shown below the circle during preparation.
         * @param buttonText           Text displayed on the start button.
         * @param buttonTextColor      Hex color string for the button text (e.g. `"#FFFFFF"`).
         * @param buttonBackgroundColor Hex color string for the button background.
         * @param buttonRadiusDp       Corner radius of the button in dp.
         * @param overlayColor         Hex color string for the circle overlay background during preparation.
         *                             Defaults to the main overlay color if not set.
         *
         * @throws IllegalArgumentException if any hex color string cannot be parsed.
         */
        @JvmOverloads
        @NonMandatory("Preparation screen is skipped if not set")
        fun showPreparationScreenWithHexColors(
            message: String = "Follow the head movement shown in the animation",
            buttonText: String = "Start",
            buttonTextColor: String? = null,
            buttonBackgroundColor: String? = null,
            buttonRadiusDp: Float = 28f,
            overlayColor: String? = null
        ) = apply { impl.showPreparationScreenWithHexColors(message, buttonText, buttonTextColor, buttonBackgroundColor, buttonRadiusDp, overlayColor) }

        /**
         * Every setting of the **preparation screen** animation, in one call: which Lottie
         * file plays, the color of the disc behind the head and the overall opacity.
         *
         * This is the full-size animation shown before capture, above the confirm button
         * (see [showPreparationScreen]). What the processing screen shows is configured
         * separately, with [processingAnimation].
         *
         * The animation is **yours to supply** — the SDK ships no artwork for this screen.
         * Without an [animation] the preparation screen is skipped entirely.
         *
         * ```kotlin
         * .preparationAnimation(
         *     animation       = R.raw.my_head_circle,   // optional, Lottie JSON
         *     backgroundColor = R.color.white,
         *     opacity         = 0.9f
         * )
         * ```
         *
         * Pass [backgroundColor] as a hex string instead to use the string overload.
         *
         * ### Supplying your own animation
         *
         * [animation] must be a **Lottie JSON** raw resource — MP4 and other video formats
         * are not supported. Two expectations, both met by the built-in file:
         *
         *  - **two equal-length segments**, marked `clockwise` and `counterclockwise`, so
         *    the SDK can play the one matching the direction the user must rotate. Without
         *    markers the animation is split in half: first half clockwise, second half
         *    counter-clockwise.
         *  - **a transparent background** — the disc behind the head is drawn by the SDK and
         *    colored by [backgroundColor]; so is the progress ring, which takes its colors
         *    from [userInterfaceColors].
         *
         * @param animation       Lottie JSON raw resource. 0 = no preparation screen.
         * @param backgroundColor Color resource of the disc behind the head. 0 keeps black.
         * @param opacity         0f (fully transparent) to 1f (fully opaque).
         *
         * @throws IllegalArgumentException if [opacity] is outside `0f..1f`.
         */
        @JvmOverloads
        @NonMandatory("Preparation screen is skipped if no animation is set")
        fun preparationAnimation(
            @RawRes animation: Int = 0,
            @ColorRes backgroundColor: Int = 0,
            opacity: Float = 1f
        ) = apply { impl.preparationAnimation(animation, backgroundColor, opacity) }

        /**
         * Hex-color variant of [preparationAnimation], for callers who keep their palette as
         * strings rather than color resources. Everything else behaves identically.
         *
         * ```kotlin
         * .preparationAnimation(backgroundColor = "#FFFFFF", opacity = 0.9f)
         * ```
         *
         * Accepted formats — anything [android.graphics.Color.parseColor] supports:
         * `#RRGGBB`, `#AARRGGBB` (e.g. `"#80000000"` for 50 % black) and named colors.
         *
         * @param animation       Lottie JSON raw resource. 0 = no preparation screen.
         * @param backgroundColor Hex color of the disc behind the head.
         * @param opacity         0f (fully transparent) to 1f (fully opaque).
         *
         * @throws IllegalArgumentException if [opacity] is outside `0f..1f`, or if
         *         [backgroundColor] cannot be parsed.
         */
        @JvmOverloads
        @NonMandatory("Preparation screen is skipped if no animation is set")
        fun preparationAnimation(
            @RawRes animation: Int = 0,
            backgroundColor: String,
            opacity: Float = 1f
        ) = apply { impl.preparationAnimation(animation, backgroundColor, opacity) }

        /**
         * Every setting of what the **processing screen** draws in the centre of the camera
         * circle, in one call: the rotation hint animation, the icon shown while the user
         * holds their face straight, and the opacity both are drawn with.
         *
         * The hint plays for the whole rotation, scaled down over the camera feed, so it
         * carries no background of its own. [faceGuideDrawable] and the animation take turns
         * in the same spot, at the same size, and share [opacity].
         *
         * Both are **yours to supply** — the SDK ships no artwork. Each is optional and
         * degrades on its own: with no [animation] the overlay falls back to its built-in
         * spinning direction arrow, and with no [faceGuideDrawable] the "hold still" step
         * relies on the instruction text alone.
         *
         * ```kotlin
         * .processingAnimation(
         *     animation         = R.raw.my_head_circle,      // optional, Lottie JSON
         *     faceGuideDrawable = R.drawable.my_face_guide,  // optional, any drawable
         *     opacity           = 0.8f
         * )
         * ```
         *
         * [animation] has the same requirements as in [preparationAnimation]: a Lottie JSON
         * with `clockwise` / `counterclockwise` markers and a transparent background — the
         * camera feed has to stay visible underneath.
         *
         * @param animation         Lottie JSON raw resource. 0 = no centre hint; the overlay
         *                          draws its spinning direction arrow instead.
         * @param faceGuideDrawable Icon shown while the user holds still, before the rotation
         *                          starts. 0 = no icon.
         * @param opacity           0f (fully transparent) to 1f (fully opaque), applied to
         *                          both the hint animation and [faceGuideDrawable].
         *
         * @throws IllegalArgumentException if [opacity] is outside `0f..1f`.
         */
        @JvmOverloads
        @NonMandatory("Centre hint and face guide are skipped if not set")
        fun processingAnimation(
            @RawRes animation: Int = 0,
            @DrawableRes faceGuideDrawable: Int = 0,
            opacity: Float = 1f
        ) = apply { impl.processingAnimation(animation, faceGuideDrawable, opacity) }

        @Throws
        @Mandatory("Has no default value")
        fun observe(poseEstimationObserver: PoseEstimationObserver?) = apply { impl.observe(poseEstimationObserver) }

        fun onException(exception: ExceptionCallBack) = apply { impl.onException(exception) }

        /**
         * Registers a listener for high-level UI states of the v2 liveness flow:
         * [PoseEstimationV2UiState.PREPARATION_STARTED] when the preparation screen is shown,
         * [PoseEstimationV2UiState.PREPARATION_CONFIRMED] when the user taps its confirm button,
         * and [PoseEstimationV2UiState.CAPTURE_STARTED] when the camera opens and capture begins.
         *
         * Useful for analytics or driving your own UI around the flow. The listener is invoked on
         * the main thread. The preparation states are only emitted when a preparation screen is
         * configured via [showPreparationScreen]; otherwise the flow emits only CAPTURE_STARTED.
         */
        fun onUiStateChanged(listener: (PoseEstimationV2UiState) -> Unit) = apply { impl.onUiStateChanged(listener) }

        /** Validates colours and returns the v2 fragment, or `null` on colour validation failure. */
        @Mandatory("To finalise the V2 builder")
        fun build(context: Context): BaseFragment? = impl.build(context)

    }
}
