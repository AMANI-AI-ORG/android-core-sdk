package ai.amani.sdk.modules.nfc

import ai.amani.sdk.interfaces.INfcCallBack
import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.interfaces.NfcResultCallBack
import android.content.Context
import android.graphics.Bitmap
import android.nfc.Tag
import androidx.fragment.app.FragmentActivity

object NFC {

    /**
     * Unique ID for each session start to end
     */
    val operationID: String
        get() = NFCImpl.operationID

    fun start(
        tag: Tag,
        applicationContext: Context,
        birthDate: String,
        expireDate: String,
        documentNumber: String,
        callBack: INfcCallBack?
    ) = NFCImpl.start(tag, applicationContext, birthDate, expireDate, documentNumber, callBack)

    /** Please be sure that you are using this functions at scenarios which you have the MRZ field
     * of the image.Otherwise NFC will be failed.
     *
     * MRZ fields generally existing on the back side of the ID.
     *
     * @param tag : NFC Tag
     * @param applicationContext : Required context of activity
     * @param image : Back side of the document that contains MRZ field.
     * @param callBack
     */
    fun start(
        tag: Tag,
        applicationContext: Context,
        docType: String?,
        image: Bitmap?,
        callBack: INfcCallBack?
    ) = NFCImpl.start(tag, applicationContext, docType, image, callBack)

    fun start(
        tag: Tag,
        context: Context,
        birthDate: String,
        expireDate: String,
        documentNumber: String,
        callBack: NfcResultCallBack
    ) = NFCImpl.start(tag, context, birthDate, expireDate, documentNumber, callBack)

    fun upload(activity: FragmentActivity, docType: String, callBack: IUploadCallBack?) =
        NFCImpl.upload(activity, docType, callBack)
}
