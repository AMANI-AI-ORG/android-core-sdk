package ai.amani.sdk.modules.document

import ai.amani.R
import ai.amani.base.logger.local.AmaniLog
import ai.amani.base.logger.local.LogArea
import android.content.Context
import android.graphics.Color
import androidx.annotation.ColorRes
import androidx.core.content.ContextCompat

/*
 * Fallbacks for the public DocBuilder, whose fields are all nullable: a host (Java especially)
 * may pass null for any of them. The capture screen reads them through these instead of
 * asserting non-null. Extensions, not members: members of DocBuilder are kept public in the
 * release AAR by its keep rule.
 */

internal const val DEFAULT_TRY_AGAIN_TEXT = "Try Again"
internal const val DEFAULT_CONFIRM_TEXT = "Confirm"

@ColorRes
internal val DEFAULT_BUTTON_TEXT_COLOR: Int = R.color.white

/** Capture button colour when the builder sets none. */
@ColorRes
internal val DEFAULT_CAPTURE_BUTTON_COLOR: Int = R.color.white

/** Loader colour when the builder sets neither loaderColor nor a valid loaderColorHex. */
@ColorRes
internal val DEFAULT_LOADER_COLOR: Int = R.color.white

/** The builder used when the host passes none. */
internal fun defaultDocBuilder(): DocBuilder = DocBuilder(
    DEFAULT_TRY_AGAIN_TEXT,
    DEFAULT_CONFIRM_TEXT,
    DEFAULT_BUTTON_TEXT_COLOR,
    DEFAULT_BUTTON_TEXT_COLOR,
    DEFAULT_CAPTURE_BUTTON_COLOR,
    1
)

internal val DocBuilder.tryAgainTextOrDefault: String
    get() = tryAgainText?.takeIf { it.isNotBlank() } ?: DEFAULT_TRY_AGAIN_TEXT

internal val DocBuilder.confirmTextOrDefault: String
    get() = confirmText?.takeIf { it.isNotBlank() } ?: DEFAULT_CONFIRM_TEXT

@get:ColorRes
internal val DocBuilder.tryAgainTextColorOrDefault: Int
    get() = tryAgainTextColor ?: DEFAULT_BUTTON_TEXT_COLOR

@get:ColorRes
internal val DocBuilder.confirmTextColorOrDefault: Int
    get() = confirmTextColor ?: DEFAULT_BUTTON_TEXT_COLOR

/** Pages to capture; at least one. */
internal val DocBuilder.pageCountOrDefault: Int
    get() = (documentCount ?: 1).coerceAtLeast(1)

/**
 * The loader colour as a colour int: [DocBuilder.loaderColorHex] when it parses, else
 * [DocBuilder.loaderColor], else null (the screen then uses [DEFAULT_LOADER_COLOR]).
 */
internal fun DocBuilder.loaderColorOrNull(context: Context): Int? {
    loaderColorHex?.takeIf { it.isNotBlank() }?.let { hex ->
        try {
            return Color.parseColor(hex.trim())
        } catch (e: IllegalArgumentException) {
            AmaniLog.w(LogArea.DOCUMENT) { "document loader hex colour invalid, falling back" }
        }
    }
    return loaderColor?.let { res ->
        try {
            ContextCompat.getColor(context, res)
        } catch (e: Exception) {
            AmaniLog.w(LogArea.DOCUMENT, e) { "document loader colour not found, falling back" }
            null
        }
    }
}

@get:ColorRes
internal val DocBuilder.captureButtonColorOrDefault: Int
    get() = captureButtonColor ?: DEFAULT_CAPTURE_BUTTON_COLOR
