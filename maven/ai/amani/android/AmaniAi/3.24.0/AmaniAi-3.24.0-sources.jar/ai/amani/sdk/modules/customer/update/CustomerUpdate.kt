package ai.amani.sdk.modules.customer.update

import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.interfaces.PINCallback
import ai.amani.sdk.interfaces.TermsConditionsCallback

object CustomerUpdate : ICustomerInfo {

    override fun upload(callBack: IUploadCallBack) = CustomerUpdateImpl.upload(callBack)

    override fun sendEmailOTP(callBack: IUploadCallBack) = CustomerUpdateImpl.sendEmailOTP(callBack)

    override fun submitEmailOTP(otp: String, callBack: IUploadCallBack) = CustomerUpdateImpl.submitEmailOTP(otp, callBack)

    override fun sendPhoneOTP(callBack: IUploadCallBack) = CustomerUpdateImpl.sendPhoneOTP(callBack)

    override fun submitPhoneOTP(otp: String, callBack: IUploadCallBack) = CustomerUpdateImpl.submitPhoneOTP(otp, callBack)

    override fun enablePin(pin: String, callback: PINCallback) = CustomerUpdateImpl.enablePin(pin, callback)

    override fun disablePin(callback: PINCallback) = CustomerUpdateImpl.disablePin(callback)

    override fun acceptTermsConditions(
        callback: TermsConditionsCallback
    ) = CustomerUpdateImpl.acceptTermsConditions(callback)

    fun setInfo(
        occupation: String? = null,
        city: String? = null,
        province: String? = null,
        address: String? = null,
        email: String? = null,
        phoneNumber: String? = null,
        birthDate: String? = null,
        fullName: String? = null
    ) = CustomerUpdateImpl.setInfo(occupation, city, province, address, email, phoneNumber, birthDate, fullName)
}
