package ai.amani.sdk.modules.selfie.manual_capture

import ai.amani.sdk.interfaces.ExceptionCallBack
import ai.amani.sdk.interfaces.IFragmentCallBack
import ai.amani.sdk.interfaces.IUploadCallBack
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity

object Selfie {

    var callBackF: IFragmentCallBack?
        get() = SelfieImpl.callBackF
        set(value) { SelfieImpl.callBackF = value }

    var callBackU: IUploadCallBack?
        get() = SelfieImpl.callBackU
        set(value) { SelfieImpl.callBackU = value }

    fun start(docType: String, callBack: IFragmentCallBack?): Fragment? = SelfieImpl.start(docType, callBack)

    fun setTextPaddings(left: Int, top: Int = -999, right: Int) = apply { SelfieImpl.setTextPaddings(left, top, right) }

    fun onException(exception: ExceptionCallBack) = apply { SelfieImpl.onException(exception) }

    fun upload(activity: FragmentActivity, docType: String, callBack: IUploadCallBack?) =
        SelfieImpl.upload(activity, docType, callBack)
}
