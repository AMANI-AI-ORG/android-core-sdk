package ai.amani.sdk.modules.document
import android.os.Parcel
import android.os.Parcelable
import androidx.annotation.ColorRes
import com.google.gson.annotations.SerializedName

/**
 * Customisation of the document capture screen. Every field is optional; a null one keeps the
 * SDK default.
 *
 * @param loaderColor colour resource of the loader shown while a capture is processed and saved.
 * @param loaderColorHex loader colour as `#RRGGBB` or `#AARRGGBB`; wins over [loaderColor] when
 * valid. With neither, the loader is white.
 */
data class DocBuilder(
        @SerializedName("tryAgainText")
        val tryAgainText: String?,

        @SerializedName("confirmText")
        val confirmText: String?,

        @SerializedName("tryAgainTextColor")
        val tryAgainTextColor: Int?,

        @SerializedName("confirmTextColor")
        val confirmTextColor: Int?,

        @SerializedName("captureButtonColor")
        val captureButtonColor: Int?,

        @SerializedName("documentCount")
        val documentCount: Int?,

        @SerializedName("loaderColor")
        @ColorRes
        val loaderColor: Int?,

        @SerializedName("loaderColorHex")
        val loaderColorHex: String?)

    :Parcelable {

    /** The constructor before the loader colour; kept so existing hosts compile and link. */
    constructor(
            tryAgainText: String?,
            confirmText: String?,
            tryAgainTextColor: Int?,
            confirmTextColor: Int?,
            captureButtonColor: Int?,
            documentCount: Int?,
    ) : this(tryAgainText, confirmText, tryAgainTextColor, confirmTextColor, captureButtonColor, documentCount, null, null)

    constructor(parcel: Parcel) : this(
            parcel.readValue(Int::class.java.classLoader) as? String,
            parcel.readValue(Int::class.java.classLoader) as? String,
            parcel.readValue(Int::class.java.classLoader) as? Int,
            parcel.readValue(Int::class.java.classLoader) as? Int,
            parcel.readValue(Int::class.java.classLoader) as? Int,
            parcel.readValue(Int::class.java.classLoader) as? Int,
            parcel.readValue(Int::class.java.classLoader) as? Int,
            parcel.readValue(Int::class.java.classLoader) as? String,) {
    }


    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeValue(tryAgainText)
        parcel.writeValue(confirmText)
        parcel.writeValue(tryAgainTextColor)
        parcel.writeValue(confirmTextColor)
        parcel.writeValue(captureButtonColor)
        parcel.writeValue(documentCount)
        parcel.writeValue(loaderColor)
        parcel.writeValue(loaderColorHex)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object  CREATOR : Parcelable.Creator<DocBuilder> {
        override fun createFromParcel(parcel: Parcel): DocBuilder {
            return DocBuilder(parcel)
        }

        override fun newArray(size: Int): Array<DocBuilder?> {
            return arrayOfNulls(size)
        }
    }
}
