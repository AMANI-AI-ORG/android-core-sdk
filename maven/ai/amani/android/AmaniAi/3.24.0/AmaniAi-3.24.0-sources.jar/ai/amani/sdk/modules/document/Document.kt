package ai.amani.sdk.modules.document

import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.modules.document.interfaces.IDocumentCallBack
import android.widget.FrameLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity

object Document {

    /** Starter function that returns related vies as a Fragment into your frameLayout container.
     *  @param docType: DocumentType as String
     *  @param documentBuilder: It's for customization of the view.
     *  @param frameLayout: Container of the fragment that will return.
     *  @param callBack: Returns specific callback from IFragmentCallBack.
     */
    fun start(docType: String?, documentBuilder: DocBuilder?, frameLayout: FrameLayout, callBack: IDocumentCallBack?): Fragment? =
        DocumentImpl.start(docType, documentBuilder, frameLayout, callBack)

    /** Sets custom UI object.
     *  It must be called before start() function.
     */
    fun setCustomUI(tryAgainText: String, confirmText: String, tryAgainTextColor: Int, confirmTextColor: Int, captureButtonColor: Int, documentCount: Int) =
        DocumentImpl.setCustomUI(tryAgainText, confirmText, tryAgainTextColor, confirmTextColor, captureButtonColor, documentCount)

    /** Upload given data.
     *  @param data : ByteArray of an image/bitmap or file that fiven from HostApplication(CustomerApp).
     *  @param activity : Activity pointer
     *  @param docType: DocumentType as String
     *  @param callBack: Returns specific callback from IUploadCallBack.
     */
    fun upload(activity: FragmentActivity, docType: String, data: ArrayList<FileWithType>, callBack: IUploadCallBack) =
        DocumentImpl.upload(activity, docType, data, callBack)

    /** Uploads directly the data that taken from camera.
     *  This function has to be called after result of start function is properly done.
     */
    fun upload(activity: FragmentActivity,docType: String,callBack: IUploadCallBack) =
        DocumentImpl.upload(activity, docType, callBack)

    /** Optional Usage
     * This function delete all related files(list of all documents) that
     * taken and saved from camera. Also it must be called after the upload process done.
     */
    fun deleteAllDocumentCaches() = DocumentImpl.deleteAllDocumentCaches()
}
