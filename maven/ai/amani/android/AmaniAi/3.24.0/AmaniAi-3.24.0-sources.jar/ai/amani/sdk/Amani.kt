package ai.amani.sdk

import ai.amani.base.annotiations.AmaniRestricted
import ai.amani.base.utility.AmaniVersion
import ai.amani.sdk.Amani.configure
import ai.amani.sdk.Amani.init
import ai.amani.sdk.Amani.startSession
import ai.amani.sdk.interfaces.ILoginCallBack
import ai.amani.sdk.model.AmaniLogLevel
import ai.amani.sdk.model.exception.AmaniException
import ai.amani.sdk.modules.amani_events.AmaniEvent
import ai.amani.sdk.modules.bio_login.BioLogin
import ai.amani.sdk.modules.config.app.AppConfig
import ai.amani.sdk.modules.config.country.CountryList
import ai.amani.sdk.modules.customer.detail.CustomerDetail
import ai.amani.sdk.modules.customer.update.CustomerUpdate
import ai.amani.sdk.modules.document.Document
import ai.amani.sdk.modules.document_capture.IDCapture
import ai.amani.sdk.modules.nfc.NFC
import ai.amani.sdk.modules.questionnaire.Questionnaire
import ai.amani.sdk.modules.selfie.auto_capture.AutoSelfieCapture
import ai.amani.sdk.modules.selfie.manual_capture.Selfie
import ai.amani.sdk.modules.selfie.pose_estimation.SelfiePoseEstimation
import ai.amani.sdk.modules.signature.Signature
import ai.amani.sdk.modules.video_call.VideoCall
import android.app.Activity
import android.content.Context
import androidx.annotation.RawRes
import java.io.InputStream

object Amani {

    var VERSION: AmaniVersion
        get() = AmaniImpl.VERSION
        set(value) { AmaniImpl.VERSION = value }

    @JvmStatic
    fun sharedInstance(): Amani = AmaniImpl.sharedInstance()

    /**
     * ⚠️ Deprecated: Use [configure] instead.
     * Fully deprecated after +v4.
     *
     * ✅ Recommended Latest Configuration method:
     * ```kotlin
     * configure(
     *     context = yourContext,
     *     server = "https://yourserver.com",
     *     version = AmaniVersion.V2,
     *     sharedSecret = "optional",
     *     uploadSource = UploadSource.KYC,
     *     enabledFeatures = DynamicFeature.allFeatures
     * )
     * ```
     */
    @Deprecated(
        message = "Use configure() instead. Fully deprecated after +v4.",
        replaceWith = ReplaceWith(
            "configure(context, server, version, sharedSecret = null, uploadSource = null, " +
                    "enabledFeatures = DynamicFeature.allFeatures)"
        )
    )
    @JvmStatic
    fun init(
        context: Context,
        server: String? = null,
        version: AmaniVersion? = null,
    ) = AmaniImpl.init(context, server, version)

    /**
     * ⚠️ Deprecated: Use [configure] instead.
     * Fully deprecated after +v4.
     *
     * ✅ Recommended Latest Configuration method:
     * ```kotlin
     * configure(
     *     context = yourContext,
     *     server = "https://yourserver.com",
     *     version = AmaniVersion.V2,
     *     sharedSecret = "optional",
     *     uploadSource = UploadSource.KYC,
     *     enabledFeatures = DynamicFeature.allFeatures
     * )
     * ```
     */
    @Deprecated(
        message = "Use configure() instead. Fully deprecated after +v4.",
        replaceWith = ReplaceWith(
            "configure(context, server, version, sharedSecret = null, uploadSource = null," +
                    " enabledFeatures = DynamicFeature.allFeatures)"
        )
    )
    @JvmStatic
    fun init(
        context: Context,
        server: String? = null,
        version: AmaniVersion? = null,
        sharedSecret: String?
    ) = AmaniImpl.init(context, server, version, sharedSecret)

    /**
     * ⚠️ Deprecated: Use [configure] instead.
     * Fully deprecated after +v4.
     *
     * ✅ Recommended Latest Configuration method:
     * ```kotlin
     * configure(
     *     context = yourContext,
     *     server = "https://yourserver.com",
     *     version = AmaniVersion.V2,
     *     sharedSecret = "optional",
     *     uploadSource = UploadSource.KYC,
     *     enabledFeatures = DynamicFeature.allFeatures
     * )
     * ```
     */
    @Deprecated(
        message = "Use configure() instead. Fully deprecated after +v4.",
        replaceWith = ReplaceWith(
            "configure(context, server, version, sharedSecret = null, uploadSource = null," +
                    " enabledFeatures = DynamicFeature.allFeatures)"
        )
    )
    @JvmStatic
    fun init(
        context: Context,
        server: String? = null,
        version: AmaniVersion? = null,
        sharedSecret: String?,
        uploadSource: UploadSource? = null
    ) = AmaniImpl.init(context, server, version, sharedSecret, uploadSource)

    /**
     * ⚠️ Deprecated: Use [configure] instead.
     * Fully deprecated after +v4.
     *
     * ✅ Recommended Latest Configuration method:
     * ```kotlin
     * configure(
     *     context = yourContext,
     *     server = "https://yourserver.com",
     *     version = AmaniVersion.V2,
     *     sharedSecret = "optional",
     *     uploadSource = UploadSource.KYC,
     *     enabledFeatures = DynamicFeature.allFeatures
     * )
     * ```
     */
    @Deprecated(
        message = "Use configure() instead. Fully deprecated after +v4.",
        replaceWith = ReplaceWith(
            "configure(context, server, version, sharedSecret = null, uploadSource = null," +
                    " enabledFeatures = DynamicFeature.allFeatures)"
        )
    )
    @JvmStatic
    fun init(
        context: Context,
        server: String? = null,
        version: AmaniVersion? = null,
        sharedSecret: String? = null,
        uploadSource: UploadSource? = null,
        enabledFeatures: List<DynamicFeature> = DynamicFeature.allFeatures
    ) = AmaniImpl.init(context, server, version, sharedSecret, uploadSource, enabledFeatures)

    /**
     * ✅ Recommended Latest Configuration method
     *
     * Use this method to configure the SDK with all available options.
     * It replaces the deprecated [init] method and should be preferred
     * for all new integrations.
     *
     * Example usage:
     * ```kotlin
     * configure(
     *     context = yourContext,
     *     server = "https://yourserver.com",
     *     version = AmaniVersion.V2,
     *     sharedSecret = "optionalSharedSecret",
     *     uploadSource = UploadSource.KYC,
     *     enabledFeatures = DynamicFeature.allFeatures
     * )
     * ```
     *
     * This method allows you to configure:
     * - Server URL
     * - SDK version
     * - Optional shared secret
     * - Upload source
     * - Enabled dynamic features
     */
    @JvmStatic
    fun configure(
        context: Context,
        server: String? = null,
        version: AmaniVersion? = null,
        sharedSecret: String? = null,
        uploadSource: UploadSource? = null,
        enabledFeatures: List<DynamicFeature> = DynamicFeature.allFeatures
    ) = AmaniImpl.configure(context, server, version, sharedSecret, uploadSource, enabledFeatures)

    /**
     * Configures the SDK using local (bundled) TFLite model files from the APK's `assets/`
     * directory, **skipping all CDN downloads entirely**.
     *
     * Only the features configured via [DynamicFeatureLocal.Builder] are enabled.
     * No other features are activated or downloaded.
     *
     * Example:
     * ```kotlin
     * Amani.configureWithLocalFeatures(
     *     context = context,
     *     server = "https://yourserver.com",
     *     version = AmaniVersion.V2,
     *     sharedSecret = "optional",
     *     uploadSource = UploadSource.KYC,
     *     dynamicFeatureLocal = DynamicFeatureLocal.Builder()
     *         .idCaptureAsset("id_capture_asset.tflite")
     *         .hologramAsset("hologram_asset.tflite")
     *         .autoSelfieAssets(
     *             autoSelfieAsset1 = "selfie_asset_1.tflite",
     *             autoSelfieAsset2 = "selfie_asset_2.tflite",
     *             autoSelfieAsset3 = "selfie_asset_3.tflite"
     *         )
     *         .build()
     * )
     * ```
     *
     * @param dynamicFeatureLocal Asset file names grouped by feature via [DynamicFeatureLocal.Builder].
     */
    @AmaniRestricted
    @JvmStatic
    fun configureWithLocalFeatures(
        context: Context,
        server: String? = null,
        version: AmaniVersion? = null,
        sharedSecret: String? = null,
        uploadSource: UploadSource? = null,
        dynamicFeatureLocal: DynamicFeatureLocal
    ) = AmaniImpl.configureWithLocalFeatures(context, server, version, sharedSecret, uploadSource, dynamicFeatureLocal)

    @JvmStatic
    fun initBio(context: Context, server: String, sharedSecret: String?) = AmaniImpl.initBio(context, server, sharedSecret)

    @JvmStatic
    fun setUploadSource(uploadSource: UploadSource) = AmaniImpl.setUploadSource(uploadSource)

    @JvmStatic
    fun setUploadSource(uploadSource: String) = AmaniImpl.setUploadSource(uploadSource)

    fun getUploadSource(): String = AmaniImpl.getUploadSource()

    @JvmStatic
    @Throws(AmaniException::class)
    fun setSSLPinning(context: Context, @RawRes certificate: Int) = AmaniImpl.setSSLPinning(context, certificate)

    @JvmStatic
    @Throws(AmaniException::class)
    fun setSSLPinning(certificate: InputStream) = AmaniImpl.setSSLPinning(certificate)

    /**
     * ⚠️ Deprecated: Use [startSession] instead.
     * Fully deprecated after +v4.
     *
     */
    @Deprecated(
        message = "Use startSession() instead. Fully deprecated after +v4.",
        replaceWith = ReplaceWith("startSession(id, token, lang, birthDate, expireDate," +
                " documentNo, geoLocation, userFullName, userPhoneNumber, userEmail, callback)")
    )
    @JvmStatic
    fun initAmani(
        id: String,
        token: String,
        lang: String,
        callBack: ILoginCallBack
    ) = AmaniImpl.initAmani(id, token, lang, callBack)

    /**
     * ⚠️ Deprecated: Use [startSession] instead.
     * Fully deprecated after +v4.
     *
     */
    @Deprecated(
        message = "Use startSession() instead. Fully deprecated after +v4.",
        replaceWith = ReplaceWith("startSession(id, token, lang, birthDate, expireDate," +
                " documentNo, geoLocation, userFullName, userPhoneNumber, userEmail, callback)")
    )
    @JvmStatic
    fun initAmani(
        activity: Activity?,
        id: String,
        token: String,
        lang: String,
        birthDate: String? = null,
        expireDate: String? = null,
        documentNo: String? = null,
        geoLocation: Boolean = true,
        userFullName: String? = null,
        userPhoneNumber: String? = null,
        userEmail: String? = null,
        callback: ILoginCallBack
        ) = AmaniImpl.initAmani(activity, id, token, lang, birthDate, expireDate, documentNo, geoLocation, userFullName, userPhoneNumber, userEmail, callback)

    /**
     * ✅ Recommended Latest token-based Session Starter
     */
    @JvmStatic
    fun startSession(
        id: String,
        token: String,
        lang: String,
        birthDate: String? = null,
        expireDate: String? = null,
        documentNo: String? = null,
        geoLocation: Boolean = true,
        userFullName: String? = null,
        userPhoneNumber: String? = null,
        userEmail: String? = null,
        callback: ILoginCallBack
    ) = AmaniImpl.startSession(id, token, lang, birthDate, expireDate, documentNo, geoLocation, userFullName, userPhoneNumber, userEmail, callback)

    /**
     * 🚫 Fully Deprecated: Password-based login
     */
    @JvmStatic
    @Deprecated(
        message = "Password-based login is deprecated. Use token-based initAmani() instead.",
        replaceWith = ReplaceWith(
            "initAmani(activity, id, token, birthDate, expireDate, documentNo, " +
                    "geoLocation, lang, userFullName, userPhoneNumber, userEmail, callback)",
        )
    )
    fun initAmaniWithPassword(
        activity: Activity,
        id: String?,
        email: String?,
        password: String?,
        lang: String,
        callback: ILoginCallBack,
        birthDate: String? = null,
        expireDate: String? = null,
        documentNo: String? = null,
        geoLocation: Boolean = true,
        userFullName: String? = null,
        userPhoneNumber: String? = null,
        userEmail: String? = null
    ) = AmaniImpl.initAmaniWithPassword(activity, id, email, password, lang, callback, birthDate, expireDate, documentNo, geoLocation, userFullName, userPhoneNumber, userEmail)

    /**
     * Sets how much the SDK writes to logcat (tag `AmaniCoreSDK`, each line prefixed with its area
     * such as `[Upload]`). Without a call the SDK follows the host app's build:
     * [AmaniLogLevel.DEBUG] in a debuggable app, [AmaniLogLevel.ESSENTIAL] in a release app.
     * May be called at any time, before or after [configure], and from any thread.
     *
     * Personal data, credentials and document data are never written, at any level: they show as
     * `[hidden]`, in a debuggable app too.
     *
     * ```kotlin
     * Amani.setLogLevel(AmaniLogLevel.NONE) // silence the SDK in logcat
     * ```
     * ```java
     * Amani.setLogLevel(AmaniLogLevel.DEBUG); // details in a release build, e.g. for a support session
     * ```
     */
    @JvmStatic
    fun setLogLevel(level: AmaniLogLevel) = AmaniImpl.setLogLevel(level)

    @JvmStatic
    fun finishSession() = AmaniImpl.finishSession()

    @AmaniRestricted
    fun setUISDKVersion(version: String) = apply { AmaniImpl.setUISDKVersion(version) }

    @JvmStatic
    fun IDCapture(): IDCapture = AmaniImpl.IDCapture()

    @JvmStatic
    fun Selfie(): Selfie = AmaniImpl.Selfie()

    @JvmStatic
    fun ScanNFC(): NFC = AmaniImpl.ScanNFC()

    @JvmStatic
    fun BioLogin(): BioLogin = AmaniImpl.BioLogin()

    @JvmStatic
    fun AutoSelfieCapture(): AutoSelfieCapture = AmaniImpl.AutoSelfieCapture()

    @JvmStatic
    fun Document(): Document = AmaniImpl.Document()

    @JvmStatic
    fun CustomerInfo(): CustomerUpdate = AmaniImpl.CustomerInfo()

    @JvmStatic
    fun Signature(): Signature = AmaniImpl.Signature()

    @JvmStatic
    fun VideoCall(): VideoCall = AmaniImpl.VideoCall()

    @JvmStatic
    fun CustomerDetail(): CustomerDetail = AmaniImpl.CustomerDetail()

    @JvmStatic
    fun AppConfig(): AppConfig = AmaniImpl.AppConfig()

    @JvmStatic
    fun SelfiePoseEstimation(): SelfiePoseEstimation = AmaniImpl.SelfiePoseEstimation()

    @JvmStatic
    fun CountryList(): CountryList = AmaniImpl.CountryList()

    @JvmStatic
    fun AmaniEvent(): AmaniEvent = AmaniImpl.AmaniEvent()

    @JvmStatic
    fun Questionnaire(): Questionnaire = AmaniImpl.Questionnaire()


    /**
     * Unique ID for each session start to end
     */
    val operationID: String
        get() = AmaniImpl.operationID
}
