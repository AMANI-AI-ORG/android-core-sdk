package ai.amani.sdk.modules.document.data

import ai.amani.base.logger.local.AmaniLog
import ai.amani.base.logger.local.LogArea
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlin.coroutines.CoroutineContext

/**
 * Background work of the document module that outlives the capture screen: page encoding for the
 * upload and deleting uploaded pages. A failed job is logged and does not cancel the others or
 * crash the host.
 */
internal object DocumentScope : CoroutineScope {
    override val coroutineContext: CoroutineContext =
        SupervisorJob() + Dispatchers.IO + CoroutineExceptionHandler { _, e ->
            AmaniLog.e(LogArea.DOCUMENT, e) { "document background job failed" }
        }
}
