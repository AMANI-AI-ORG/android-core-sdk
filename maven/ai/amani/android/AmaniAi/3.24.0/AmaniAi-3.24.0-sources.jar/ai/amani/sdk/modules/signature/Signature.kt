package ai.amani.sdk.modules.signature

import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.modules.signature.interfaces.ISignature
import ai.amani.sdk.modules.signature.interfaces.ISignatureStartCallBack
import android.content.Context
import androidx.fragment.app.Fragment

class Signature: ISignature {

    private val impl = SignatureImpl()

    /**
     * Unique ID for each session start to end
     */
    val operationID: String
        get() = impl.operationID

    companion object {
        @Volatile
        private var mSignature: Signature? = null

        @JvmStatic
        @Synchronized
        fun sharedInstance(): Signature {
            if (mSignature == null) {
                synchronized(Signature){
                    mSignature = Signature()
                }
            }
            return mSignature!!
        }
    }

    /** @return: SignatureFragment
     *  @param numberOfSignatures       : Number of signature that will be taken.
     *  @param iSignatureStart          : A callback that returns with 2 parameter (bitmap , countOfSignatures:)
     */
    override fun start(context:Context, numberOfSignatures: Int, iSignatureStart: ISignatureStartCallBack): Fragment =
        impl.start(context, numberOfSignatures, iSignatureStart)

    /** Upload function after requested Signatures are saved successfully.
     *  @param uploadCallBack           : A callback that returns 3 parameter of upload result (isSuccess, result, errors).
     */
    override fun upload( uploadCallBack: IUploadCallBack) = impl.upload(uploadCallBack)

    /** Provides to clean canvas view of the Signature from SignatureFragment.
     */
    override fun clean() = impl.clean()

    /** Provides to save ByteArray of Signature as File,
     *  to clean Signature from canvas if it's NOT last signature.
     */
    override fun confirm(context: Context) = impl.confirm(context)

    /** reset the count of signature
     */
    override fun resetCountOfSignature() = impl.resetCountOfSignature()
}
