package ai.amani.sdk.modules.document.view

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Rect
import androidx.camera.core.ImageProxy

/**
 * Converts the still with CameraX's own [ImageProxy.toBitmap], which applies neither the
 * crop rect nor the rotation, then in one pass:
 *  - keeps only the frame the preview shows: the view port's crop rect, center-cropped to
 *    the preview's aspect ratio (what `fillCenter` displays) in case no view port was set;
 *  - rotates it upright by `imageInfo.rotationDegrees`, the EXIF orientation of the JPEG.
 */
internal fun ImageProxy.toPreviewFramedBitmap(previewWidth: Int, previewHeight: Int): Bitmap {
    val source = toBitmap()
    val rotation = imageInfo.rotationDegrees

    val frame = Rect(0, 0, source.width, source.height)
    frame.intersect(cropRect)

    if (previewWidth > 0 && previewHeight > 0) {
        val quarterTurn = rotation % 180 != 0
        val targetWidth = if (quarterTurn) previewHeight else previewWidth
        val targetHeight = if (quarterTurn) previewWidth else previewHeight
        if (frame.width().toLong() * targetHeight > frame.height().toLong() * targetWidth) {
            val width = (frame.height().toLong() * targetWidth / targetHeight).toInt().coerceAtLeast(1)
            frame.inset((frame.width() - width) / 2, 0)
        } else {
            val height = (frame.width().toLong() * targetHeight / targetWidth).toInt().coerceAtLeast(1)
            frame.inset(0, (frame.height() - height) / 2)
        }
    }

    val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
    val result = Bitmap.createBitmap(
        source, frame.left, frame.top, frame.width(), frame.height(), matrix, true
    )
    if (result !== source) source.recycle()
    return result
}
