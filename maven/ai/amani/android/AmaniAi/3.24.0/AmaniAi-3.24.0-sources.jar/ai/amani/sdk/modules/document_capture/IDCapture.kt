package ai.amani.sdk.modules.document_capture

import ai.amani.sdk.interfaces.ExceptionCallBack
import ai.amani.sdk.interfaces.IFragmentCallBack
import ai.amani.sdk.interfaces.IUploadCallBack
import ai.amani.sdk.model.amani_events.error.AmaniError
import ai.amani.sdk.model.mrz.MRZResult
import android.widget.FrameLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity

object IDCapture : IDCaptureI {

    /** Default capture-area scale (full-size rectangle, original behaviour). */
    const val DEFAULT_CAPTURE_AREA_SCALE = 1.0f

    /** Smallest capture-area scale accepted by [setCaptureAreaScaleFactor]. */
    const val MIN_CAPTURE_AREA_SCALE = 0.75f

    /** Largest capture-area scale accepted by [setCaptureAreaScaleFactor]. */
    const val MAX_CAPTURE_AREA_SCALE = 1.0f

    /**
     * Unique ID for each session start to end
     */
    val operationID: String
        get() = IDCaptureImpl.operationID

    /**
     * This function must be called before the start() function.
     * Default timeOut: 15 seconds, if you are not calling this func.
     * @param timeOut The time required seconds for the Manual Crop button to activate.
     */
    fun setManualCropTimeOut(timeOut: Int) = IDCaptureImpl.setManualCropTimeOut(timeOut)

    /**
     * This function must be called before the start() function.
     * Default value is false.
     * @param withNFC : Represents process withNFC or withOutNFC
     */
    fun withNFC(withNFC: Boolean = false) = IDCaptureImpl.withNFC(withNFC)

    fun hologramDetection(hologramDetection: Boolean = false) = IDCaptureImpl.hologramDetection(hologramDetection)

    fun videoRecord(videoRecord: Boolean = false) = IDCaptureImpl.videoRecord(videoRecord)

    fun setIsMRZReaderEnabled(enable: Boolean = true) = IDCaptureImpl.setIsMRZReaderEnabled(enable)

    /**
     * Configures the size of the on-screen ID/document capture guide rectangle
     * relative to its default (full) size. Must be called before [start].
     *
     * The factor uniformly scales the rectangle's width and height, so its aspect
     * ratio — and the position of the face/chip guide icons drawn inside it — stay
     * correct. So that a smaller rectangle (which invites the user to hold the
     * document a little farther from the camera) doesn't start failing the
     * auto-capture minimum-area check, that size threshold is relaxed by the same
     * factor.
     *
     * When this function is never called the default is [DEFAULT_CAPTURE_AREA_SCALE]
     * (1.0f) and the capture screen behaves exactly as before.
     *
     * @param factor Desired scale in the range
     * [[MIN_CAPTURE_AREA_SCALE], [MAX_CAPTURE_AREA_SCALE]] where 1.0f = default
     * full-size rectangle. Out-of-range values are coerced into the range (and
     * logged); non-positive values are ignored and the previous value is kept.
     */
    fun setCaptureAreaScaleFactor(factor: Float) = apply { IDCaptureImpl.setCaptureAreaScaleFactor(factor) }

    override fun start(
        activity: FragmentActivity,
        frameLayout: FrameLayout,
        docType: String,
        frontSide: Boolean,
        callBack: IFragmentCallBack,
    ): Fragment? = IDCaptureImpl.start(activity, frameLayout, docType, frontSide, callBack)

    /** Must be only called after Back Side of ID which includes MRZ field is captured correctly
     *
     * @param type : Document type
     * @param onComplete: Unit callback during success cases
     * @param onError: Unit callback during errors
     */
    @Synchronized
    fun getMRZ(
        type: String,
        onComplete: (mrz: MRZResult) -> Unit,
        onError: (error: AmaniError) -> Unit
    ) = IDCaptureImpl.getMRZ(type, onComplete, onError)

    override fun upload(activity: FragmentActivity, docType: String, callBack: IUploadCallBack) =
        IDCaptureImpl.upload(activity, docType, callBack)

    override fun onException(exception: ExceptionCallBack): IDCapture = apply { IDCaptureImpl.onException(exception) }
}
