package ai.amani.sdk.modules.bio_login

import ai.amani.base.annotiations.NonMandatory
import ai.amani.sdk.interfaces.AutoSelfieCaptureObserver
import ai.amani.sdk.interfaces.BioLoginUploadCallBack
import ai.amani.sdk.interfaces.ManualSelfieCaptureObserver
import ai.amani.sdk.modules.selfie.auto_capture.ASCBuilder
import ai.amani.sdk.modules.selfie.manual_capture.model.ManualSelfieCaptureConfig
import ai.amani.sdk.modules.selfie.pose_estimation.model.PoseEstimationConfig
import ai.amani.sdk.modules.selfie.pose_estimation.observable.PoseEstimationObserver
import android.content.Context
import androidx.annotation.ColorRes
import androidx.annotation.DrawableRes
import androidx.fragment.app.Fragment

object BioLogin {

    var autoSelfieConfig: ASCBuilder
        get() = BioLoginImpl.autoSelfieConfig
        set(value) { BioLoginImpl.autoSelfieConfig = value }

    var poseEstimationConfig: PoseEstimationConfig
        get() = BioLoginImpl.poseEstimationConfig
        set(value) { BioLoginImpl.poseEstimationConfig = value }

    var manualSelfieConfig: ManualSelfieCaptureConfig
        get() = BioLoginImpl.manualSelfieConfig
        set(value) { BioLoginImpl.manualSelfieConfig = value }

    var docType: String
        get() = BioLoginImpl.docType
        set(value) { BioLoginImpl.docType = value }

    object AutoSelfie {

        fun timeOutManualButton( timeOut: Int) = apply { BioLoginImpl.AutoSelfie.timeOutManualButton(timeOut) }

        fun observer(
            observer : AutoSelfieCaptureObserver
        ) = apply { BioLoginImpl.AutoSelfie.observer(observer) }

        fun documentType(docType: String) = apply { BioLoginImpl.AutoSelfie.documentType(docType) }

        fun userInterfaceTexts(
            faceNotFoundText: String? = null,
            holdStableText: String? = null,
            faceIsTooFarText: String? = null
        ) = apply { BioLoginImpl.AutoSelfie.userInterfaceTexts(faceNotFoundText, holdStableText, faceIsTooFarText) }

        fun userInterfaceColors(
            @ColorRes appFontColor: Int? = null,
            @ColorRes manualButtonColor: Int? = null,
            @ColorRes ovalViewStartColor: Int? = null,
            @ColorRes ovalViewSuccessColor: Int? = null,
        ) = apply { BioLoginImpl.AutoSelfie.userInterfaceColors(appFontColor, manualButtonColor, ovalViewStartColor, ovalViewSuccessColor) }

        fun build(): Fragment? = BioLoginImpl.AutoSelfie.build()

    }

    object ManualSelfie  {

        fun documentType(docType: String) = apply { BioLoginImpl.ManualSelfie.documentType(docType) }

        fun observer(
            observer : ManualSelfieCaptureObserver
        ) = apply { BioLoginImpl.ManualSelfie.observer(observer) }

        fun userInterfaceTexts(
            selfieDescriptionText: String? = null
        ) = apply { BioLoginImpl.ManualSelfie.userInterfaceTexts(selfieDescriptionText) }

        fun userInterfaceColors(
            @ColorRes appFontColor: Int? = null,
            @ColorRes appBackgroundColor: Int? = null,
            @ColorRes ovalViewColor: Int? = null,
            @ColorRes manualButtonColor: Int? = null
        ) = apply { BioLoginImpl.ManualSelfie.userInterfaceColors(appFontColor, appBackgroundColor, ovalViewColor, manualButtonColor) }

        fun build(): Fragment? = BioLoginImpl.ManualSelfie.build()

    }

    object SelfiePoseEstimation {

        fun documentType(docType: String) = apply { BioLoginImpl.SelfiePoseEstimation.documentType(docType) }

        fun requestedPoseNumber(requestedPoseNumber: Int?) = apply { BioLoginImpl.SelfiePoseEstimation.requestedPoseNumber(requestedPoseNumber) }

        fun ovalViewAnimationDurationMilSec(ovalViewAnimationDurationMilSec: Int?) = apply { BioLoginImpl.SelfiePoseEstimation.ovalViewAnimationDurationMilSec(ovalViewAnimationDurationMilSec) }

        @NonMandatory("Has default values")
        fun userInterfaceTexts(
            faceNotInside: String? = null,
            faceNotStraight: String? = null,
            faceIsTooFar: String? = null,
            holdPhoneVertically: String? = null,
            alertTitle: String? = null,
            alertDescription: String? = null,
            alertTryAgain: String? = null,
            turnLeft: String? = null,
            turnRight: String? = null,
            turnUp: String? = null,
            turnDown: String? = null,
            faceStraight: String? = null
        ) = apply { BioLoginImpl.SelfiePoseEstimation.userInterfaceTexts(faceNotInside, faceNotStraight, faceIsTooFar, holdPhoneVertically, alertTitle, alertDescription, alertTryAgain, turnLeft, turnRight, turnUp, turnDown, faceStraight) }

        @NonMandatory("Has mandatory values")
        fun userInterfaceColors(
            ovalViewStartColor: Int?,
            ovalViewSuccessColor: Int?,
            ovalViewErrorColor: Int?,
            alertTitleFontColor: Int?,
            alertDescriptionFontColor: Int?,
            alertTryAgainFontColor: Int?,
            alertBackgroundFontColor: Int?,
            appFontColor: Int?
        ) = apply { BioLoginImpl.SelfiePoseEstimation.userInterfaceColors(ovalViewStartColor, ovalViewSuccessColor, ovalViewErrorColor, alertTitleFontColor, alertDescriptionFontColor, alertTryAgainFontColor, alertBackgroundFontColor, appFontColor) }

        @NonMandatory("Has default values")
        fun userInterfaceDrawables(
            @DrawableRes mainGuideLeft: Int? = null,
            @DrawableRes mainGuideRight: Int? = null,
            @DrawableRes mainGuideUp: Int? = null,
            @DrawableRes mainGuideDown: Int? = null,
            @DrawableRes mainGuideStraight: Int? = null,
            @DrawableRes secondaryGuideLeft: Int? = null,
            @DrawableRes secondaryGuideRight: Int? = null,
            @DrawableRes secondaryGuideUp: Int? = null,
            @DrawableRes secondaryGuideDown: Int? = null,
        ) = apply { BioLoginImpl.SelfiePoseEstimation.userInterfaceDrawables(mainGuideLeft, mainGuideRight, mainGuideUp, mainGuideDown, mainGuideStraight, secondaryGuideLeft, secondaryGuideRight, secondaryGuideUp, secondaryGuideDown) }

        @NonMandatory("Has default values as true")
        fun userInterfaceVisibilities (
            mainGuideVisibility : Boolean = true,
            secondaryGuideVisibility : Boolean = true
        ) = apply { BioLoginImpl.SelfiePoseEstimation.userInterfaceVisibilities(mainGuideVisibility, secondaryGuideVisibility) }

        fun observer(poseEstimationObserver: PoseEstimationObserver?) = apply { BioLoginImpl.SelfiePoseEstimation.observer(poseEstimationObserver) }

        fun build(): Fragment? = BioLoginImpl.SelfiePoseEstimation.build()

    }

    fun AutoSelfieCapture() : AutoSelfie {
        BioLoginImpl.AutoSelfieCapture()
        return AutoSelfie
    }

    fun ManualSelfieCapture() : ManualSelfie {
        BioLoginImpl.ManualSelfieCapture()
        return ManualSelfie
    }

    fun PoseEstimation(): SelfiePoseEstimation {
        BioLoginImpl.PoseEstimation()
        return SelfiePoseEstimation
    }

    /**
     * Uploads the captured bio login selfie.
     *
     * Unlike the other modules, whose callbacks report whether the upload itself completed, the
     * result reported here is the document status returned by the backend. A `false` result
     * therefore also covers an upload that completed but was not verified.
     *
     * @param callBack receives the document status and, when the backend returns one, the id of
     *                 the uploaded document. Implement only `cb(result)` to keep the previous
     *                 behaviour, or use [bioLoginUploadCallBack] to receive the document id.
     */
    fun upload(context: Context, callBack: BioLoginUploadCallBack?) = BioLoginImpl.upload(context, callBack)

    internal sealed class SelfieFeature {
        object ManualSelfie : SelfieFeature()
        object AutoSelfie : SelfieFeature()
        object PoseEstimation : SelfieFeature()
    }
}
