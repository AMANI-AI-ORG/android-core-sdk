package ai.amani.sdk.modules.selfie.auto_capture

import ai.amani.sdk.interfaces.ExceptionCallBack
import ai.amani.sdk.interfaces.IFragmentCallBack
import ai.amani.sdk.interfaces.IUploadCallBack
import android.widget.FrameLayout
import androidx.annotation.Nullable
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity

object AutoSelfieCapture {

    /**
     * @param faceNotStraightMessageText shown while the face is turned, tilted, or looking up or
     * down; empty (the default) shows no message.
     */
    @JvmOverloads
    fun setCustomUI(messageTextColor: Int,messageTextSize: Int, counterTextColor: Int, counterTextVisibility: Boolean, counterTextSize: Int, timeOutManualButton:Int,closeEnoughMessageText:String, faceNotFoundMessageText:String,holdStableMessageText:String,failureMessageText: String, ovalColor:Int, successColor:Int, faceNotStraightMessageText: String = "") =
        AutoSelfieCaptureImpl.setCustomUI(messageTextColor, messageTextSize, counterTextColor, counterTextVisibility, counterTextSize,
            timeOutManualButton, closeEnoughMessageText, faceNotFoundMessageText, holdStableMessageText, failureMessageText,
            ovalColor, successColor, faceNotStraightMessageText)

    fun onException(exception: ExceptionCallBack) = apply { AutoSelfieCaptureImpl.onException(exception) }

    fun start(docType: String?, @Nullable ascBuilder: ASCBuilder?, frameLayout: FrameLayout, callBack: IFragmentCallBack?): Fragment? =
        AutoSelfieCaptureImpl.start(docType, ascBuilder, frameLayout, callBack)

    fun upload(activity: FragmentActivity, docType: String, callBack: IUploadCallBack) =
        AutoSelfieCaptureImpl.upload(activity, docType, callBack)
}
