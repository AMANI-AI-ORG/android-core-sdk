package ai.amani.sdk.modules.video_call

import android.content.Intent

object VideoCall : IVideoCall {

    override fun returnURL(returnURL: String) = apply { VideoCallImpl.returnURL(returnURL) }

    override fun geoLocation(geoLocation: Boolean) = apply { VideoCallImpl.geoLocation(geoLocation) }

    override fun language(language: String) = apply { VideoCallImpl.language(language) }

    /** @return VideoCall intent
     */
    override fun start(): Intent = VideoCallImpl.start()
}
